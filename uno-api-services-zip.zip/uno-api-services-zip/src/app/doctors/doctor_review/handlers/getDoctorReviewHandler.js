const getDoctorReviewServices = require("../services/getDoctorReviewServices");

function getDoctorReviewHandler(fastify) {
  const getReview = getDoctorReviewServices(fastify);
  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await getReview({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getDoctorReviewHandler;
 