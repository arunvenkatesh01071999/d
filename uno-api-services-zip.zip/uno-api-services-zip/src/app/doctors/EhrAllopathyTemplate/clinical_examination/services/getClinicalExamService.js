const getClinicalExamRepository = require("../repository/getClinicalExamRepository");

function createClinicalExamServiceBasic(fastify) {
  const { ClinicalExamAdd } = getClinicalExamRepository.postClinicalExamRepositoryBasic(fastify);

  return async ({ body, logTrace}) => {
    const knex = fastify.knexMaster;
    const promise1 = ClinicalExamAdd.call(knex, {
      logTrace,
      body
    });

    const [ClinicalExamAddData] = await Promise.all([promise1]);

    return ClinicalExamAddData;
  };
}

function updateClinicalExamServiceBasic(fastify) {
  const { ClinicalExamUpdate } = getClinicalExamRepository.updateClinicalExamRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = ClinicalExamUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedClinicalExamData] = await Promise.all([promise1]);

    return updatedClinicalExamData;
  };
}

function getClinicalExamInfoService(fastify) {
  
  const { ClinicalExamGetAlls } = getClinicalExamRepository.getClinicalExamRepository(fastify);
  
  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = ClinicalExamGetAlls.call(knex, {
      logTrace
    });
    const [getClinicalExamAlldata] = await Promise.all([promise1]);
    return getClinicalExamAlldata;
  }
}

function getClinicalExamInfoServiceId(fastify) {
  
  const { ClinicalExamGetOne } = getClinicalExamRepository.getClinicalExamRepositoryId(fastify);
  
  return async ({ params,logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = ClinicalExamGetOne.call(knex, {
      logTrace,
      params
    });
    const [getClinicalExamOnedata] = await Promise.all([promise1]);
    return getClinicalExamOnedata;
  }
}

function deleteClinicalExamServiceId(fastify) {
 
  const { ClinicalExamDelete } = getClinicalExamRepository.deleteClinicalExamRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = ClinicalExamDelete.call(knex, {
      logTrace,
      params
    });

    const [deleteClinicalExamdata] = await Promise.all([promise1]);

    return deleteClinicalExamdata;
  };
}


module.exports = {

 createClinicalExamServiceBasic,
 updateClinicalExamServiceBasic,
 getClinicalExamInfoService,
 getClinicalExamInfoServiceId,
 deleteClinicalExamServiceId
};
