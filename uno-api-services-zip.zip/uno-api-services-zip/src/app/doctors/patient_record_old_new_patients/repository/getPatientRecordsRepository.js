const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers")
const { PatientRecords } = require("../commons/constants");
const { PATIENT_RECORD } = require("../commons/constants");
const { DOCTORBASICINFO } = require("../commons/constants");
const { CustomError } = require("../../../errorHandler");


// function getPatientRecordsRepositoryPost(fastify) {
//   async function PatientRecordsGetOne({ logTrace, body }) {
//     const knex = this;

// const oldorNewpatient = body.oldorNewpatient

//     const oldPatients=[];

//     const newPatients=[];

//     if(oldorNewpatient === 0){

//       const query = knex.raw(`select id from HealthUno_Patient.dbo.patient_registration`);

//       const response = await query;

//       const query1 = knex.raw(`select patient_id from HealthUno_Patient.dbo.patient_booking`);

//       const response1Booking = await query1;

//     const uniquePatientIds = [...new Set(response1Booking.map(item => item.patient_id))];
// const uniqueArray = uniquePatientIds.map(id => ({ patient_id: id }));


//   for (const item1 of response) {

//     if (uniqueArray.some(item2 => item2.patient_id === item1.id)) {
//         const query3 = await knex.raw(`select name,id,mobile from HealthUno_Patient.dbo.patient_registration where id=${item1.id}`);
//         oldPatients.push(query3)
//         console.log(oldPatients, "oldPatients");
//     } 

// }

//       logQuery({
//         logger: fastify.log,
//         query,
//         context: "Get Patient details",
//         logTrace
//       });

//       if (!response.length) {
//         throw CustomError.create({
//           httpCode: StatusCodes.NOT_FOUND,
//           message: "Patient info not found",
//           property: "",
//           code: "NOT_FOUND"
//         });
//       }

//       return oldPatients;
//     }else{

//         const query = knex.raw(`select id from HealthUno_Patient.dbo.patient_registration`);

//         const response = await query;

//         const query1 = knex.raw(`select patient_id from HealthUno_Patient.dbo.patient_booking`);

//         const response1Booking = await query1;

//       const uniquePatientIds = [...new Set(response1Booking.map(item => item.patient_id))];
//   const uniqueArray = uniquePatientIds.map(id => ({ patient_id: id }));

//     for (const item1 of response) {

//       if (uniqueArray.some(item2 => item2.patient_id !== item1.id)) {
//           const query3 = await knex.raw(`select name,id,mobile from HealthUno_Patient.dbo.patient_registration where id=${item1.id}`);
//           newPatients.push(query3)
//           console.log(newPatients, "newPatients");
//       } 

//   }



//         logQuery({
//           logger: fastify.log,
//           query,
//           context: "Get Patient details",
//           logTrace
//         });

//         if (!response.length) {
//           throw CustomError.create({
//             httpCode: StatusCodes.NOT_FOUND,
//             message: "Patient info not found",
//             property: "",
//             code: "NOT_FOUND"
//           });
//         }

//         return newPatients;

//     }




//   }

//   return {
//     PatientRecordsGetOne
//   };
// }


function getPatientRecordsFrontRepositoryPost(fastify) {
  async function PatientRecordsGetOne({ logTrace, body }) {
    const knex = this;

    const oldorNewpatient = body.oldorNewpatient

    const currentTimestamp = Date.now();

    // Convert the timestamp to a Date object
    const currentDate = new Date(currentTimestamp);

    // Extract the date part in ISO format (YYYY-MM-DD)
    const formattedDate = currentDate.toISOString().split('T')[0];

    // console.log(formattedDate,"formattedDate");



    const newPatients = [];
    const oldPatients = [];

    const query = knex.raw(`select id from patient_registration`);

    const responseRegister = await query;

    const responseRegisterId = responseRegister.map(patient => patient.id);

    const query1 = knex.raw(`select patient_id from patient_booking`);

    const responseBooking = await query1;

    const responseBookingId = responseBooking.map(patient => patient.patient_id);


    if (oldorNewpatient === 1) {   // 1 is new patients

      const difference =
        responseRegisterId.filter((element) => !responseBookingId.includes(element));

      for (const item1 of difference) {

        // var query3 = await knex.raw(`SELECT name, id, mobile
        // FROM patient_registration
        // WHERE id = ${item1} AND DATE(created_at) = '${formattedDate}';
        // `);

        var query3 = await knex.raw(`SELECT name, id as patient_id , mobile,profile_image
        FROM patient_registration
        WHERE id = ${item1} AND CONVERT(date, created_at) = '${formattedDate}';
        `)

        newPatients.push(query3)

      }

      const difference2 =
        responseRegisterId.filter((element) => responseBookingId.includes(element));

      for (const item1 of difference2) {

        var query4 = await knex.raw(`select a.name,a.id as patient_id,a.mobile,a.profile_image from patient_registration as a
        left join patient_booking as b on b.patient_id=a.id where a.id=${item1} and b.appointment_status =4 and
        b.appointment_date = '${formattedDate}'`)

        newPatients.push(query4)
      }

      const flattenedArray = newPatients.flatMap(item => item);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      if (!flattenedArray.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return flattenedArray;
    }
    else {                           // 0 is old patients 

      const difference =
        responseRegisterId.filter((element) => responseBookingId.includes(element));

      for (const item1 of difference) {
        var query3 = await knex.raw(`select b.name,b.id as patient_id,b.mobile,b.profile_image
        from patient_booking as a
        left join patient_registration as b on b.id=a.patient_id
        where a.patient_id=${item1} and a.appointment_status !=3 and a.appointment_status !=4 and a.appointment_date = '${formattedDate}'`);
        oldPatients.push(query3)
      }

      const flattenedArray = oldPatients.flatMap(item => item);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      if (!flattenedArray.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return flattenedArray;

    }
  }

  return {
    PatientRecordsGetOne
  };
}

function getPatientRecordsDateFilterRepositoryPost(fastify) {
  async function PatientRecordsGetOne({ logTrace, body }) {
    const knex = this;

    const oldorNewpatient = body.oldorNewpatient

    const appintmentDate = body.appintmentDate

    const newPatients = [];
    const oldPatients = [];

    const query = knex.raw(`select id from patient_registration`);

    const responseRegister = await query;

    const responseRegisterId = responseRegister.map(patient => patient.id);

    const query1 = knex.raw(`select patient_id from patient_booking`);

    const responseBooking = await query1;

    const responseBookingId = responseBooking.map(patient => patient.patient_id);


    if (oldorNewpatient === 1) {   // 1 is new patients

      const difference =
        responseRegisterId.filter((element) => !responseBookingId.includes(element));

      for (const item1 of difference) {

        // var query3 = await knex.raw(`select name,id,mobile from patient_registration
        //  where id=${item1}`);

        var query3 = await knex.raw(`SELECT name, id as patient_id, mobile ,profile_image
        FROM patient_registration
        WHERE id = ${item1} AND CONVERT(date, created_at) = '${appintmentDate}'`)

        newPatients.push(query3)

      }

      const difference2 =
        responseRegisterId.filter((element) => responseBookingId.includes(element));

      for (const item1 of difference2) {

        // var query4 = await knex.raw(`select a.name,a.id,a.mobile from patient_registration as a
        // left join patient_booking as b on b.patient_id=a.id where a.id=${item1} and b.appointment_status =4`)

        var query4 = await knex.raw(`select a.name,a.id as patient_id,a.mobile ,a.profile_image from patient_registration as a
        left join patient_booking as b on b.patient_id=a.id where a.id=${item1} and b.appointment_status =4 and
        b.appointment_date = '${appintmentDate}'`)

        newPatients.push(query4)
      }

      const flattenedArray = newPatients.flatMap(item => item);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      if (!flattenedArray.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return flattenedArray;
    }
    else {                           // 0 is old patients 

      const difference =
        responseRegisterId.filter((element) => responseBookingId.includes(element));

      for (const item1 of difference) {
        var query3 = await knex.raw(`select b.name,b.id as patient_id,b.mobile,b.profile_image
        from patient_booking as a
        left join patient_registration as b on b.id=a.patient_id
        where a.patient_id=${item1} and a.appointment_status =3  and a.appointment_date = '${appintmentDate}'`);
        oldPatients.push(query3)
      }

      const flattenedArray = oldPatients.flatMap(item => item);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      if (!flattenedArray.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return flattenedArray;

    }
  }

  return {
    PatientRecordsGetOne
  };
}





function getPatientRecordsOldRepositoryPost(fastify) {
 
  async function getPatientRocords({body,params, logTrace,patient_id }) {
    const knex = this;

    const query = knex(PATIENT_RECORD.NAME)
      .where(PATIENT_RECORD.COLUMNS.PATIENT_ID, patient_id)
      .orderBy(PATIENT_RECORD.COLUMNS.FILE_FLAG, "asc");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get patient records",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Records not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const allRecords = Object.values(response).reduce((acc, section) => acc.concat(section), []);

    const sortedRecords = allRecords.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    return sortedRecords
  }
  async function getDoctorInfo({ doctor_id, logTrace }) {
    const knex = fastify.knexMaster;

    const query = knex(DOCTORBASICINFO.NAME).where(
      DOCTORBASICINFO.COLUMNS.ID,
      doctor_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      return [];
    }
    return response[0];
  }
  async function getDoctorInfoFull({ patient_id, logTrace }) {
    const knex = this;
    console.log(patient_id,"patient_id");
    var query =  knex.raw(`select id as patient_id,name,age,
    gender_id,email,mobile,dob,logitute,latitude,
    blood_group_id,profile_image,created_at,updated_at,
    address from patient_registration where id=${patient_id}`)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor details",
      logTrace
    });

    const response = await query;
    console.log(response,"response last");
    if (!response.length) {
      return [];
    }
    return response[0];
  }
  return {
   
    getPatientRocords,
    getDoctorInfo,
    getDoctorInfoFull
  };
}

module.exports = {
  getPatientRecordsFrontRepositoryPost,
  getPatientRecordsDateFilterRepositoryPost,
  getPatientRecordsOldRepositoryPost

};
