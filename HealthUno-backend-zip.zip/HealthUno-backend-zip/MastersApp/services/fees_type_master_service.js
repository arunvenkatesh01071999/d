const FeesMaster = require('../models/FeesTypeMasterModel');

const Get = async () => {
    await FeesMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await FeesMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (fees_type_name) => {
    await FeesMaster.findAll({ where: { fees_type_name: fees_type_name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateFeesType = async (ft_data) => {
    await FeesMaster.create(ft_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateFeesType = async (id, ft_data) => {
    await FeesMaster.update(ft_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyFeesType = async (id) => {
    await FeesMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateFeesType,
    UpdateFeesType,
    DestroyFeesType
};