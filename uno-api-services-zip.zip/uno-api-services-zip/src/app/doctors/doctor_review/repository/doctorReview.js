const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");

const { DOCTORBASICINFO } = require("../commons/constants");
const { DOCTOREDUCATIONINFO } = require("../commons/constants");
const { DOCTORADDRESSINFO } = require("../commons/constants");
const { DOCTORLANGUAGEINFO } = require("../commons/constants");
const { DOCTOR_REVIEWS } = require("../commons/constants");
const { REGISTERINFO } = require("../commons/constants");
function doctorReviewRepo(fastify) {
  async function postReview({
    logTrace,
    input: { doctor_id, patient_id, comments, rating }
  }) {
    const knex = this;
    const query = knex(DOCTOR_REVIEWS.NAME)
      .where(DOCTOR_REVIEWS.COLUMNS.DOCTOR_ID, doctor_id)
      .where(DOCTOR_REVIEWS.COLUMNS.PATIENT_ID, patient_id);

    const exists_response = await query;

    if (exists_response.length > 0) {
      // Review already exists, so update it
      const query_update = await knex(`${DOCTOR_REVIEWS.NAME}`)
        .where(`${DOCTOR_REVIEWS.COLUMNS.DOCTOR_ID}`, doctor_id)
        .where(`${DOCTOR_REVIEWS.COLUMNS.PATIENT_ID}`, patient_id)
        .update({
          [DOCTOR_REVIEWS.COLUMNS.COMMENTS]: comments,
          [DOCTOR_REVIEWS.COLUMNS.RATING]: rating
        });

      const response = await query_update;
      if (!response) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while updating patient review",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    } else {
      // Review does not exist, so insert a new one
      const query_insert = knex(DOCTOR_REVIEWS.NAME).insert({
        [DOCTOR_REVIEWS.COLUMNS.PATIENT_ID]: patient_id,
        [DOCTOR_REVIEWS.COLUMNS.DOCTOR_ID]: doctor_id,
        [DOCTOR_REVIEWS.COLUMNS.COMMENTS]: comments,
        [DOCTOR_REVIEWS.COLUMNS.RATING]: rating
      });
      logQuery({
        logger: fastify.log,
        query,
        context: "Add patient review",
        logTrace
      });
      await query_insert;
    }

    return { success: true };
  }
  async function getReview({ params, logTrace }) {
    const knex = this;

    const query = knex(DOCTOR_REVIEWS.NAME)
      .where(DOCTOR_REVIEWS.COLUMNS.DOCTOR_ID, params.doctor_id)
      .where(DOCTOR_REVIEWS.COLUMNS.ACTIVE, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor reviews details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor reviews not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getPatientInfo({ pid, logTrace }) {
    const knex = fastify.knexPatient;

    const query = knex(REGISTERINFO.NAME).where(REGISTERINFO.COLUMNS.ID, pid);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get patient details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "patient not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function updateDoctorRate({ overallRating, params, logTrace }) {
    const knex = this;

    const query_update = await knex(`${DOCTORBASICINFO.NAME}`)
      .where(`${DOCTORBASICINFO.COLUMNS.ID}`, params.doctor_id)
      .update({
        [DOCTORBASICINFO.COLUMNS.RATING]: overallRating
      });

    await query_update;
  }
  async function postDisableReview({
    logTrace,
    input: { doctor_id, patient_id, active }
  }) {
    const knex = this;

    const query_update = await knex(`${DOCTOR_REVIEWS.NAME}`)
      .where(`${DOCTOR_REVIEWS.COLUMNS.PATIENT_ID}`, patient_id)
      .where(`${DOCTOR_REVIEWS.COLUMNS.DOCTOR_ID}`, doctor_id)
      .update({
        [DOCTOR_REVIEWS.COLUMNS.ACTIVE]: active
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating patient review",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function getAdminReview({ params, logTrace }) {
    const knex = this;

    const query = knex(DOCTOR_REVIEWS.NAME).where(
      DOCTOR_REVIEWS.COLUMNS.DOCTOR_ID,
      params.doctor_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor reviews details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor reviews not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  return {
    postReview,
    getReview,
    getPatientInfo,
    updateDoctorRate,
    postDisableReview,
    getAdminReview
  };
}

module.exports = doctorReviewRepo;
