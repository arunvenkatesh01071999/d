const hospitalDisableReviewServices = require("../services/hospitalDisableReviewServices");

function postDisableHospitalReviewHandler(fastify) {
  const postDisableReview = hospitalDisableReviewServices(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await postDisableReview({ body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = postDisableHospitalReviewHandler;
