const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const education_info_service = require('../services/education_info');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();
const db1 = require('../../config/db1');
const AddCheck = require('../../services/doctor_addCheck_service');


const FetchQualificationInfo = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await education_info_service.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_education_info_service');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await education_info_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_education_info_service', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewQualificationInfo = async (req, res, next) => {
    const qualification_name_id = req.body.qualification_name_id;
    const yop = req.body.yop;
    const doctor_name_id = req.body.doctor_name_id;
    const certificate_path = req.files ? req.files.certificate_path : null;
    // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {

    //     certificate_path = req.files.certificate_path;
    // } else {
    //     certificate_path = req.body.certificate_path;
    // }
    const active = req.body.active;
    const created_at = date();
    const updated_at = date();
    const created_by = req.user.id;
    const updated_by = req.user.id;

    var query = `SELECT COUNT(*) AS count FROM d_education_info WHERE doctor_name_id = ${doctor_name_id}`;
    const result_data = await db1.query(query);
    const t = result_data.flat();
    const check = t[0].count;
    if (check === 0) {
        const query = AddCheck(req.body.doctor_name_id)
    }

    if (qualification_name_id) {
        s_data = {
            qualification_name_id: parseInt(qualification_name_id),
            yop: yop,
            doctor_name_id: parseInt(doctor_name_id),
            active: parseInt(active),
            created_at: created_at,
            updated_at: updated_at,
            created_by: created_by,
            updated_by: updated_by
        }

        if (certificate_path) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = certificate_path.name;
            const buffer = certificate_path.data;
            const path = `images/${fileName}`;
            const file = storage.bucket(bucketName).file(path);
            // Upload the image to GCS
            await file.save(buffer);
            s_data.certificate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            // If no image is provided, you may want to handle null or default values
            s_data.certificate_path = null; // or set a default image URL
        }

        // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {
        //     s_data.certificate_path = certificate_path.name;
        //     buffer = certificate_path.data
        //     path = './media/' + certificate_path.name;
        //     fs.writeFile(path.toString(), buffer, function (err) {
        //         if (err) {
        //             return console.log(err);
        //         }
        //     });

        // } else {
        //     certificate_path = req.body.certificate_path;
        //     s_data.certificate_path = certificate_path;
        // }
        console.log(s_data)
        await education_info_service.CreateEducationInfo(s_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_education_info_service')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "qualification_name_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

// const UpdateQualificationInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         qualification_name_id = req.body.qualification_name_id;
//         doctor_name_id = req.body.doctor_name_id;
//         yop = req.body.yop;
//         if (req.files && req.files.certificate_path && req.files.certificate_path.name) {

//             certificate_path = req.files.certificate_path;
//         } else {
//             certificate_path = req.body.certificate_path;
//         }
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (qualification_name_id) {
//             s_data = {
//                 qualification_name_id: parseInt(qualification_name_id),
//                 doctor_name_id: parseInt(doctor_name_id),
//                 yop: yop,
//                 active: parseInt(active),
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             if (certificate_path) {
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 const fileName = certificate_path.name;
//                 const buffer = certificate_path.data;
//                 const path = `images/${fileName}`;
//                 const file = storage.bucket(bucketName).file(path);
//                 // Upload the image to GCS
//                 await file.save(buffer);
//                 s_data.certificate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//             }
//             else {
//                 // If no image is provided, you may want to handle null or default values
//                 s_data.certificate_path = null; // or set a default image URL
//             }
//             // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {
//             //     s_data.certificate_path = certificate_path.name;
//             //     buffer = certificate_path.data
//             //     path = './media/' + certificate_path.name;
//             //     fs.writeFile(path.toString(), buffer, function (err) {
//             //         if (err) {
//             //             return console.log(err);
//             //         }
//             //     });

//             // } else {
//             // certificate_path = req.body.certificate_path;
//             // s_data.certificate_path = certificate_path;
//             // }
//             await education_info_service.UpdateEducationInfo(id, s_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_education_info_service')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         } else {
//             msg = "language_name_id and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const UpdateQualificationInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const qualification_name_id = req.body.qualification_name_id;
        const yop = req.body.yop;
        const doctor_name_id = req.body.doctor_name_id;
        // const certificate_path = req.files ? req.files.certificate_path : null;
        if (req.files && req.files.certificate_path && req.files.certificate_path.name) {

            certificate_path = req.files.certificate_path;
        } else {
            certificate_path = req.body.certificate_path;
        }
        const active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (qualification_name_id) {
            e_data = {
                qualification_name_id: qualification_name_id,
                yop: yop,
                doctor_name_id: doctor_name_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            if (typeof certificate_path === "string") {
                e_data.certificate_path = certificate_path;
            } else {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = certificate_path.name;
                const buffer = certificate_path.data;
                const path = `images/${fileName}`;
                const file = storage.bucket(bucketName).file(path);
                // Upload the image to GCS
                await file.save(buffer);
                e_data.certificate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            }

            // if (certificate_path) {
            //     const bucketName = process.env.GCP_BUCKET_NAME;
            //     const fileName = certificate_path.name;
            //     const buffer = certificate_path.data;
            //     const path = `images/${fileName}`;
            //     const file = storage.bucket(bucketName).file(path);
            //     // Upload the image to GCS
            //     await file.save(buffer);
            //     e_data.certificate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            // }
            // else {

            //     certificate_path = req.body.certificate_path;
            //     e_data.certificate_path = certificate_path;
            // }

            // if (req.files && req.files.certificate_path && req.files.certificate_path.name) {
            //     e_data.certificate_path = certificate_path.name;
            //     buffer = certificate_path.data
            //     path = './media/' + certificate_path.name;
            //     fs.writeFile(path.toString(), buffer, function (err) {
            //         if (err) {
            //             return console.log(err);
            //         }
            //     });

            // } else {
            //     certificate_path = req.body.certificate_path;
            //     e_data.certificate_path = certificate_path;
            // }
            // console.log(e_data)
            await education_info_service.UpdateEducationInfo(id, e_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_education_info_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "qualification_name_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteQualificationInfo = async (req, res, next) => {
    try {
        const id = req.params.id;

        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }

        // Fetch insurance data by ID
        const quaData = await education_info_service.GetbyId(id);

        if (!quaData) {
            const msg = "ID doesn't exist";
            return res.status(400).json(failure_func(msg));
        }

        // Delete the image from GCS
        if (quaData.certificate_path) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = quaData.certificate_path.split('/').pop(); // Extract file name from URL
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Delete the image from GCS
            await file.delete();
        }

        // Delete insurance entry
        const deletedRows = await education_info_service.DestroyEducationInfo(id)

        if (deletedRows === 1) {
            const msg = "Deleted successfully";
            cache.DEL(req.user.id + '_insurance_services');
            res.status(200).json(success_func(msg));
        } else {
            const msg = "Failed to delete. ID may not exist";
            res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};


module.exports = {
    NewQualificationInfo,
    FetchQualificationInfo,
    UpdateQualificationInfo,
    DeleteQualificationInfo
}