const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const loginquestionSchema = {
  tags: ["LOGIN QUESTION"],
  summary: "This API is used to login ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        id:{ type: "integer" },
        category_ques_id: { type: "integer" },
        questions: { type: "string" },
        suggestion:{ type: "integer" }
      }
    },
    ...errorSchemas
  }
};

const allcatloginquestionSchema = {
  tags: ["LOGIN QUESTION ALL CATEGORY"],
  summary: "This API is used to login question ",
  headers: { $ref: "request-headers#" },

  response: {
    200: {
      type: "object",
      properties: {
        id:{ type: "integer" },
        question_category: { type: "integer" }
      }
    },
    ...errorSchemas
  }
};

const postLoginCategorySchema = {
  tags: ["POST Service INFO"],
  summary: "This API is to Post Login Category  ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "question_category",
      "question_category_img",
      "active",
      "created_by"
    ],
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const putLoginCategorySchema = {
  tags: ["POST Service INFO"],
  summary: "This API is to Post Login Category  ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "question_category",
      "question_category_img",
      "active",
      "created_by"
    ],
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const deleteLoginCategorySchema = {
  tags: ["DELETE LoginCategorySchema"],
  summary: "This API is to delete LoginCategorySchema ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = { loginquestionSchema,allcatloginquestionSchema , postLoginCategorySchema , putLoginCategorySchema , deleteLoginCategorySchema};
