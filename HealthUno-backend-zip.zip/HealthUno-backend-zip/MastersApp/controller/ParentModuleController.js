const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const parent_module_services = require('../services/parent_module_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchParentModules = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await parent_module_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_parent_module');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await parent_module_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_parent_module', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
        }
    }
}

const NewParentModule = async (req, res, next) => {
    parent_module_name = req.body.parent_module_name;
    main_module_id = req.body.main_module_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (parent_module_name && main_module_id && active) {
        pm_data = {
            parent_module_name: parent_module_name,
            main_module_id: main_module_id,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await parent_module_services.GetbyName(parent_module_name)
            .then(services_data => {
                if (services_data.length > 0) {
                    msg = "parent Module Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    parent_module_services.CreateParentModule(pm_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(500).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_parent_module')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(500).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "parent_module_name, main_module_id and active is required";
        res.status(500).json(failure_func(msg))
    }
}

const UpdateParentModule = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        parent_module_name = req.body.parent_module_name;
        main_module_id = req.body.main_module_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (parent_module_name && main_module_id && active) {
            pm_data = {
                parent_module_name: parent_module_name,
                main_module_id: main_module_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // await parent_module_services.GetbyName(parent_module_name)
            //     .then(services_data => {
            //         if (services_data.length > 0) {
            //             msg = "parent Module Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            parent_module_services.UpdateParentModule(id, pm_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_parent_module')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(500).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
            //     }
            // })
        } else {
            msg = "parent_module_name, main_module_id and active is required";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

const DeleteParentModule = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await parent_module_services.DestroyParentModule(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_parent_module')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}


module.exports = {
    NewParentModule,
    FetchParentModules,
    UpdateParentModule,
    DeleteParentModule
}