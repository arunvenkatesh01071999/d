const LoginquestionHandler = require('./getloginquestion');

module.exports = {
    LoginquestionHandler
}