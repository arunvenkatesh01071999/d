const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postDoctorReviewSchema = {
  tags: ["DOCTOR REVIEWS"],
  summary: "This API is used to post reivews",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["doctor_id", "patient_id", "comments", "rating"],
    additionalProperties: false,
    properties: {
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      comments: { type: "string" },
      rating: { type: "number" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postDoctorReviewSchema;
