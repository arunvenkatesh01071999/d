const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../../../src/app/commons/helpers");
const { PRESCRIPTION } = require("../commons/constants");
const { MEDICINE } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postPrescriptionRepositoryBasic(fastify) {
  async function PrescriptionAdd({ logTrace, body }) {
    const knex = this;

    const medicine_name = body.medicine_name

    const medicine_names = await knex.raw(`select medicine_name from medicine_list`)
      .then(response => response.map(med => med.medicine_name));

      if (!medicine_names.includes(medicine_name)) {
        // try {
          var query = await knex(`${MEDICINE.NAME}`).insert({
            [MEDICINE.COLUMNS.MEDICINE_NAME]: body.medicine_name,
            [MEDICINE.COLUMNS.ACTIVE]: body.active,
            [MEDICINE.COLUMNS.CREATED_BY]: body.created_by,
            [MEDICINE.COLUMNS.UPDATED_BY]: body.created_by
          })
          .returning(MEDICINE.COLUMNS.ID);

          var medicine_details = {"medicine_id":query[0].id,
          "medicine_name":medicine_name
        };


        // }
        
        // catch (error) {
        //   console.error("Error Inserting Disease:", error);
        // }

      }
      else{

        var medicine_one = await knex.raw(`select * from medicine_list where medicine_name = '${medicine_name}'`)
        if(medicine_one.length>0){
          var medicine_details = {"medicine_id":medicine_one[0].id,
          "medicine_name":medicine_one[0].medicine_name
           };
        }
      }

    // const query = await knex(`${PRESCRIPTION.NAME}`).insert({
    //   [PRESCRIPTION.COLUMNS.MEDICINE_NAME]: body.medicine_name,
    //   [PRESCRIPTION.COLUMNS.DOCTOR_ID]: body.doctor_id,
    //   [PRESCRIPTION.COLUMNS.PATIENT_ID]: body.patient_id,
    //   [PRESCRIPTION.COLUMNS.ACTIVE]: body.active,
    //   [PRESCRIPTION.COLUMNS.CREATED_BY]: body.created_by
    // })

    // const response = await query;


    return  medicine_details
  }

  return {
    PrescriptionAdd

  };
}

function updatePrescriptionRepository(fastify) {
  async function PrescriptionUpdate({ logTrace, body, params }) {
    const knex = this;

    const patient_id = params.patient_id;
    const doctor_id = body.doctor_id
    const medicine_name = body.medicine_name

    const medicine_nameDb = await knex.raw(`select top 1 medicine_name from e_e_prescription where patient_id = ${patient_id} and doctor_id = ${doctor_id} order By id desc`)
    .then(response => response.map(med => med.medicine_name));

    // console.log(cheifComplientPost,"cheifComplientPost");

    var notDifference = medicine_nameDb.includes(medicine_name)
  

  if (notDifference) {

    const prescriptionGetID = await knex.raw(`select top 1 id from e_e_prescription where patient_id = ${patient_id} and doctor_id = ${doctor_id} order By id desc`)
    const id = prescriptionGetID[0].id

    const query = await knex(`${PRESCRIPTION.NAME}`)
      .where(`${PRESCRIPTION.COLUMNS.ID}`, id)
      .update({
        [PRESCRIPTION.COLUMNS.MEDICINE_NAME]: body.medicine_name,
        [PRESCRIPTION.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [PRESCRIPTION.COLUMNS.PATIENT_ID]: body.patient_id,
        [PRESCRIPTION.COLUMNS.ACTIVE]: body.active,
        [PRESCRIPTION.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };

  }
  else{

    try {
      await knex(`${MEDICINE.NAME}`).insert({
        [MEDICINE.COLUMNS.MEDICINE_NAME]: body.medicine_name,
        [MEDICINE.COLUMNS.ACTIVE]: body.active,
        [MEDICINE.COLUMNS.CREATED_BY]: body.created_by,
        [MEDICINE.COLUMNS.UPDATED_BY]: body.created_by
      });
    } catch (error) {
      console.error("Error Inserting Disease:", error);
    }

    const prescriptionGetID = await knex.raw(`select top 1 id from e_e_prescription where patient_id = ${patient_id} and doctor_id = ${doctor_id} order By id desc`)
    const id = prescriptionGetID[0].id

    const query = await knex(`${PRESCRIPTION.NAME}`)
      .where(`${PRESCRIPTION.COLUMNS.ID}`, id)
      .update({
        [PRESCRIPTION.COLUMNS.MEDICINE_NAME]: body.medicine_name,
        [PRESCRIPTION.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [PRESCRIPTION.COLUMNS.PATIENT_ID]: body.patient_id,
        [PRESCRIPTION.COLUMNS.ACTIVE]: body.active,
        [PRESCRIPTION.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };

  }
   
  }

  return {
    PrescriptionUpdate,
  };
}

function getPrescriptionRepository(fastify) {

  async function PrescriptionGetAlls({ logTrace }) {

    const knex = this;
    const query = knex.select('*').from(`${PRESCRIPTION.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get e_prescription details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "e_prescription info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PrescriptionGetAlls
  };

}


function getPrescriptionRepositoryId(fastify) {

  async function PrescriptionGetOne({ logTrace, params }) {

    const knex = this;


    // var medicineIdsArray =[]

    // const patient_id = params.patient_id;
    // const doctor_id = params.doctor_id;

  //   const query = knex.raw(`select top 1 a.id as medicine_id,a.medicine_name,a.doctor_id,a.patient_id,b.quantity,b.frequency,b.frequencynotes,
  // b.timing,b.timingnotes,b.duration,b.instruction
  // from e_e_prescription as a
  // left join e_e_prescription_medicine as b on b.medicine_id = a.id
  // where a.patient_id = ${patient_id} and a.doctor_id = ${doctor_id} order By b.medicine_id desc`)

  const query = knex.raw(`select * from `)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get e_prescription details",
      logTrace
    });

    const response = await query;


    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "e_prescription info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }


    return modifiedResponse;
  }

  return {
    PrescriptionGetOne
  };

}


function deletePrescriptionRepositoryId(fastify) {
  async function PrescriptionDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const patient_id = params.patient_id;
    const doctor_id = params.doctor_id;

    // const prescriptionGetID = await knex.raw(`select top 1 id from e_e_prescription where patient_id = ${patient_id} and doctor_id = ${doctor_id} order By id desc`)

    const prescriptionGetID = await knex.raw(`SELECT TOP 1 p.id
    FROM e_e_prescription AS p
    JOIN e_e_prescription_medicine AS pm ON pm.medicine_id = p.id
    WHERE p.patient_id = ${patient_id} AND p.doctor_id = ${doctor_id}
    ORDER BY p.id DESC`)

    const id = prescriptionGetID[0].id

    // const query = await knex(`${PRESCRIPTION.NAME}`).
    //   where(`${PRESCRIPTION.COLUMNS.ID}`, id)
    //   .del();

//     const query = await knex.raw(`DELETE e_e_prescription, e_e_prescription_medicine
// FROM e_e_prescription as a
// JOIN e_e_prescription_medicine ON a.id = b.medicine_id
// WHERE where id = ${id}`)

const query1 = await knex.raw(`DELETE FROM e_e_prescription
WHERE id = ${id}`)


const query2 = await knex.raw(`DELETE FROM e_e_prescription_medicine
WHERE medicine_id = ${id}`)



    return { success: true, message: "Deleted successfully" };
  }

  return {
    PrescriptionDelete
  };
}

function deleteAllPrescriptionRepositoryId(fastify) {
  async function PrescriptionDelete({
    logTrace,
    params,
    body
  }) {
    const knex = this;

    const patient_id = params.patient_id;
    const doctor_id = params.doctor_id;
    
    const medicine_ids = body.medicine_id;

  // console.log(medicine_ids,"medicine_ids");


    for(const id of medicine_ids){


const query1 = await knex.raw(`DELETE FROM e_e_prescription
WHERE id = ${id}`)

const query2 = await knex.raw(`DELETE FROM e_e_prescription_medicine
WHERE medicine_id = ${id}`)


    }

    return { success: true, message: "Deleted successfully" };
  }

  return {
    PrescriptionDelete
  };
}

module.exports = {
  postPrescriptionRepositoryBasic,
  updatePrescriptionRepository,
  getPrescriptionRepository,
  getPrescriptionRepositoryId,
  deletePrescriptionRepositoryId,
  deleteAllPrescriptionRepositoryId

};
