const getScanByLabHandler = require("./getScanByLabHandler");
const getHealthPackageByScanHandler = require("./getHealthPackageByScanHandler");

module.exports = {
  getScanByLabHandler,
  getHealthPackageByScanHandler
};
