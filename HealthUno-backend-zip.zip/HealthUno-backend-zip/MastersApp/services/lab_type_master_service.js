const LabType = require('../models/LabTypeMasterModel');

const Get = async () => {
    await LabType.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await LabType.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabType = async (c_data) => {
    await LabType.create(c_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabType = async (id, c_data) => {
    await LabType.update(c_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabType = async (id) => {
    await LabType.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (lab_type_name) => {
    await LabType.findAll({ where: { lab_type_name: lab_type_name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateLabType,
    UpdateLabType,
    GetbyName,
    DestroyLabType
};
