const CHEIFCOMPLAINTS = {
  NAME: "e_cheif_complaints",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ISALLO_OR_AUYR: "isallo_or_auyr",
    APPOINT_ID: "appoint_id",
    CHEIF_COMPLIENTS: "cheif_complients",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};


const ILLNESSTYPE = {
  NAME: "illness_types",
  COLUMNS: {
    ID: "id",
    ILLNESS_TYPE_NAME: "illness_type_name",
    ACTIVE: "active",
    LOGO_IMAGE: "logo_image",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};


module.exports = {
  CHEIFCOMPLAINTS,
  ILLNESSTYPE
  
};





