const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const HospitalType = require('../../MastersApp/models/HospitalTypeMasterModel');
const SectorType = require('../../MastersApp/models/HospitalSectorModel');
const Accredation = require('../../MastersApp/models/AccredationModel');
const HoapitalImage = require('../models/HospitalImgModel');


const HospitalBasicInfo = sequelize.define("h_hospital_basic_info", {
    hospital_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "hospital_name is required"
            }
        }
    },
    hospital_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    // user_id: {
    //     type: DataTypes.STRING,
    //     allowNull: false
    // },
    sector_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    accredation_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    regNo: {
        type: DataTypes.STRING,
        allowNull: false
    },
    about: {
        type: DataTypes.STRING,
        allowNull: false
    },
    certicate_path: {
        type: DataTypes.STRING,
        allowNull: false,
        // defaultValue: '',
    },
    hospital_image: {
        type: DataTypes.STRING,
        allowNull: true
    },
    isApproved: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0
    },
    approve_date: {
        type: DataTypes.DATE,
        allowNull: true,
        default:'null'
    },
    approved_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default:''
    },
    addCheck: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    reason: {
        type: DataTypes.STRING,
        allowNull: true,
    },

    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

HospitalBasicInfo.belongsTo(HospitalType, { foreignKey: 'hospital_type_id' });
HospitalBasicInfo.belongsTo(SectorType, { foreignKey: 'sector_id' });
HospitalBasicInfo.belongsTo(Accredation, { foreignKey: 'accredation_id' });
HospitalBasicInfo.hasMany(HoapitalImage, { foreignKey: 'hospital_name_id', as: 'Image' });
// HospitalBasicInfo.hasMany(ContactInfo, { foreignKey: 'hospital_name_id', as: 'contact' })



HospitalBasicInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_hospital_basic_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

HospitalBasicInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_hospital_basic_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = HospitalBasicInfo;