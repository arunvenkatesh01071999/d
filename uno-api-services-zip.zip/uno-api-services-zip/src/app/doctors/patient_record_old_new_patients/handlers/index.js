const getPatientRecordsHandler = require("./getPatientRecordsHandler.js");

module.exports = {
  getPatientRecordsHandler
};
