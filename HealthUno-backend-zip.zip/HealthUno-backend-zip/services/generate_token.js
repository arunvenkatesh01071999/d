// const jwt = require("jsonwebtoken");
// require('dotenv').config()

// const generateToken = (user) => {
//     secret_key = process.env.JWT_SECRET_KEY
//     const token = jwt.sign(user, secret_key, { expiresIn: '7d' });
//     return token
// }

// module.exports = generateToken;


const jwt = require("jsonwebtoken");
require('dotenv').config()

const generateToken = async (user) => {
    secret_key = process.env.JWT_SECRET_KEY
    const token = jwt.sign(user, secret_key);
    // const token = jwt.sign(user, secret_key, { expiresIn: '7d' });
    return token
}

module.exports = { generateToken };