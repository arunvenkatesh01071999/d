const BANNER = {
  NAME: "banner",
  COLUMNS: {
    BANNER_IMAGE: "banner_image",
    IS_ACTIVE: "banner_active",
    BANNER_OFFER: "banner_offer"
  }
};

module.exports = {
  BANNER
};
