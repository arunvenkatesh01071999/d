const hospitalServices = require("../services/getHospitalService");

function getHospitalInfoByUserHandler(fastify) {
  const getHospitalInfoByUser =
    hospitalServices.getHospitalInfoByUserService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getHospitalInfoByUser({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHospitalInfoByUserHandler;
