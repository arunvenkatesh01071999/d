const getPatientDetailsService = require("../services/getPatientDetailsService");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream")
const pump = util.promisify(pipeline);


function getPatientDetailsHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};

function reschedulepostHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getreschedulepostInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};

function reschedulepostHandlerv2Post(fastify) {

  const getPatientDetails = getPatientDetailsService.getreschedulepostInfoServicev2versionPost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};



function reschedulefinalHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getreschedulefinalPost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};

function cancelappoinmentlHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getcancelPost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};

function getPatientDetailsDateFilterHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsDateFilterInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};


function getPatientDetailsHandlerPostImg(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsInfoServicePostImg(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace,
      params,
      body

    });
    return reply.code(200).send(response);
  };

}

function getPatientDetailsHandlerPostImg(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsInfoServicePostImg(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace,
      params,
      body

    });
    return reply.code(200).send(response);
  };

}


function getPatientDetailsWithEhrHandlerPost(fastify) {

  const getPatientDetails = getPatientDetailsService.getPatientDetailsWithEhrInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getPatientDetails({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

};

function getCancelAppointmentwithReasonHandler(fastify) {

  const getCancelAppointmentwithReason = getPatientDetailsService.getCancelAppointmentwithReasonService(fastify);

  return async (request, reply) => {

    const { logTrace, params, body } = request;
    const response = await getCancelAppointmentwithReason({
      logTrace, body,
      params

    });
    return reply.code(200).send(response);
  };

}

function getPatientDetailsDateFilterOverallCompleteHandlerPost(fastify) {
  const getPatientDetailsOverallComplete = getPatientDetailsService.getPatientDetailsDateFilterOverallCompleteInfoServicePost(fastify);
  return async (request, reply) => {
    const { logTrace, params, body } = request;
    const response = await getPatientDetailsOverallComplete({
      logTrace, body,
      params
    });
    return reply.code(200).send(response);
  };
};


module.exports = {
  getPatientDetailsDateFilterHandlerPost,
  getPatientDetailsHandlerPostImg,
  getPatientDetailsHandlerPost,
  reschedulepostHandlerPost,
  reschedulefinalHandlerPost,
  cancelappoinmentlHandlerPost,
  getPatientDetailsWithEhrHandlerPost,
  getCancelAppointmentwithReasonHandler,
  reschedulepostHandlerv2Post,
  getPatientDetailsDateFilterOverallCompleteHandlerPost
};
