const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { LAB_TEST } = require("../commons/constants");
const { LAB_BASIC_INFO } = require("../commons/constants");
const { ACCREDATION } = require("../commons/constants");
const { LAB_SECTOR } = require("../commons/constants");
const { LAB_TYPE_MASTER } = require("../commons/constants");
const { LAB_TEST_PACK } = require("../commons/constants");
const { L_LAB_INFO } = require("../commons/constants");
const { CITIES } = require("../commons/constants");
const { STATES } = require("../commons/constants");
const { COUNTRIES } = require("../commons/constants");
const { LAB_ADDRESS_INFO } = require("../commons/constants");
const { LAB_CONTACT_INFO } = require("../commons/constants");
const { LAB_SERVICE } = require("../commons/constants");
const { LAB_SERVICE_INFO } = require("../commons/constants");
const { LAB_SCAN_INFO } = require("../commons/constants");
const { SCAN_TEST_MASTER } = require("../commons/constants");
const { SCAN_TEST_PACK } = require("../commons/constants");

function scanRepo(fastify) {
  async function getScanByLab({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.ID} as scaninfo_id`,
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.COST}`,
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.DISCOUNT}`,
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.SCAN_NAME_ID}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_NAME}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ID} as lab_id `,
        `${SCAN_TEST_MASTER.NAME}.*`
      ])
      .from(`${LAB_SCAN_INFO.NAME} as ${LAB_SCAN_INFO.NAME}`)
      .leftJoin(
        `${LAB_BASIC_INFO.NAME} as ${LAB_BASIC_INFO.NAME}`,
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.LAB_NAME_ID}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ID}`
      )
      .leftJoin(
        `${SCAN_TEST_MASTER.NAME} as ${SCAN_TEST_MASTER.NAME}`,
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.SCAN_NAME_ID}`,
        `${SCAN_TEST_MASTER.NAME}.${SCAN_TEST_MASTER.COLUMNS.ID}`
      )
      .where(
        `${LAB_SCAN_INFO.NAME}.${LAB_SCAN_INFO.COLUMNS.LAB_NAME_ID}`,
        params.lab_id
      );

    if (params.lab_or_scan == 0 || params.lab_or_scan == 1) {
      query.where(function () {
        this.where(LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN, 0).orWhere(
          LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN,
          2
        );
      });
    }
    if (params.lab_or_scan == 2) {
      query.where(function () {
        this.where(LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN, params.lab_or_scan);
      });
    }

    // Check if search term is provided and longer than and equal to 3 characters

    if (params.search && params.search.length >= 3) {
      query.where(function () {
        this.where(
          SCAN_TEST_MASTER.COLUMNS.SCAN_TEST_NAME,
          "like",
          `%${params.search}%`
        );
      });
    }
    logQuery({
      logger: fastify.log,
      query,
      context: "Get scan's tests",
      logTrace
    });
    const response = await query
      .orderBy(LAB_BASIC_INFO.COLUMNS.LAB_NAME, "ASC")
      .paginate({
        pageSize: params.page_size,
        currentPage: params.current_page
      });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "scan's tests not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    return response;
  }
  async function getHealthPackageByScan({ params, logTrace }) {
    const knex = this;
    const currentDate = new Date().toISOString(); // Get the current date in ISO format

    const query = knex
      .select([
        `${SCAN_TEST_PACK.NAME}.*`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_NAME}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ID} as lab_id `
      ])
      .from(`${SCAN_TEST_PACK.NAME} as ${SCAN_TEST_PACK.NAME}`)
      .leftJoin(
        `${LAB_BASIC_INFO.NAME} as ${LAB_BASIC_INFO.NAME}`,
        `${SCAN_TEST_PACK.NAME}.${SCAN_TEST_PACK.COLUMNS.LAB_NAME_ID}`,
        `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ID}`
      )
      .where(
        `${SCAN_TEST_PACK.NAME}.${SCAN_TEST_PACK.COLUMNS.LAB_NAME_ID}`,
        params.lab_id
      )
      .whereRaw(
        `? BETWEEN ${SCAN_TEST_PACK.NAME}.${SCAN_TEST_PACK.COLUMNS.VALID_FROM} AND ${SCAN_TEST_PACK.NAME}.${SCAN_TEST_PACK.COLUMNS.VALID_TO}`,
        [currentDate]
      );

    if (params.lab_or_scan == 0 || params.lab_or_scan == 1) {
      query.where(function () {
        this.where(LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN, 0).orWhere(
          LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN,
          2
        );
      });
    }
    if (params.lab_or_scan == 2) {
      query.where(function () {
        this.where(LAB_BASIC_INFO.COLUMNS.LAB_OR_SCAN, params.lab_or_scan);
      });
    }

    // Check if search term is provided and longer than and equal to 3 characters

    if (params.search && params.search.length >= 3) {
      query.where(function () {
        this.where(
          SCAN_TEST_PACK.COLUMNS.SCAN_PACK_NAME,
          "like",
          `%${params.search}%`
        );
      });
    }
    logQuery({
      logger: fastify.log,
      query,
      context: "Get scan's health packages",
      logTrace
    });
    const response = await query
      .orderBy(SCAN_TEST_PACK.COLUMNS.SCAN_PACK_NAME, "ASC")
      .paginate({
        pageSize: params.page_size,
        currentPage: params.current_page
      });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "scan's health packages not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    return response;
  }
  return {
    getScanByLab,
    getHealthPackageByScan
  };
}

module.exports = scanRepo;
