var axios = require('axios');

module.exports.send_otp = async (phno, otp) => {
    msg = 'Your OTP for Kovai Pazhamudir Nilayam online/Mobile app.registration is ' + otp + ' - Kovai Pazhamudir Nilayam'
    var config = {
        method: 'get',
        maxBodyLength: Infinity,
        url: 'http://www.bluekode.co.in/Smsserver/sms.aspx?cid=25&mobileno=' + phno + '&message=' + msg,
        headers: {}
    };

    await axios(config)
        .then(function (response) {
            if (response.data) {
                console.log("OTP sent for " + phno);
            }
        })
        .catch(function (error) {
            console.log(error);
        });
}