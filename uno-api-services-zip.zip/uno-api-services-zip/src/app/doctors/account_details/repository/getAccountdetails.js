const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { ACCOUNTDETAILS } = require("../commons/constant");
const { BANKMASTER  } = require("../commons/constant");


const { CustomError } = require("../../../errorHandler");
const fastify = require("fastify");

function allAccountDetail(fastify) {
    async function getAllAccount({ logTrace }) {
        const knex = this;
        const query = knex.select(`*`).from(`${ACCOUNTDETAILS.NAME}`);
        logQuery({
            logger: fastify.log,
            query,
            context: "Get Account details",
            logTrace
        });

        const response = await query;
        if (!response.length) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: "Account info not found",
                property: "",
                code: "NOT_FOUND"
            });
        }
        return response;
    }

    return {
        getAllAccount
    };
}

function allAccountDetailById(fastify) {
    async function getAllIdAccount({ logTrace,params }) {
        const knex = this;
        const doctor_id = params.doctor_id;
        const query = knex.select(`*`).from(`${ACCOUNTDETAILS.NAME}`)
        .where(`${ACCOUNTDETAILS.COLUMNS.DOCTOR_ID}`,doctor_id)
        logQuery({
            logger: fastify.log,
            query,
            context: "Get Account details",
            logTrace
        });
        const response = await query;
        if (!response.length) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: "Account info not found",
                property: "",
                code: "NOT_FOUND"
            });
        }
        return response;
    }
    async function getBankInfo({ bank_id, logTrace }) {
        const knex = fastify.knexMaster;
        const query = knex(BANKMASTER.NAME).where(
            BANKMASTER.COLUMNS.ID,
            bank_id
        );
        logQuery({
          logger: fastify.log,
          query,
          context: "Get bank details",
          logTrace
        });
        const response = await query;
        if (!response.length) {
          return [];
        }
        return response[0];
      }
      async function getNbBankInfo({ nb_bank_id, logTrace }) {
        const knex = fastify.knexMaster;
        const query = knex(BANKMASTER.NAME).where(
            BANKMASTER.COLUMNS.ID,
            nb_bank_id
        );
        logQuery({
          logger: fastify.log,
          query,
          context: "Get nb_bank details",
          logTrace
        });
        const response = await query;
        if (!response.length) {
          return [];
        }
        return response[0];
      }
    return {
        getAllIdAccount,
        getBankInfo,
        getNbBankInfo
    };
}

function accountPostRepo(fastify) {
    async function getAddAccount({ logTrace, body }) {
        const knex = this;
        const query = await knex(`${ACCOUNTDETAILS.NAME}`).insert({
            [ACCOUNTDETAILS.COLUMNS.DOCTOR_ID]: body.doctor_id,
            [ACCOUNTDETAILS.COLUMNS.HOLDER_NAME]: body.holder_name,
            [ACCOUNTDETAILS.COLUMNS.BANK_ID]: body.bank_id,
            [ACCOUNTDETAILS.COLUMNS.ACCOUNT_NO]: body.account_no,
            [ACCOUNTDETAILS.COLUMNS.IFSC_CODE]: body.ifsc_code,
            [ACCOUNTDETAILS.COLUMNS.UPI_IDS_GPAY]: body.upi_ids_gpay,
            [ACCOUNTDETAILS.COLUMNS.UPI_IDS_PHONEPE]: body.upi_ids_phonepe,
            [ACCOUNTDETAILS.COLUMNS.UPI_IDS_PAYTM]: body.upi_ids_paytm,
            [ACCOUNTDETAILS.COLUMNS.NB_HOLDER_NAME]: body.nb_holder_name,
            [ACCOUNTDETAILS.COLUMNS.NB_BANK_ID]: body.nb_bank_id,
            [ACCOUNTDETAILS.COLUMNS.NB_ACCOUNT_NO]: body.nb_account_no,
            [ACCOUNTDETAILS.COLUMNS.NB_IFSC_CODE]: body.nb_ifsc_code,
            [ACCOUNTDETAILS.COLUMNS.CUSTOMER_NO]: body.customer_no,
            [ACCOUNTDETAILS.COLUMNS.IS_SAVE_CURRENT]: body.is_save_current,
            [ACCOUNTDETAILS.COLUMNS.IS_NBSAVE_CURRENT]: body.is_nbsave_current,
            [ACCOUNTDETAILS.COLUMNS.ACTIVE]: body.active
        
        });

        const response = await query;

        return { success: true, message: "Insert successfully" };
    }

    return {
        getAddAccount
    };
}

function accountPutRepo(fastify) {
    async function getPutAccount({ logTrace, body, params }) {
        const knex = this;
        const doctor_id = params.doctor_id;
        const query = await knex(`${ACCOUNTDETAILS.NAME}`)
            .where(`${ACCOUNTDETAILS.COLUMNS.DOCTOR_ID}`, doctor_id)
            .update({
                [ACCOUNTDETAILS.COLUMNS.DOCTOR_ID]: body.doctor_id,
                [ACCOUNTDETAILS.COLUMNS.HOLDER_NAME]: body.holder_name,
                [ACCOUNTDETAILS.COLUMNS.BANK_ID]: body.bank_id,
                [ACCOUNTDETAILS.COLUMNS.ACCOUNT_NO]: body.account_no,
                [ACCOUNTDETAILS.COLUMNS.IFSC_CODE]: body.ifsc_code,
                [ACCOUNTDETAILS.COLUMNS.UPI_IDS_GPAY]: body.upi_ids_gpay,
                [ACCOUNTDETAILS.COLUMNS.UPI_IDS_PHONEPE]: body.upi_ids_phonepe,
                [ACCOUNTDETAILS.COLUMNS.UPI_IDS_PAYTM]: body.upi_ids_paytm,
                [ACCOUNTDETAILS.COLUMNS.NB_HOLDER_NAME]: body.nb_holder_name,
                [ACCOUNTDETAILS.COLUMNS.NB_BANK_ID]: body.nb_bank_id,
                [ACCOUNTDETAILS.COLUMNS.NB_ACCOUNT_NO]: body.nb_account_no,
                [ACCOUNTDETAILS.COLUMNS.NB_IFSC_CODE]: body.nb_ifsc_code,
                [ACCOUNTDETAILS.COLUMNS.CUSTOMER_NO]: body.customer_no,
                [ACCOUNTDETAILS.COLUMNS.IS_SAVE_CURRENT]: body.is_save_current,
                [ACCOUNTDETAILS.COLUMNS.IS_NBSAVE_CURRENT]: body.is_nbsave_current,
                [ACCOUNTDETAILS.COLUMNS.ACTIVE]: body.active
            });

        const response = await query;

        return { success: true, message: "Updated successfully" };
    }

    return {
        getPutAccount
    };
}

function accountDeleteRepo(fastify) {
    async function getAccountDelete({ logTrace, body, params, userDetails }) {
        const knex = this;

        const { id } = params;

        const query = await knex(`${ACCOUNTDETAILS.NAME}`)
            .where(`${ACCOUNTDETAILS.COLUMNS.ID}`, id)
            .del();

        const response = await query;

        return { success: true, message: "Deleted successfully" };
    }

    return {
        getAccountDelete
    };
}

module.exports = {
    allAccountDetail,
    accountPostRepo,
    accountPutRepo,
    accountDeleteRepo,
    allAccountDetailById
}