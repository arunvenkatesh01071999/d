const patchProductImage = require("./patchProductImage");

module.exports = {
  patchProductImage
};
