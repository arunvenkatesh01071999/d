const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postCardMasterSchema = {
  tags: ["CARD MASTERS"],
  summary: "This API is to post card masters",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "card_type",
      "card_value",
      "validity_months",
      "consult_offer",
      "lab_offer",
      "scan_offer",
      "active"
    ],
    properties: {
      card_type: { type: "string" },
      card_value: { type: "number" },
      validity_months: { type: "integer" },
      consult_offer: { type: "number" },
      lab_offer: { type: "number" },
      scan_offer: { type: "number" },
      active: { type: "boolean" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postCardMasterSchema;
