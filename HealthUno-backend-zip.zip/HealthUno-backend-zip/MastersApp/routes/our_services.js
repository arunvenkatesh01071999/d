const express = require('express');
const router = express();
const OurServicesController = require('../controller/OurServicesController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, OurServicesController.FetchOurServices);
router.get('/:id', verify_token, OurServicesController.FetchOurServices);
router.post('/', verify_token, OurServicesController.NewOurServices);
router.put('/:id', verify_token, OurServicesController.UpdateOurServices);
router.delete('/:id', verify_token, OurServicesController.DeleteOurServices);

module.exports = router;