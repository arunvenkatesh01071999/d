const bannerBasicInfo = require("../repository/bannerBasicInfo");
const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getbannerBasicInfoService(fastify) {
  const { getBannerBasicInfo } =
    bannerBasicInfo.bannerallBasicInfoRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getBannerBasicInfo.call(knex, {
      logTrace
    });

    const [getBannerBasicInfodata] = await Promise.all([promise1]);

    return getBannerBasicInfodata;
  };
}

function getbannerBasicInfoByIdService(fastify) {
  const { getBannerBasicInfoById } =
    bannerBasicInfo.bannerallBasicInfoByIdRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getBannerBasicInfoById.call(knex, {
      logTrace, params
    });

    const [getBannerBasicInfodata] = await Promise.all([promise1]);

    return getBannerBasicInfodata;
  };
}




// function getbannerpostBasicInfoService(fastify) {
//   const { getpostBannerBasicInfo } =
//     bannerBasicInfo.bannerallBasicInfoRepos(fastify);

//   return async ({ body, params, logTrace, convertedData, userDetails }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getpostBannerBasicInfo.call(knex, {
//       logTrace, body, convertedData,
//       userDetails
//     });

//     const [getpostBannerBasicInfodata] =
//       await Promise.all([promise1]);

//     return getpostBannerBasicInfodata
//   };
// }

function getbannerpostBasicInfoService(fastify) {
  const { getpostBannerBasicInfo } =
    bannerBasicInfo.bannerallBasicInfoRepos(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getpostBannerBasicInfo.call(knex, {
      logTrace, body,
      userDetails
    });
    const [getpostBannerBasicInfodata] =
      await Promise.all([promise1]);
    return getpostBannerBasicInfodata
  };
}


// function getbannerputBasicInfoService(fastify) {
//   const { getputBannerBasicInfo } =
//     bannerBasicInfo.bannerputBasicInfoRepos(fastify);

//   return async ({ body, params, logTrace, userDetails, convertedData, }) => {
//     const knex = fastify.knexMaster;
//     const promise1 = getputBannerBasicInfo.call(knex, {
//       logTrace, convertedData,
//       body,
//       params,
//       userDetails
//     });

//     const [getputBannerBasicInfodata] = await Promise.all([promise1]);

//     return getputBannerBasicInfodata;
//   };
// }

function getbannerputBasicInfoService(fastify) {
  const { getputBannerBasicInfo } =
    bannerBasicInfo.bannerputBasicInfoRepos(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getputBannerBasicInfo.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });
    const [getputBannerBasicInfodata] = await Promise.all([promise1]);
    return getputBannerBasicInfodata;
  };
}

function getbannerdeleteBasicInfoService(fastify) {
  const { getdeleteBannerBasicInfo } =
    bannerBasicInfo.bannerdeleteBasicInfoRepos(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getdeleteBannerBasicInfo.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });

    const [getdeleteBannerBasicInfodata] = await Promise.all([promise1]);

    return getdeleteBannerBasicInfodata;
  };
}

module.exports = {
  getbannerBasicInfoService,
  getbannerBasicInfoByIdService,
  getbannerpostBasicInfoService,
  getbannerputBasicInfoService,
  getbannerdeleteBasicInfoService
};
