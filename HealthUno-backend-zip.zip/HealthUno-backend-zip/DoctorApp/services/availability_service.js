const AvailabilityInfo = require('../models/AvailabilityModel');
const SecondOpinion = require('../models/SecondOpinionModel');


const Get = async () => {
    await AvailabilityInfo.findAll({
        include: SecondOpinion
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (doctor_name_id) => {
    await AvailabilityInfo.findAll({
        where: { doctor_name_id: doctor_name_id }, include: SecondOpinion
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (doctor_name_id) => {
    await AvailabilityInfo.findAll({ where: { doctor_name_id: doctor_name_id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateAvailabilityInfo = async (s_data) => {
    await AvailabilityInfo.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateAvailabilityInfo = async (id, s_data) => {
    await AvailabilityInfo.update(s_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DeleteAvailabilityInfo = async (id) => {
    await AvailabilityInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateAvailabilityInfo,
    UpdateAvailabilityInfo,
    DeleteAvailabilityInfo,
};
