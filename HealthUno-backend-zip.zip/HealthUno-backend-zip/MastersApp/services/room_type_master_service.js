const RoomTypeMaster = require('../models/RoomTypeMasterModel');

const Get = async () => {
    await RoomTypeMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await RoomTypeMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await RoomTypeMaster.findAll({ where: { roomType_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateRoomType = async (r_data) => {
    await RoomTypeMaster.create(r_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateRoomType = async (id, r_data) => {
    await RoomTypeMaster.update(r_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyRoomType = async (id) => {
    await RoomTypeMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateRoomType,
    UpdateRoomType,
    DestroyRoomType
};
