const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const consultFeeType = require('../../MastersApp/models/FeesTypeMasterModel')

const PaymentInfo = sequelize.define("h_payment_info", {
    fees_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "fees_type_id is required"
            }
        }
    },
    fees_amt: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "fees_amt is required"
            }
        }
    },
    commision: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    check: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    N_display_amt: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    N_commision: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    N_payout: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    s_display_amt: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    s_commision: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    s_payout: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });



PaymentInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_payment_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

PaymentInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_payment_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


PaymentInfo.belongsTo(consultFeeType, { foreignKey: 'fees_type_id' });


module.exports = PaymentInfo;