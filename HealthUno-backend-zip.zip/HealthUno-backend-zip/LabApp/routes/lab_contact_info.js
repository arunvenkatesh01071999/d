const express = require('express');
const router = express();
const LabContactInfoController = require('../../LabApp/controller/LabContactInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabContactInfoController.FetchLabContactInfo);
router.get('/:lab_name_id', verify_token, LabContactInfoController.FetchLabContactInfo);
router.post('/', verify_token, LabContactInfoController.NewLabContactInfo);
router.put('/:id', verify_token, LabContactInfoController.UpdateLabContactInfo);
router.delete('/:id', verify_token, LabContactInfoController.DeleteLabContactInfo);


module.exports = router;