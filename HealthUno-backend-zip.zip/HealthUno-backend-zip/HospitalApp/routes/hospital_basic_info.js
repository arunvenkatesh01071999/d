// const express = require('express');
// const router = express();
// const HospitalBasicInfoController = require('../../HospitalApp/controller/HospitalBasicInfoController');
// const verify_token = require('../../services/verify_token')

// router.get('/', verify_token, HospitalBasicInfoController.FetchHospitalBasicInfo);
// router.get('/:id', verify_token, HospitalBasicInfoController.FetchHospitalBasicInfo);
// router.post('/', verify_token, HospitalBasicInfoController.NewHospitalBasicInfo);
// router.put('/:id', verify_token, HospitalBasicInfoController.UpdateHospitalBasicInfo);
// router.put('/approve/:id', verify_token, HospitalBasicInfoController.HospitalApprove);
// router.put('/approve/updated/:id', verify_token, HospitalBasicInfoController.UpdateforApprove);

// module.exports = router; 

const express = require('express');
const router = express();
const HospitalBasicInfoController = require('../../HospitalApp/controller/HospitalBasicInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, HospitalBasicInfoController.FetchHospitalBasicInfo);
router.get('/:id', HospitalBasicInfoController.FetchHospitalBasicInfo);
router.get('/user/:user_id', verify_token, HospitalBasicInfoController.fetchhosnameid);
router.post('/', HospitalBasicInfoController.NewHospitalBasicInfo);
router.put('/:id',  HospitalBasicInfoController.UpdateHospitalBasicInfo);
router.put('/approve/:id', verify_token, HospitalBasicInfoController.HospitalApprove);
router.put('/approve/updated/:id', verify_token, HospitalBasicInfoController.UpdateforApprove);

module.exports = router; 