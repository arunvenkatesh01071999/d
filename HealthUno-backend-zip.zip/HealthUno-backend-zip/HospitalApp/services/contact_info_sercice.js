const ContactInfo = require('../models/ContactInfoModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');

const Get = async () => {
    await ContactInfo.findAll({ include: [HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (hospital_name_id) => {
    // await ContactInfo.findAll({ where: { id: id }, include: [HospitalInfo], raw: true })
    await ContactInfo.findAll({ where: { hospital_name_id: hospital_name_id }, include: [HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const CreateContact = async (c_data) => {
    await ContactInfo.create(c_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const GetId = async (id) => {
    await ContactInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const UpdateContact = async (id, c_data) => {
    await ContactInfo.update(c_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyContact = async (id) => {
    await ContactInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateContact,
    UpdateContact,
    DestroyContact
};