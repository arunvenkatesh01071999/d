const getPatientDetailsRepository = require("../repository/getPatientDetailsRepository");
const reschedulesms = require("../../../notification/repository/reschedulesms");
const patientcancelnotify = require("../../../notification/repository/patientcancelnotify");
const cancelbookingsms = require("../../../notification/repository/cancelbookingsms");

function getPatientDetailsInfoServicePost(fastify) {
  const { PatientDetailsGetOne } =
    getPatientDetailsRepository.getPatientDetailsPost(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = PatientDetailsGetOne.call(knex, {
      logTrace,
      body,
      params
    });
    const [getPatientDetailsOnedata] = await Promise.all([promise1]);

    return getPatientDetailsOnedata;
  };
}

function getreschedulepostInfoServicePost(fastify) {
  const { reschedulepost } =
    getPatientDetailsRepository.getreschedulepostDetailsPost(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = reschedulepost.call(knex, {
      logTrace,
      body,
      params
    });
    const [reschedulepostdata] = await Promise.all([promise1]);
    return reschedulepostdata;
  };
}

function getreschedulepostInfoServicev2versionPost(fastify) {
  const { reschedulepostv2 } =
    getPatientDetailsRepository.getreschedulepostv2DetailsPost(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = reschedulepostv2.call(knex, {
      logTrace,
      body,
      params
    });
    const [reschedulepostv2data] = await Promise.all([promise1]);
    return reschedulepostv2data;
  };
}

function getreschedulefinalPost(fastify) {
  const { reschedulepostfinal, getDoctorInfo, getPatientInfo } =
    getPatientDetailsRepository.getreschedulepostfinal(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = reschedulepostfinal.call(knex, {
      logTrace,
      body,
      params
    });

    let doctor_id = body.doctor_id;
    let patient_id = body.patient_id;
    const docInfo = await getDoctorInfo({ doctor_id, logTrace });
    const patientInfo = await getPatientInfo.call(knex, {
      patient_id,
      logTrace
    });

    const { rescheduleSms } = reschedulesms(fastify);
    let phone_number = patientInfo.mobile;
    let date = body.appointment_date;
    let time = body.appointment_from_time;
    let doctor_name = docInfo.doctor_name;
    const pat_promise = rescheduleSms(phone_number, doctor_name, date, time);
    const [reschedulepostfinaldata] = await Promise.all([promise1]);
    return reschedulepostfinaldata;
  };
}

function getcancelPost(fastify) {
  const { cancelpostfinal, getPatientInfo, getDoctorInfo } =
    getPatientDetailsRepository.getcancelpostfinal(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = cancelpostfinal.call(knex, {
      logTrace,
      body,
      params
    });

    let doctor_id = body.doctor_id;
    let patient_id = body.patient_id;
    const docInfo = await getDoctorInfo({ doctor_id, logTrace });
    const patientInfo = await getPatientInfo.call(knex, {
      patient_id,
      logTrace
    });

    const { patientNotifySms } = patientcancelnotify(fastify); //Patient
    const { cancelBookingSms } = cancelbookingsms(fastify); //Dr.
    let phone_number = patientInfo.mobile;
    let patient_name = patientInfo.name;
    let date = body.appointment_date;
    let time = body.appointment_from_time;
    let doctor_name = docInfo.doctor_name;

    const pat_promise = patientNotifySms(phone_number, date, time);

    phone_number = docInfo.phone_no;
    const doctor_promise = cancelBookingSms(
      phone_number,
      doctor_name,
      patient_name
    );

    const [cancelpostfinaldata] = await Promise.all([promise1]);
    return cancelpostfinaldata;
  };
}

function getPatientDetailsDateFilterInfoServicePost(fastify) {
  const { patientfilterwithdatefilter } =
    getPatientDetailsRepository.getpatientwithfilter(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = patientfilterwithdatefilter.call(knex, {
      logTrace,
      body,
      params
    });
    const [patientfilterwithdatefilterdata] = await Promise.all([promise1]);
    return patientfilterwithdatefilterdata;
  };
}

function getPatientDetailsInfoServicePostImg(fastify) {
  const { PatientDetailsGetOnePostImg } =
    getPatientDetailsRepository.getPatientDetailsRepositoryPostImg(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexPatient;
    const promise1 = PatientDetailsGetOnePostImg.call(knex, {
      logTrace,
      params,
      body
    });
    const [getPatientDetailsOnedata] = await Promise.all([promise1]);
    return getPatientDetailsOnedata;
  };
}

function getPatientDetailsDateFilterInfoServicePost(fastify) {
  const { patientfilterwithdatefilter } =
    getPatientDetailsRepository.getpatientwithfilter(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = patientfilterwithdatefilter.call(knex, {
      logTrace,
      body,
      params
    });
    const [patientfilterwithdatefilterdata] = await Promise.all([promise1]);
    return patientfilterwithdatefilterdata;
  };
}
function getPatientDetailsWithEhrInfoServicePost(fastify) {
  const { patientalldetailswithehr } =
    getPatientDetailsRepository.getPatientDetailsWithEhrPost(fastify);

  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = patientalldetailswithehr.call(knex, {
      logTrace,
      body,
      params
    });
    const [patientalldetailswithehrdata] = await Promise.all([promise1]);
    return patientalldetailswithehrdata;
  };
}

function getCancelAppointmentwithReasonService(fastify) {
  const { getCancelAppointmentwithReasonGetOne, getNumberInfo } =
    getPatientDetailsRepository.getCancelAppointmentwithReasonRepo(fastify);
  return async ({ params, logTrace, body }) => {
    const knexPatient = fastify.knexPatient;
    const promise1 = getCancelAppointmentwithReasonGetOne.call(knexPatient, {
      logTrace,
      body,
      params
    });
    const [getCancelAppointmentwithReasonOnedata] = await Promise.all([
      promise1
    ]);
    const transformedResponse = {
      data: await Promise.all(
        getCancelAppointmentwithReasonOnedata.map(async details => {
          var patient_id = details.patient_id;
          const patientNumber = await getNumberInfo({ patient_id, logTrace });
          return {
            ...details,
            patientNumber: patientNumber
          };
        })
      )
    };
    return transformedResponse;
  };
}
function getPatientDetailsDateFilterOverallCompleteInfoServicePost(fastify) {
  const { patientfilterwithdatefilterOverallComplete } =
    getPatientDetailsRepository.getpatientwithfilterOverallComplete(fastify);
  return async ({ params, logTrace, body }) => {
    const knex = fastify.knexMaster;
    const promise1 = patientfilterwithdatefilterOverallComplete.call(knex, {
      logTrace,
      body,
      params
    });
    const [patientfilterwithdatefilterOverallCompletedata] = await Promise.all([promise1]);
    return patientfilterwithdatefilterOverallCompletedata;
  };
}

module.exports = {
  getPatientDetailsDateFilterInfoServicePost,
  getPatientDetailsInfoServicePostImg,
  getPatientDetailsInfoServicePost,
  getreschedulepostInfoServicePost,
  getreschedulefinalPost,
  getcancelPost,
  getPatientDetailsWithEhrInfoServicePost,
  getCancelAppointmentwithReasonService,
  getreschedulepostInfoServicev2versionPost,
  getPatientDetailsDateFilterOverallCompleteInfoServicePost
};
