const express = require('express');
const router = express();
const CouncilMasterController = require('../controller/CouncilController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, CouncilMasterController.FetchCouncil);
router.get('/:id', verify_token, CouncilMasterController.FetchCouncil);
router.post('/', verify_token, CouncilMasterController.NewCouncil);
router.put('/:id', verify_token, CouncilMasterController.UpdateCouncil);
router.delete('/:id', verify_token, CouncilMasterController.DeleteCouncil);

module.exports = router;