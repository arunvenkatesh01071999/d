const EXPINFO = {
  NAME: "d_experience_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    SPECIALIZATION_ID: "specialization_id",
    DEPARTMENT_ID: "department_id",
    UPLOAD_CERTIFICATE: "upload_certicate",
    EXPERIENCE: "experience",
    SPECIALIZED_FILE: "specialized_file",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }


};

const SPECIALITY = {
  NAME: "specialities",
  COLUMNS: {
    ID: "id",
    SPECIALITY_NAME: "speciality_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
}

const EDUCATIONINFO = {
  NAME: "d_education_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    QUALIFICATION_NAME_ID: "qualification_name_id",
    CERTIFICATE_PATH: "certificate_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    YOP: "yop",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }


};

const COUNCILINFO = {
  NAME: "d_council_info",
  COLUMNS: {
    ID: "id",
    COUNCIL_ID: "council_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    REGISTRATION_NO: "registration_no",
    REGISTRATION_DATE: "registration_date",
    RENEWAL_DATE: "renewal_date",
    CERTIFICATE_PATH: "certificate_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",

  }

};

module.exports = {
  EXPINFO,
  EDUCATIONINFO,
  COUNCILINFO,
  SPECIALITY
};

