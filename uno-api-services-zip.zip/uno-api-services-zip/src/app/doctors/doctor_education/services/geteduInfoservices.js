const EduBasicInfo = require("../repository/EduInfoRespo");
const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");
function getalleduService(fastify) {
  const { getedueall } = EduBasicInfo.EduAllRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getedueall.call(knex, {
      logTrace
    });
    const [geteduealldata] = await Promise.all([promise1]);
    return geteduealldata;
  };
}
function getByIdeduService(fastify) {
  const { geteduById } = EduBasicInfo.EduGetByIdRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = geteduById.call(knex, {
      logTrace, body, params
    });
    const [geteduByIddata] = await Promise.all([promise1]);
    return geteduByIddata;
  };
}

function getPosteduService(fastify) {
  const { geteduadd } = EduBasicInfo.EduPostRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = geteduadd.call(knex, {
      logTrace, params, 
      body
    });
    const [geteduadddata] = await Promise.all([promise1]);
    return geteduadddata;
  };
}

function getPuteduService(fastify) {
  const { geteduput } = EduBasicInfo.EduPutRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = geteduput.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });
    const [geteduputdata] = await Promise.all([promise1]);
    return geteduputdata;
  };
}
function getDeleteeduService(fastify) {
  const { getedudelete } =
    EduBasicInfo.EduDeleteRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getedudelete.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });
    const [getedudeletedata] = await Promise.all([promise1]);
    return getedudeletedata;
  };
}
     
      function getGenerateotpService(fastify) {
  const { getotp } =
    EduBasicInfo.generateotpRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getotp.call(knex, {
      // logTrace,
      body,
      params,
      userDetails
    });
    const phone = body.mobile;
    // if (!phone.match(phoneRegex)) {
    //   return "invalid phone number";
    // }
    try {
      const [getedudeletedata] = await Promise.all([promise1]);
      return getedudeletedata;
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Failed to generate OTP.' });
    }
  };
}

function getcheckotpService(fastify) {
  const { getotpcheck } =
    EduBasicInfo.checkotpRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getotpcheck.call(knex, {
      // logTrace,
      body,
      params,
      userDetails
    });
    const phone = body.mobile;
    // if (!phone.match(phoneRegex)) {
    //   return "invalid phone number";
    // }
    try {
      const [getregdeletedata] = await Promise.all([promise1]);
      return getregdeletedata;
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Failed to generate OTP.' });
    }
  };
}

module.exports = {
  getalleduService,
  getByIdeduService,
  getPosteduService,
  getPuteduService,
  getDeleteeduService,
  getGenerateotpService,
  getcheckotpService
};