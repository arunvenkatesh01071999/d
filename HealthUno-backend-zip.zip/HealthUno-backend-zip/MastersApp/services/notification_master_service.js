const NotificationMaster = require('../models/NotificationMasterModel');

const Get = async () => {
    await NotificationMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await NotificationMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await NotificationMaster.findAll({ where: { notification_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateNotificationMaster = async (nm_data) => {
    await NotificationMaster.create(nm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateNotificationMaster = async (id, nm_data) => {
    await NotificationMaster.update(nm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyNotificationMaster = async (id) => {
    await NotificationMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateNotificationMaster,
    UpdateNotificationMaster,
    DestroyNotificationMaster
};
