const ConsultationSlotsDuration = require('../models/ConsultationSlotsModel');

const Get = async () => {
    await ConsultationSlotsDuration.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await ConsultationSlotsDuration.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateConsultationSlotsDuration = async (cs_data) => {
    await ConsultationSlotsDuration.create(cs_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateConsultationSlotsDuration = async (id, cs_data) => {
    await ConsultationSlotsDuration.update(cs_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyConsultationSlotsDuration = async (id) => {
    await ConsultationSlotsDuration.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateConsultationSlotsDuration,
    UpdateConsultationSlotsDuration,
    DestroyConsultationSlotsDuration
};
