const express = require('express');
const app = express();

const LabBasicInfoRouter = require('./routes/lab_basic_info');
const LabAddressInfoRouter = require('./routes/lab_address_info');
const LabContactInfoRouter = require('./routes/lab_contact_info');
const LabServiceInfoRouter = require('./routes/lab_service_info');
const LabOfficeUseRouter = require('./routes/lab_office_use');
const LabScanInfoRouter = require('./routes/lab_scan_info');
const LabTermInfoRouter = require('./routes/lab_terms_info');
const LabInfoRouter = require('./routes/lab_info');
const LabRepositoryInfoRouter = require('./routes/lab_repository_info');
const LabInchargeInfoRouter = require('./routes/lab_incharge_info');
const LabTestPackRouter = require('./routes/lab_test_package-info');
const LabScanPackRouter = require('./routes/lab_scan_test_pack_info');
const LabServiceOffRouter = require('./routes/lab_service_offer');
const LabScaninfo = require('../LabApp/routes/lab_addCheck');

app.use('/lab-basic-info', LabBasicInfoRouter);
app.use('/l-address-info', LabAddressInfoRouter);
app.use('/l-contact-info', LabContactInfoRouter);
app.use('/l-lab-service', LabServiceInfoRouter);
app.use('/l-office-use', LabOfficeUseRouter);
app.use('/l-scan-info', LabScanInfoRouter);
app.use('/l-terms-condition', LabTermInfoRouter);
app.use('/l-lab-info', LabInfoRouter);
app.use('/l-repository-info', LabRepositoryInfoRouter);
app.use('/lab-incharge-info', LabInchargeInfoRouter);
app.use('/l-lab-test-info', LabTestPackRouter);
app.use('/l-lab-scan-test', LabScanPackRouter);
app.use('/l-offer-service', LabServiceOffRouter);
app.use('/Lab-Pass',LabScaninfo);

module.exports = app;