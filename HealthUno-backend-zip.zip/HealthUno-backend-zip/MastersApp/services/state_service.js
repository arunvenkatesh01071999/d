const State = require('../models/StateModel');
const countryMaster = require('../../MastersApp/models/CountryModel')

const Get = async () => {
    await State.findAll({ include: [countryMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await State.findAll({ where: { id: id }, include: [countryMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateState = async (s_data) => {
    await State.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateState = async (id, s_data) => {
//     await State.update(s_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

const FetchByCountryId = async (country_id) => {
    await State.findAll({ where: { country_id: country_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateState,
    // UpdateState,
    FetchByCountryId
};
