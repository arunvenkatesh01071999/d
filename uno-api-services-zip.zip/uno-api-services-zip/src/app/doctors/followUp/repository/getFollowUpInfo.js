const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { FOLLOWUP } = require("../commons/constant");
const { PATIENTFILEDETAILS } = require("../commons/constant");
const { PAITENTBOOKINGINFO } = require("../commons/constant");
const { PASTMEDICALHISTORY } = require("../commons/constant");
const { CHEIFCOMPLAINTS } = require("../commons/constant");
const { CLINICALEXAM } = require("../commons/constant");
const { EXAMINATORY } = require("../commons/constant");
const { PROVISIONAL } = require("../commons/constant");
const { LABINVESTIGATION } = require("../commons/constant");
const { FINALDIAGNOSIS } = require("../commons/constant");
const { SURGICAL } = require("../commons/constant");
const { OTHERTREATMENT } = require("../commons/constant");
const { PRESCRIPTION } = require("../commons/constant");
const { PRESCRIPTIONMEDICINE } = require("../commons/constant");
const { EHRUNIQUE } = require("../commons/constant");

const { CustomError } = require("../../../errorHandler");
const fastify = require("fastify");


function followupRepo(fastify) {
    async function getAddFollow({ logTrace, body }) {
       
        const knex = this;
        const knexMaster = fastify.knexMaster;

        const patient_id = body.patient_id;

        const doctor_id = body.doctor_id;

        const query = await knex.raw(`select top 1 * from patient_booking
        where patient_id = ${patient_id} and doctor_id = ${doctor_id} order By id desc`);
        const paitent_booking_id=query[0].id;

        const query1 = await knex(`${PAITENTBOOKINGINFO.NAME}`)
        .where(`${PAITENTBOOKINGINFO.COLUMNS.ID}`, paitent_booking_id)
        .update({
          [PAITENTBOOKINGINFO.COLUMNS.IS_FOLLOWUP]:1,
        });

        // const query2 = await knex.raw(`update patient_booking set is_followup = 1 where id = ${id}`);

        const query3 = await knexMaster(`${FOLLOWUP.NAME}`).insert({
            [FOLLOWUP.COLUMNS.DOCTOR_ID]: body.doctor_id,
            [FOLLOWUP.COLUMNS.PATIENT_ID]: body.patient_id,
            [FOLLOWUP.COLUMNS.PATIENT_APPOINTMENT_ID]: paitent_booking_id,
            [FOLLOWUP.COLUMNS.FOLLOWUP_DATE]: body.followup_date,
            [FOLLOWUP.COLUMNS.ADDITIONAL_NOTES]: body.additional_notes,
            [FOLLOWUP.COLUMNS.ACTIVE]: body.active
        });
        // const response = await query2;
        return { success: true, message: "Insert successfully" };
    }
    return {
        getAddFollow
    };
}

function getAddEhrSubmitRepo(fastify) {
    async function getAddEhrSubmit({ logTrace, body }) {
        const knex = this;
        const knexMaster = fastify.knexMaster;

        const patient_id = body.patient_id;
        const doctor_id = body.doctor_id;
        const file_path = body.file_path;
        const through_vc= parseInt(body.through_vc);

        if(through_vc===0){
            var appointment_date=body.appointment_date?body.appointment_date:0;
            var appointment_from_time=body.appointment_from_time?body.appointment_from_time:0;
            var  hospitalcounsul_or_videoconsul=body.hospitalcounsul_or_videoconsul?body.hospitalcounsul_or_videoconsul:0;
        }
      
     
        // if (!patient_id) {
        //     throw CustomError.create({
        //       httpCode: StatusCodes.NOT_FOUND,
        //       message: "Please Select Patient",
        //       property: "",
        //       code: "NOT_FOUND"
        //     });
        //   }


        const query1 = await knexMaster.select('*').from(CHEIFCOMPLAINTS.NAME)
        .where(CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID, patient_id)
        .andWhere(CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID, doctor_id)
        .andWhere(CHEIFCOMPLAINTS.COLUMNS.END_CONSULTATION, 0)
        .orderBy(CHEIFCOMPLAINTS.COLUMNS.ID, 'desc')
        .limit(1);

            if(query1.length!=0){
                const cheif_data =query1[0].id;

                const query = await knexMaster(`${CHEIFCOMPLAINTS.NAME}`)
                .where(`${CHEIFCOMPLAINTS.COLUMNS.ID}`, cheif_data)
                .update({
                  [CHEIFCOMPLAINTS.COLUMNS.END_CONSULTATION]: 1,
                });

            }

            const query2 = await knexMaster.select('*').from(PASTMEDICALHISTORY.NAME)
            .where(PASTMEDICALHISTORY.COLUMNS.PATIENT_ID, patient_id)
            .andWhere(PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID, doctor_id)
            .andWhere(PASTMEDICALHISTORY.COLUMNS.END_CONSULTATION, 0)
            .orderBy(PASTMEDICALHISTORY.COLUMNS.ID, 'desc')
            .limit(1);

                if(query2.length!=0){
                    const past_data =query2[0].id;
    
                    const query_past = await knexMaster(`${PASTMEDICALHISTORY.NAME}`)
                    .where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, past_data)
                    .update({
                      [PASTMEDICALHISTORY.COLUMNS.END_CONSULTATION]: 1,
                    });
                    const respons_past = await query_past;
                }


                const query3 = await knexMaster.select('*').from(CLINICALEXAM.NAME)
                .where(CLINICALEXAM.COLUMNS.PATIENT_ID, patient_id)
                .andWhere(CLINICALEXAM.COLUMNS.DOCTOR_ID, doctor_id)
                .andWhere(CLINICALEXAM.COLUMNS.END_CONSULTATION, 0)
                .orderBy(CLINICALEXAM.COLUMNS.ID, 'desc')
                .limit(1);
        
                    if(query3.length!=0){
                        const clinic_data =query3[0].id;
        
                        const clinc_query = await knexMaster(`${CLINICALEXAM.NAME}`)
                        .where(`${CLINICALEXAM.COLUMNS.ID}`, clinic_data)
                        .update({
                          [CLINICALEXAM.COLUMNS.END_CONSULTATION]: 1,
                        });
                        const clinc_past = await clinc_query;
                    }

                    const query4 = await knexMaster.select('*').from(EXAMINATORY.NAME)
                    .where(EXAMINATORY.COLUMNS.PATIENT_ID, patient_id)
                    .andWhere(EXAMINATORY.COLUMNS.DOCTOR_ID, doctor_id)
                    .andWhere(EXAMINATORY.COLUMNS.END_CONSULTATION, 0)
                    .orderBy(EXAMINATORY.COLUMNS.ID, 'desc')
                    .limit(1);
            
                        if(query4.length!=0){
                            const examinatory_data =query4[0].id;
            
                            const examinatory_query = await knexMaster(`${EXAMINATORY.NAME}`)
                            .where(`${EXAMINATORY.COLUMNS.ID}`, examinatory_data)
                            .update({
                              [EXAMINATORY.COLUMNS.END_CONSULTATION]: 1,
                            });
                            const examinatory_past = await examinatory_query;
                        }

                        const query5 = await knexMaster.select('*').from(PROVISIONAL.NAME)
                        .where(PROVISIONAL.COLUMNS.PATIENT_ID, patient_id)
                        .andWhere(PROVISIONAL.COLUMNS.DOCTOR_ID, doctor_id)
                        .andWhere(PROVISIONAL.COLUMNS.END_CONSULTATION, 0)
                        .orderBy(PROVISIONAL.COLUMNS.ID, 'desc')
                        .limit(1);
                
                            if(query5.length!=0){
                                const provisional_data =query5[0].id;
                
                                const provisional_query = await knexMaster(`${PROVISIONAL.NAME}`)
                                .where(`${PROVISIONAL.COLUMNS.ID}`, provisional_data)
                                .update({
                                  [PROVISIONAL.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const eprovisional_response = await provisional_query;
                            }

                            const query6 = await knexMaster.select('*').from(LABINVESTIGATION.NAME)
                            .where(LABINVESTIGATION.COLUMNS.PATIENT_ID, patient_id)
                            .andWhere(LABINVESTIGATION.COLUMNS.DOCTOR_ID, doctor_id)
                            .andWhere(LABINVESTIGATION.COLUMNS.END_CONSULTATION, 0)
                            .orderBy(LABINVESTIGATION.COLUMNS.ID, 'desc')
                            .limit(1);
                
                            if(query6.length!=0){
                                const labInvestigation_data =query6[0].id;
                
                                const query_labInvestigation = await knexMaster(`${LABINVESTIGATION.NAME}`)
                                .where(`${LABINVESTIGATION.COLUMNS.ID}`, labInvestigation_data)
                                .update({
                                  [LABINVESTIGATION.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const labInvestigation_response = await query_labInvestigation;
                            }


                            const query7 = await knexMaster.select('*').from(FINALDIAGNOSIS.NAME)
                            .where(FINALDIAGNOSIS.COLUMNS.PATIENT_ID, patient_id)
                            .andWhere(FINALDIAGNOSIS.COLUMNS.DOCTOR_ID, doctor_id)
                            .andWhere(FINALDIAGNOSIS.COLUMNS.END_CONSULTATION, 0)
                            .orderBy(FINALDIAGNOSIS.COLUMNS.ID, 'desc')
                            .limit(1);
                
                            if(query7.length!=0){
                                const finaldiag_data =query7[0].id;
                
                                const query_finaldiag= await knexMaster(`${FINALDIAGNOSIS.NAME}`)
                                .where(`${FINALDIAGNOSIS.COLUMNS.ID}`, finaldiag_data)
                                .update({
                                  [FINALDIAGNOSIS.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const finaldiag_response = await query_finaldiag;
                            }


                            const query8 = await knexMaster.select('*').from(SURGICAL.NAME)
                            .where(SURGICAL.COLUMNS.PATIENT_ID, patient_id)
                            .andWhere(SURGICAL.COLUMNS.DOCTOR_ID, doctor_id)
                            .andWhere(SURGICAL.COLUMNS.END_CONSULTATION, 0)
                            .orderBy(SURGICAL.COLUMNS.ID, 'desc')
                            .limit(1);
                
                            if(query8.length!=0){
                                const surgical_data =query8[0].id;
                
                                const query_surgical= await knexMaster(`${SURGICAL.NAME}`)
                                .where(`${SURGICAL.COLUMNS.ID}`, surgical_data)
                                .update({
                                  [SURGICAL.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const surgical_response = await query_surgical;
                            }
           
                            const query9 = await knexMaster.select('*').from(OTHERTREATMENT.NAME)
                            .where(OTHERTREATMENT.COLUMNS.PATIENT_ID, patient_id)
                            .andWhere(OTHERTREATMENT.COLUMNS.DOCTOR_ID, doctor_id)
                            .andWhere(OTHERTREATMENT.COLUMNS.END_CONSULTATION, 0)
                            .orderBy(OTHERTREATMENT.COLUMNS.ID, 'desc')
                            .limit(1);
                
                            if(query9.length!=0){
                                const treament_data =query9[0].id;
                
                                const query_treament = await knexMaster(`${OTHERTREATMENT.NAME}`)
                                .where(`${OTHERTREATMENT.COLUMNS.ID}`, treament_data)
                                .update({
                                  [OTHERTREATMENT.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const treament_response = await query_treament;
                            }

                            const query12 = await knexMaster.select('*').from(EHRUNIQUE.NAME)
                            .where(EHRUNIQUE.COLUMNS.PATIENT_ID, patient_id)
                            .andWhere(EHRUNIQUE.COLUMNS.DOCTOR_ID, doctor_id)
                            .andWhere(EHRUNIQUE.COLUMNS.END_CONSULTATION, 0)
                            .orderBy(EHRUNIQUE.COLUMNS.ID, 'desc')
                            .limit(1);
                
                
                            if(query12.length!=0){
                                const priscription_data =query12[0].id;
                
                                const query_priscription = await knexMaster(`${PRESCRIPTIONMEDICINE.NAME}`)
                                .where(`${PRESCRIPTIONMEDICINE.COLUMNS.FINAL_DIAGNOSIS_ID}`, priscription_data)
                                .update({
                                  [PRESCRIPTIONMEDICINE.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const query_priscription_response = await query_priscription;
                            }


                           
                            if(query12.length!=0){
                                const unique_data =query12[0].id;
                
                                const query_unique = await knexMaster(`${EHRUNIQUE.NAME}`)
                                .where(`${EHRUNIQUE.COLUMNS.ID}`, unique_data)
                                .update({
                                  [EHRUNIQUE.COLUMNS.END_CONSULTATION]: 1,
                                });
                                const unique_response = await query_unique;
                            }

                if(body.appointment_date!=0 && body.appointment_from_time!=0){
                    const query = await knex.raw(`select * from patient_booking
                    where patient_id = ${patient_id} and doctor_id = ${doctor_id} and appointment_date='${appointment_date}' and appointment_from_time='${appointment_from_time}' and hospitalcounsul_or_videoconsul =${hospitalcounsul_or_videoconsul}  order By id desc`);
                    if(query.length!=0){
                        const paitent_booking_id=query[0].id;

                        const follow_up_data=query[0].is_followup;
                        if(follow_up_data==0){
                            const query = await knex(`${PAITENTBOOKINGINFO.NAME}`)
                            .where(`${PAITENTBOOKINGINFO.COLUMNS.ID}`, paitent_booking_id)
                            .update({
                            [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]:3,
                            });
                        }
                        else{
                            const query = await knex(`${PAITENTBOOKINGINFO.NAME}`)
                            .where(`${PAITENTBOOKINGINFO.COLUMNS.ID}`, paitent_booking_id)
                            .update({
                            [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]: 1,
                            });
                        }


                    }
                }
        
                           
       

                    const query11 = await knex(`${PATIENTFILEDETAILS.NAME}`).insert({
                        [PATIENTFILEDETAILS.COLUMNS.DOCTOR_ID]: doctor_id,
                        [PATIENTFILEDETAILS.COLUMNS.PATIENT_ID]: patient_id,
                        [PATIENTFILEDETAILS.COLUMNS.PATIENT_FILE_PATH]: file_path,
                        [PATIENTFILEDETAILS.COLUMNS.FILE_FLAG]: 1, //1-ehr files,2-prescription,3-investifgation,4-diagnosis,5-lab test,6-scan report
                        [PATIENTFILEDETAILS.COLUMNS.ACTIVE]: body.active

                    });

                    const response = await query11;

                    return { success: true, message: "Insert successfully" };

    }

    return {
        getAddEhrSubmit
    };
}


////----------------------- ADMIN PANEL ----------------

// function adminFollowupRepos(fastify) {
//     async function adminaGetAddFollow({ logTrace, body }) {
//         const knex = this;
//         const knexMaster = fastify.knexMaster;

//         const patient_id = body.patient_id;
//         const doctor_id = body.doctor_id;

//         const query = await knex.raw(`select * from patient_booking
//         where patient_id = ${patient_id} and doctor_id = ${doctor_id}`);

//         console.log("qwertyuio",query[0].id)
//         const id = query[0].id;
//         console.log(id,"id");
//         // const query2 = await knex.raw(`update patient_booking set is_followup = 1 where id = ${id}`);

//         // const query3 = await knexMaster(`${FOLLOWUP.NAME}`).insert({
//         //     [FOLLOWUP.COLUMNS.DOCTOR_ID]: body.doctor_id,
//         //     [FOLLOWUP.COLUMNS.PATIENT_ID]: body.patient_id,
//         //     [FOLLOWUP.COLUMNS.PATIENT_APPOINTMENT_ID]: id,
//         //     [FOLLOWUP.COLUMNS.FOLLOWUP_DATE]: body.followup_date,
//         //     [FOLLOWUP.COLUMNS.ADDITIONAL_NOTES]: body.additional_notes,
//         //     [FOLLOWUP.COLUMNS.ACTIVE]: body.active
//         // });
//         // const response = await query2;
//         // return { success: true, message: "Insert successfully" };
//     }
//     return {
//         adminaGetAddFollow
//     };
// }

function adminFollowupRepos(fastify) {
    async function adminaGetAddFollow({ logTrace, body }) {
        const knex = this;
        const knexMaster = fastify.knexMaster;

        // const patient_id = body.patient_id;
        // const doctor_id = body.doctor_id;

        const query = await knex.raw(`select * from patient_booking `);
        // console.log("qwertyuio", query[0].id)
        const id = query[0].id;
        const query2 = await knex.raw(`update patient_booking set is_followup = 1 where id = ${id}`);

        const query3 = await knexMaster(`${FOLLOWUP.NAME}`).insert({
            [FOLLOWUP.COLUMNS.DOCTOR_ID]: body.doctor_id,
            [FOLLOWUP.COLUMNS.PATIENT_ID]: body.patient_id,
            [FOLLOWUP.COLUMNS.PATIENT_APPOINTMENT_ID]: body.patient_appointment_id,
            [FOLLOWUP.COLUMNS.FOLLOWUP_DATE]: body.followup_date,
            [FOLLOWUP.COLUMNS.ADDITIONAL_NOTES]: body.additional_notes,
            [FOLLOWUP.COLUMNS.ACTIVE]: body.active
        });
        // const response = await query2;
        return { success: true, message: "Insert successfully" };
    }
    return {
        adminaGetAddFollow
    };
}


module.exports = {
    followupRepo,
    getAddEhrSubmitRepo,
    adminFollowupRepos
}