const getHospitalInfoSchema = require("./getHospitalInfoSchema");
const getHospitalSchema = require("./getHospitalSchema");
const assignHospitalUserSchema = require("./assignHospitalUserSchema");
const getHospitalInfoByUserSchema = require("./getHospitalInfoByUserSchema");

module.exports = {
  getHospitalInfoSchema,
  getHospitalSchema,
  assignHospitalUserSchema,
  getHospitalInfoByUserSchema
};
