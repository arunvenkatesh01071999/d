const LabTestCategory = require('../models/LabTestCategoryModel');

const Get = async () => {
    await LabTestCategory.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await LabTestCategory.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await LabTestCategory.findAll({ where: { lab_test_category_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabTestCategory = async (lt_data) => {
    await LabTestCategory.create(lt_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabTestCategory = async (id, lt_data) => {
    await LabTestCategory.update(lt_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabTestCategory = async (id) => {
    await LabTestCategory.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateLabTestCategory,
    UpdateLabTestCategory,
    DestroyLabTestCategory,
    GetbyName
};
