## Profiles

1. Personal info 
2. Education info 
3. seperate api for doctor profile image
4. Doctor availaility
5. instant consultation availbility
6. Doctor informations get API
7. Degital signature API

Need Help? static content. no need API

## Personal info 
