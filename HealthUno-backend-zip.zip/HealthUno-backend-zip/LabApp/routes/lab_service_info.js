const express = require('express');
const router = express();
const LabServiceInfoController = require('../../LabApp/controller/LabServiceInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabServiceInfoController.FetchLabServiceInfo);
router.get('/:lab_name_id', verify_token, LabServiceInfoController.FetchLabServiceInfo);
router.post('/', verify_token, LabServiceInfoController.NewLabServiceInfo);
router.put('/:lab_name_id', verify_token, LabServiceInfoController.UpdateLabServiceInfo);
router.delete('/:id', verify_token, LabServiceInfoController.DeleteLabServiceInfo);


module.exports = router; 