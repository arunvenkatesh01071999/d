const express = require('express');
const router = express();
const LanguageInfoController = require('../controller/DoctorLanguageInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LanguageInfoController.FetchLanguageInfo);
router.get('/:doctor_name_id', verify_token, LanguageInfoController.FetchLanguageInfo);
router.post('/', verify_token, LanguageInfoController.NewLanguageInfo);
router.put('/:doctor_name_id', verify_token, LanguageInfoController.UpdateLanguageInfo);
router.delete('/:id', verify_token, LanguageInfoController.DeleteLanguageInfo);

module.exports = router;