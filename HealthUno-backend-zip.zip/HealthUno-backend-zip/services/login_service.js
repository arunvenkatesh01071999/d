const User = require('../models/UserModel');

const GetUser = async (email, password) => {
    await User.findAll({where:{email:email,password:password},raw: true })
        .then(user => {
            res = user
        })
        .catch(err => {
            res = err
        })
    return res
}

const VerifyUser = async (id, email, password) => {
    await User.findAll({where:{id:id, email: email, password: password}, raw:true})
        .then(user => {
            res = user
        }).catch(err => {
            res = err
        })
    return res
}

module.exports={GetUser,VerifyUser};