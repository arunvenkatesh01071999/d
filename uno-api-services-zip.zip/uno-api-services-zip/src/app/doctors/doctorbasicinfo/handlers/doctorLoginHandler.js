const doctorLoginService = require("../services/doctorLoginService");

function doctorLoginHandler(fastify) {
  const doctorLogin = doctorLoginService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    // console.log(query);
    // exit();
    const response = await doctorLogin({ body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = doctorLoginHandler;