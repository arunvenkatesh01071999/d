const express = require('express');
const router = express();
const ServiceTypeController = require('../controller/LabServiceMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ServiceTypeController.FetchLabService);
router.get('/:id', verify_token, ServiceTypeController.FetchLabService);
router.post('/', verify_token, ServiceTypeController.NewLabService);
router.put('/:id', verify_token, ServiceTypeController.UpdateLabService);
router.delete('/:id', verify_token, ServiceTypeController.DeleteLabService);

module.exports = router;