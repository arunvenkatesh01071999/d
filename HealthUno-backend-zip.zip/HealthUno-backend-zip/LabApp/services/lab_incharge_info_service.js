const LabInchargeInfo = require('../models/LabInchargeInfoModel');
const SpecialityInfo = require('../../MastersApp/models/SpecialitiesModel');
const GenderMaster = require('../../MastersApp/models/GenderModel');
const LabInfo = require('../models/LabBasicInfoModel');

const Get = async () => {
    await LabInchargeInfo.findAll({
        include: [SpecialityInfo, GenderMaster, LabInfo]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await LabInchargeInfo.findAll({
        where: { lab_name_id: id },
        include: [SpecialityInfo, GenderMaster, LabInfo]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await LabInchargeInfo.findAll({ where: { doctor_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabInChargeInfo = async (d_data) => {
    await LabInchargeInfo.create(d_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabInchargeInfo = async (id, d_data) => {
    await LabInchargeInfo.update(d_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLanInChargeInfo = async (id) => {
    await LabInchargeInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateLabInChargeInfo,
    UpdateLabInchargeInfo,
    DestroyLanInChargeInfo,
    GetbyName
};