const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { LOGINQUESTION,ALLCATEGIORYLOGINQUESTION,ANSWER} = require("../commons/constant");
const { CustomError } = require("../../../errorHandler");
const UploadImageService = require("../../../commons/imageuploadpatient");
const sms = require("../../../notification/repository/sms");
const moment = require("moment/moment");
const { log } = require("handlebars/runtime");

function Loginques(fastify) {
  async function getLoginques({ body,params, logTrace }) {
    const knex = this;
  if(params.patient_id){
    const query = knex(LOGINQUESTION.NAME)
    .select(
      LOGINQUESTION.COLUMNS.ID,
      LOGINQUESTION.COLUMNS.QUESTIONS,
      LOGINQUESTION.COLUMNS.CATEGORY_QUESTION_ID
    )
    .where(LOGINQUESTION.COLUMNS.ACTIVE, 1)
    .orderBy(LOGINQUESTION.COLUMNS.CATEGORY_QUESTION_ID, 'asc');
    const response = await query;
    for (const question of response) {
      const ques_id=question.id;
      const cat_id=question.category_ques_id;

      const query1 = knex(ANSWER.NAME)
      .select(
        ANSWER.COLUMNS.ID,
        ANSWER.COLUMNS.LOGIN_QUESTION_ANSWER,
      )
      .where(ANSWER.COLUMNS.PATIENT_ID, params.patient_id)
      .where(ANSWER.COLUMNS.CATEGORY_QUES_ID, cat_id)
      .where(ANSWER.COLUMNS.LOGIN_QUES_ID, ques_id)

      const response1 = await query1;


    }

  }
    

    logQuery({
      logger: fastify.log,
      query,
      context: "Get login question info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "login question info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
      return response;
  }

  return {
    getLoginques
  };
}

function getallcatquestion(fastify) {
  async function getallcatLoginques({ logTrace, body }) {
    const knex = this;
  
    const query = knex(ALLCATEGIORYLOGINQUESTION.NAME)
      .select(
        ALLCATEGIORYLOGINQUESTION.COLUMNS.ID,
        ALLCATEGIORYLOGINQUESTION.COLUMNS.QUESTION_CATEGORY,
      )
      .where(ALLCATEGIORYLOGINQUESTION.COLUMNS.ACTIVE, 1);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get login question info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "login question info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
      return response;
  }
  return {
    getallcatLoginques
  };
}

function questionpost(fastify) {
  async function anspost({ body, params, userDetails }) {
    const knex = this;
    
   const question_array=body.questions_data;
   for (const question of question_array) {
    const answerArray = question.answer;
    for (const question_inner of answerArray) {
   const query = await knex(`${ANSWER.NAME}`).insert({
    [ANSWER.COLUMNS.CATEGORY_QUES_ID]:question.category_ques_id,
    [ANSWER.COLUMNS.LOGIN_QUES_ID]: question.ques_id,
    [ANSWER.COLUMNS.LOGIN_QUESTION_ANSWER]: question_inner,
    [ANSWER.COLUMNS.CREATED_BY]: 2,
    [ANSWER.COLUMNS.ACTIVE]: body.active,
    [ANSWER.COLUMNS.PATIENT_ID]: body.patient_id,
    [ANSWER.COLUMNS.UPDATED_BY]: 2,

  });
    }

   }

  return { success: true, message: "Insert successfully" };
  }
  return {
    anspost
  };
}

function loginQuestionCatPostRepo(fastify) {
  async function loginQuestionCatPost({ body, params, userDetails }) {
    const knex = this;

  
   var question_category_img = body.question_category_img;
    if (question_category_img !== "" && question_category_img !== undefined) {
      if (
        question_category_img.filename !== undefined &&
        question_category_img.filename !== ""
      ) {
        const img = await UploadImageService(question_category_img, fastify);
        var imgurl = img.image_url;
      } else {
        var imgurl = null;
      }
    } else {
      var imgurl = null;
    }

    const query = await knex(`${ALLCATEGIORYLOGINQUESTION.NAME}`).insert({
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.QUESTION_CATEGORY]:body.question_category.value,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.QUESTION_CATEGORY_IMG]: imgurl,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.ACTIVE]: body.active.value,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.CREATED_BY]: 2,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.UPDATED_BY]: 2,
  
    });


  return { success: true, message: "Insert successfully" };
  }
  return {
    loginQuestionCatPost
  };
}


function loginQuestionCatUpdateRepo(fastify) {
  async function loginQuestionCatUpdate({ body, params, userDetails }) {
    const knex = this;

    var id = params.id
    var question_category_img = body.question_category_img;
    if (question_category_img !== "" && question_category_img !== undefined) {
      if (
        question_category_img.filename !== undefined &&
        question_category_img.filename !== ""
      ) {
        const img = await UploadImageService(question_category_img, fastify);
        var imgurl = img.image_url;
      } else {
        var imgurl = null;
      }
    } else {
      var imgurl = null;
    }

 

    const query = await knex(`${ALLCATEGIORYLOGINQUESTION.NAME}`)
    .where(`${ALLCATEGIORYLOGINQUESTION.COLUMNS.ID}`, id)
    .update({
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.QUESTION_CATEGORY]:body.question_category.value,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.QUESTION_CATEGORY_IMG]: imgurl,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.ACTIVE]: body.active.value,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.CREATED_BY]: 2,
      [ALLCATEGIORYLOGINQUESTION.COLUMNS.UPDATED_BY]: 2,
    });
  const response = await query;

   

  return { success: true, message: "updated successfully" };
  }
  return {
    loginQuestionCatUpdate
  };
}

    function loginQuestionCatDeleteRepo(fastify) {
      async function loginQuestionCatDelete({ body, params, userDetails }) {
        const knex = this;
    
        const { id } = params;

    const query = await knex(`${ALLCATEGIORYLOGINQUESTION.NAME}`)
      .where(`${ALLCATEGIORYLOGINQUESTION.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
      }
      return {
        loginQuestionCatDelete
      };
    }


module.exports = {
  Loginques,
  getallcatquestion,
  questionpost,
  loginQuestionCatPostRepo,
  loginQuestionCatUpdateRepo,
  loginQuestionCatDeleteRepo
};
