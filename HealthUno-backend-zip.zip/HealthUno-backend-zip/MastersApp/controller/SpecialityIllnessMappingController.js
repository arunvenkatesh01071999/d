const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const speciality_illness_mapping_service = require('../services/speciality_illness_mapping_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchSpecialityIllnessMappings = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await speciality_illness_mapping_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_speciality_illness_mapping');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await speciality_illness_mapping_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_speciality_illness_mapping', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewSpecialityIllnessMapping = async (req, res, next) => {
    speciality_id = req.body.speciality_id;
    illness_type_id = req.body.illness_type_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (speciality_id && illness_type_id) {
        sm_data = {
            speciality_id: speciality_id,
            illness_type_id: illness_type_id,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await speciality_illness_mapping_service.CreateSpecialityIllnessMapping(sm_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_speciality_illness_mapping')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "speciality_id, illness_type_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateSpecialityIllnessMapping = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        speciality_id = req.body.speciality_id;
        illness_type_id = req.body.illness_type_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (speciality_id && illness_type_id) {
            sm_data = {
                speciality_id: speciality_id,
                illness_type_id: illness_type_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await speciality_illness_mapping_service.UpdateSpecialityIllnessMapping(id, sm_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_speciality_illness_mapping')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "speciality_id, illness_type_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteSpecialityIllnessMapping = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await speciality_illness_mapping_service.DestroySpecialityIllnessMapping(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_speciality_illness_mapping')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewSpecialityIllnessMapping,
    FetchSpecialityIllnessMappings,
    UpdateSpecialityIllnessMapping,
    DeleteSpecialityIllnessMapping
}