const LoginquestionService = require("../services/getloginquestion");

function getLoginquestionHandler(fastify) {
    const Loginquestion = LoginquestionService.LoginquestionService(fastify);
    return async (request, reply) => {
        const { body,params, logTrace } = request;

        const response = await Loginquestion({ body, params,logTrace });
        return reply.code(200).send(response);
    };
}

function getallcatquestionHandler(fastify) {
    const Loginquestion = LoginquestionService.LoginallcatquestionService(fastify);
    return async (request, reply) => {
        const { body, logTrace } = request;

        const response = await Loginquestion({ body, logTrace });
        return reply.code(200).send(response);
    };
}

function anspostHandler(fastify) {
    const Loginquestion = LoginquestionService.LoginanspostService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await Loginquestion({
            body,
            params,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function loginQuestionCatPostHandler(fastify) {
    const loginGuestionCatePost = LoginquestionService.loginQuestionCatPostService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await loginGuestionCatePost({
            body,
            params,
            userDetails
        });
        return reply.code(200).send(response);
    };
}


function loginQuestionCatUpdateHandler(fastify) {
    const loginGuestionCateUpdate = LoginquestionService.loginQuestionCatUpdateService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await loginGuestionCateUpdate({
            body,
            params,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function loginQuestionCatDeleteHandler(fastify) {
    const loginGuestionCateDelete = LoginquestionService.loginQuestionCatDeleteService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await loginGuestionCateDelete({
            body,
            params,
            userDetails
        });
        return reply.code(200).send(response);
    };
}
module.exports = { getLoginquestionHandler, getallcatquestionHandler, anspostHandler, loginQuestionCatPostHandler ,loginQuestionCatUpdateHandler , loginQuestionCatDeleteHandler};
