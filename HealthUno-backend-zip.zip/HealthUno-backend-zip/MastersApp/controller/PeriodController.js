const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const period_services = require('../services/period_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');

const FetchPeriod = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await period_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_period_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await period_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_period_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewPeriod = async (req, res, next) => {
    period = req.body.period;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (period) {
        cs_data = {
            period: period,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await period_services.GetbyName(period)
            .then(s_data => {
                if (s_data.length > 0) {
                    msg = "Already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    period_services.CreatePeriod(cs_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_consultation_slots')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "period and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdatePeriod = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        period = req.body.period;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (period) {
            cs_data = {
                period: period,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // await period_services.GetbyName(period)
            //     .then(cs_data => {
            //         if (cs_data.length > 0) {
            //             msg = "Language Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            period_services.UpdatePeriod(id, cs_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_languages')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(500).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
            //     }
            // })
        } else {
            msg = "period and active is required";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

const DeletePeriod = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await period_services.DestroyPeriod(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_period_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

module.exports = {
    NewPeriod,
    FetchPeriod,
    UpdatePeriod,
    DeletePeriod
}