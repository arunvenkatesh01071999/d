const getloginquestionSchema = require('./getloginquestion')

module.exports = {
    getloginquestionSchema
}