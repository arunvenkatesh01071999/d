const cardMasterServices = require("../services/cardMasterServices");

function putCardMasterHandler(fastify) {
  const putCardMaster = cardMasterServices.putCardMasterService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await putCardMaster({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = putCardMasterHandler;
