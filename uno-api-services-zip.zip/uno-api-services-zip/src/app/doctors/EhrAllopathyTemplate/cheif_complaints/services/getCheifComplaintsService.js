const getCheifComplaintsRepository = require("../repository/getCheifComplaintsRepository");

function createCheifComplaintsServiceBasic(fastify) {
  const { CheifComplaintsAdd } = getCheifComplaintsRepository.postCheifComplaintsRepositoryBasic(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsAdd.call(knex, {
      logTrace,
      body
    });

    const [CheifComplaintsAddData] = await Promise.all([promise1]);

    return CheifComplaintsAddData;
  };
}

function updateCheifComplaintsServiceBasic(fastify) {
  const { CheifComplaintsUpdate } = getCheifComplaintsRepository.updateCheifComplaintsRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedCheifComplaintsData] = await Promise.all([promise1]);

    return updatedCheifComplaintsData;
  };
}



function getCheifComplaintsInfoService(fastify) {

  const { CheifComplaintsGetAlls } = getCheifComplaintsRepository.getCheifComplaintsRepository(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsGetAlls.call(knex, {
      logTrace
    });
    const [getCheifComplaintsAlldata] = await Promise.all([promise1]);
    return getCheifComplaintsAlldata;
  }
}

function getCheifComplaintsInfoServiceId(fastify) {

  const { CheifComplaintsGetOne } = getCheifComplaintsRepository.getCheifComplaintsRepositoryId(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsGetOne.call(knex, {
      logTrace,
      params
    });
    const [getCheifComplaintsOnedata] = await Promise.all([promise1]);
    return getCheifComplaintsOnedata;
  }
}

function deleteCheifComplaintsServiceId(fastify) {
  const { CheifComplaintsDelete } = getCheifComplaintsRepository.deleteCheifComplaintsRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsDelete.call(knex, {
      logTrace,
      params
    });
    const [deleteCheifComplaintsdata] = await Promise.all([promise1]);
    return deleteCheifComplaintsdata;
  };
}

function getCheifComplaintsIllnessTypesInfoService(fastify) {

  const { CheifComplaintsGetAlls } = getCheifComplaintsRepository.getCheifComplaintsIllnesTypesRepository(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsGetAlls.call(knex, {
      logTrace
    });
    const [getCheifComplaintsAlldata] = await Promise.all([promise1]);
    return getCheifComplaintsAlldata;
  }
}


function getPatientEhrSearchService(fastify) {

  const { CheifComplaintsGetAlls } = getCheifComplaintsRepository.getPatientEhrSearchRepository(fastify);

  return async ({ logTrace,body }) => {
    const knex = fastify.knexPatient;
    const promise1 = CheifComplaintsGetAlls.call(knex, {
      logTrace,
      body
    });
    const [getCheifComplaintsAlldata] = await Promise.all([promise1]);
    return getCheifComplaintsAlldata;
  }
}


function getPatientEhrSearchGetAllService(fastify) {
  const { CheifComplaintsGetAlls } = getCheifComplaintsRepository.getPatientEhrSearchGetAllRepository(fastify);
  return async ({ logTrace,body }) => {
    const knex = fastify.knexPatient;
    const promise1 = CheifComplaintsGetAlls.call(knex, {
      logTrace,
      body
    });
    const [getCheifComplaintsAlldata] = await Promise.all([promise1]);
    return getCheifComplaintsAlldata;
  }
}
module.exports = {

  createCheifComplaintsServiceBasic,
  updateCheifComplaintsServiceBasic,
  getCheifComplaintsInfoService,
  getCheifComplaintsInfoServiceId,
  deleteCheifComplaintsServiceId,
  getCheifComplaintsIllnessTypesInfoService,
  getPatientEhrSearchService,
  getPatientEhrSearchGetAllService
};
