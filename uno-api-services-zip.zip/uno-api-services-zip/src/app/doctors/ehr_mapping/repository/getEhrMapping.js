const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { ERH_DETAILS } = require("../commons/constant");
const { DOCTORBASICINFO } = require('../commons/constant')
const { CustomError } = require("../../../errorHandler");

function allEhrRepo(fastify) {
    async function getAllEhr({ logTrace, doctor_id }) {
        const knex = this;
        const query3 = knex.raw(`select * from ehr_mappings_list where doctor_id=${doctor_id} and ehr_type_id=1`);
        const updated_allopathy_list = await query3;
        const query4 = knex.raw(`select * from ehr_mappings_list where doctor_id=${doctor_id} and ehr_type_id=2`);
        const updated_ayurvedic_list = await query4;
        const query5 = knex.raw(`select * from ehr_allopathy_list_master where active=1`);
        const all_allopathy_list = await query5;
        const query6 = knex.raw(`select * from ehr_ayurvedic_list_master where active=1`);
        const all_ayurvedic_list = await query6;
        const ayurvedic_data = [];
        const ayurvedic_data_all = []
        if (updated_ayurvedic_list.length > 0) {
            all_ayurvedic_list.filter(item => {
                ayurvedic_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });
            updated_ayurvedic_list.filter(ele => {
                all_ayurvedic_list.filter(item => {
                    if (parseInt(ele.ehr_list_id) === item.id) {
                        ayurvedic_data.push({
                            "item": item,
                            "choosen": 1
                        })
                    }
                });
            });
            ayurvedic_data_all.map(ele => {
                ayurvedic_data.map(item => {
                    if (ele.item.id == item.item.id) {
                        ele.choosen = 1;
                    }
                })
            })
        }
        else {
            all_ayurvedic_list.filter(item => {
                ayurvedic_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });
        }
        const allopathy_data = [];
        const allopathy_data_all = []
        if (updated_allopathy_list.length > 0) {
            all_allopathy_list.filter(item => {
                allopathy_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });
            updated_allopathy_list.filter(ele => {
                all_allopathy_list.filter(item => {
                    if (parseInt(ele.ehr_list_id) === item.id) {
                        allopathy_data.push({
                            "item": item,
                            "choosen": 1
                        })
                    }
                });
            });
            allopathy_data_all.map(ele => {
                allopathy_data.map(item => {
                    if (ele.item.id == item.item.id) {
                        ele.choosen = 1;
                    }
                })
            })
        }
        else {
            all_allopathy_list.filter(item => {
                allopathy_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });
        }
        const final_data = { allopathy_data_all, ayurvedic_data_all };
        return final_data;
    }
    return {
        getAllEhr
    };
}

// function allEhrRepo(fastify) {
//     async function getAllEhr({ logTrace, doctor_id }) {
//         const knex = this;
//         const query = knex.select(`*`).from(`${ERH_DETAILS.NAME}`)
//         logQuery({
//             logger: fastify.log,
//             query,
//             context: "Get EHR mapping details",
//             logTrace
//         });

//         const response = await query;
//         if (!response.length) {
//             throw CustomError.create({
//                 httpCode: StatusCodes.NOT_FOUND,
//                 message: "EHR mapping info not found",
//                 property: "",
//                 code: "NOT_FOUND"
//             });
//         }
//         return response;
//     }

//     return {
//         getAllEhr
//     };
// }

// function allEhrRepo(fastify) {
//     async function getAllEhr({ logTrace, doctor_id }) {
//         const knex = this;
//         const query = knex.select(`BS.*`,
//             `DOCTORBASICINFO.${DOCTORBASICINFO.COLUMNS.ID} as doctor_id`,

//         )
//             .from(`${ERH_DETAILS.NAME} as BS`)
//             .leftJoin(`${DOCTORBASICINFO.NAME} ,BS.doctor_id,`)
//         logQuery({
//             logger: fastify.log,
//             query,
//             context: "Get EHR mapping details",
//             logTrace
//         });

//         const response = await query;
//         if (!response.length) {
//             throw CustomError.create({
//                 httpCode: StatusCodes.NOT_FOUND,
//                 message: "EHR mapping info not found",
//                 property: "",
//                 code: "NOT_FOUND"
//             });
//         }
//         return response;
//     }

//     return {
//         getAllEhr
//     };
// }

function ehrPostRepo(fastify) {
    async function getAddEhr({ logTrace, body }) {
        const knex = this;
        const exist_array_data = [];
        const ehr_list_id = body.ehr_list_id;
        const ehr_type_id = body.ehr_type_id;
        if (ehr_list_id && Array.isArray(ehr_list_id) && body.doctor_id) {
            const query = knex.raw(`select * from ehr_mappings_list where doctor_id=${body.doctor_id} and ehr_type_id=${ehr_type_id} `);
            const response = await query;
            for (let i = 0; i < response.length; i++) {
                const data = response[i].ehr_list_id;
                exist_array_data.push(parseInt(data));
            }
            const differenceArray1 = exist_array_data.filter(item => !ehr_list_id.includes(item));
            if (differenceArray1.length > 0) {
                differenceArray1.forEach(async element => {
                    const query1 = await knex(`${ERH_DETAILS.NAME}`)
                        .where(`${ERH_DETAILS.COLUMNS.DOCTOR_ID}`, body.doctor_id)
                        .where(`${ERH_DETAILS.COLUMNS.EHR_LIST_ID}`, element)
                        .where(`${ERH_DETAILS.COLUMNS.EHR_TYPE_ID}`, ehr_type_id)
                        .del();
                    const response1 = await query1;
                });

            }

            const differenceArray2 = ehr_list_id.filter(element => !exist_array_data.includes(element));
            if (differenceArray2.length > 0) {
                differenceArray2.forEach(async element => {
                    const query2 = await knex(`${ERH_DETAILS.NAME}`).insert({
                        [ERH_DETAILS.COLUMNS.DOCTOR_ID]: body.doctor_id,
                        [ERH_DETAILS.COLUMNS.EHR_LIST_ID]: element,
                        [ERH_DETAILS.COLUMNS.EHR_TYPE_ID]: ehr_type_id,
                        [ERH_DETAILS.COLUMNS.ACTIVE]: body.active,
                        [ERH_DETAILS.COLUMNS.CREATED_BY]: body.created_by,
                        [ERH_DETAILS.COLUMNS.UPDATED_BY]: body.created_by
                    });
                    const response2 = await query2;
                });

            }

        }


        const query3 = knex.raw(`select * from ehr_mappings_list where doctor_id=${body.doctor_id} and ehr_type_id=1`);
        const updated_allopathy_list = await query3;

        const query4 = knex.raw(`select * from ehr_mappings_list where doctor_id=${body.doctor_id} and ehr_type_id=2`);
        const updated_ayurvedic_list = await query4;

        const query5 = knex.raw(`select * from ehr_allopathy_list_master where active=1`);
        const all_allopathy_list = await query5;

        const query6 = knex.raw(`select * from ehr_ayurvedic_list_master where active=1`);
        const all_ayurvedic_list = await query6;


        const ayurvedic_data = [];
        const ayurvedic_data_all = []

        if (updated_ayurvedic_list.length > 0) {

            all_ayurvedic_list.filter(item => {

                ayurvedic_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });


            updated_ayurvedic_list.filter(ele => {
                all_ayurvedic_list.filter(item => {

                    if (parseInt(ele.ehr_list_id) === item.id) {
                        ayurvedic_data.push({
                            "item": item,
                            "choosen": 1
                        })
                    }

                });
            });


            ayurvedic_data_all.map(ele => {
                ayurvedic_data.map(item => {

                    if (ele.item.id == item.item.id) {
                        ele.choosen = 1;

                    }
                })

            })


        }
        else {
            all_ayurvedic_list.filter(item => {

                ayurvedic_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });

        }






        const allopathy_data = [];
        const allopathy_data_all = []

        if (updated_allopathy_list.length > 0) {

            all_allopathy_list.filter(item => {

                allopathy_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });


            updated_allopathy_list.filter(ele => {
                all_allopathy_list.filter(item => {

                    if (parseInt(ele.ehr_list_id) === item.id) {
                        allopathy_data.push({
                            "item": item,
                            "choosen": 1
                        })
                    }

                });
            });


            allopathy_data_all.map(ele => {
                allopathy_data.map(item => {

                    if (ele.item.id == item.item.id) {
                        ele.choosen = 1;

                    }
                })

            })


        }
        else {
            all_allopathy_list.filter(item => {

                allopathy_data_all.push({
                    "item": item,
                    "choosen": 0
                })
            });

        }

        const final_data = { allopathy_data_all, ayurvedic_data_all };
        return final_data;



    }

    return {
        getAddEhr
    };
}

function ehrPutRepo(fastify) {
    async function getPutEhr({ logTrace, body, params }) {
        const knex = this;
        const { id } = params;
        const query = await knex(`${ERH_DETAILS.NAME}`)
            .where(`${ERH_DETAILS.COLUMNS.ID}`, id)
            .update({
                [ERH_DETAILS.COLUMNS.DOCTOR_ID]: body.doctor_id,
                [ERH_DETAILS.COLUMNS.IS_ALLO_AYUR]: body.is_allo_ayur,
                [ERH_DETAILS.COLUMNS.IS_ALLO_AYUR]: body.temp_id,
                [ERH_DETAILS.COLUMNS.ACTIVE]: body.active
            });
        const response = await query;
        return { success: true, message: "Updated successfully" }
    }
    return {
        getPutEhr
    }
}

function ehrDeleteRepo(fastify) {
    async function getEhrDelete({ logTrace, body, params, userDetails }) {
        const knex = this;

        const { id } = params;

        const query = await knex(`${ERH_DETAILS.NAME}`)
            .where(`${ERH_DETAILS.COLUMNS.ID}`, id)
            .del();

        const response = await query;

        return { success: true, message: "Deleted successfully" };
    }

    return {
        getEhrDelete
    };
}

module.exports = {
    allEhrRepo,
    ehrPostRepo,
    ehrPutRepo,
    ehrDeleteRepo
}