const getOtherTreatmentHandler = require("./getOtherTreatmentHandler.js");

module.exports = {
  getOtherTreatmentHandler
};
