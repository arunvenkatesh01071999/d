const BankMasterModel = require('../models/BankMasterModel');

const Get = async () => {
    await BankMasterModel.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await BankMasterModel.findAll({ where: { id: id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (bank_name) => {
    await BankMasterModel.findAll({ where: { bank_name: bank_name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const createBankMaster = async () => {
    await BankMasterModel.create(b_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateBankMaster = async (id, b_data) => {
    await BankMasterModel.update(b_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryBankMaster = async (id) => {
    await BankMasterModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    createBankMaster,
    UpdateBankMaster,
    DestoryBankMaster
};