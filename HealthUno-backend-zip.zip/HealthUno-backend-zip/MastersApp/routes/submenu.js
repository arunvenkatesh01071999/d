const express = require('express');
const router = express();
const SubMenuContoller = require('../controller/SubMenuContoller');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, SubMenuContoller.FetchSubMenu);
router.get('/:id', verify_token, SubMenuContoller.FetchSubMenu);
router.post('/', verify_token, SubMenuContoller.NewSubMenu);
router.put('/:id', verify_token, SubMenuContoller.UpdateSubMenu);
router.delete('/:id', verify_token, SubMenuContoller.DeleteSubMenu);

module.exports = router;
