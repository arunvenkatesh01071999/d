const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const department_info_service = require('../services/department_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');


const FetchDepartmentInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await department_info_service.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_department_info_service');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await department_info_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_department_info_service', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewDepartmentInfo = async (req, res, next) => {
    const hospital_name_id = req.body.hospital_name_id;
    const department_name_id = req.body.department_name_id;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id);
// console.log(query,"qwerty");
    if (hospital_name_id && department_name_id && Array.isArray(department_name_id) && department_name_id.length > 0) {
        for (const i of department_name_id) {
            const s_data = {
                hospital_name_id: parseInt(hospital_name_id),
                department_name_id: parseInt(i),
                addCheck: addCheck,
                active: active,
                created_by: created_by,
                updated_by: updated_by
            }
            console.log(s_data);
            // await department_info_service.GetId(hospital_name_id)
            //     .then(data => {
            // if (data.length > 0) {
            //     msg = "Hospital Address Already Exist";
            //     return res.status(200).json(failure_func(msg))
            // } else {
            await department_info_service.CreateDepartmentInfo(s_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Created Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
            // }
            // })
        }
        msg = "Created Successfully"
        res.status(200).json(success_func(msg))

    } else {
        msg = "hospital_name_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateDepartmentInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        department_info_service.DestroyDepartmentInfo(hospital_name_id)

        department_name_id = req.body.department_name_id;
        hospital_name_id = req.body.hospital_name_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        for (const i of department_name_id) {
            const s_data = {
                hospital_name_id: parseInt(hospital_name_id),
                department_name_id: parseInt(i),
                active: active,
                created_by: req.user.id,
                updated_by: updated_by
            }
            console.log(s_data);
            await department_info_service.CreateDepartmentInfo(s_data)
                // .then(data => {
                // if (data.length > 0) {
                //     msg = "Hospital Address Already Exist";
                //     return res.status(200).json(failure_func(msg))
                // } else {
                // department_info_service.CreateDepartmentInfo(s_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Updated Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
            // }
            // })
        }
        msg = "Updated Successfully"
        res.status(200).json(success_func(msg))
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

// const DeleteDepartmentInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await department_info_service.DestroyDepartmentInfo(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_department_info_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


module.exports = {
    NewDepartmentInfo,
    FetchDepartmentInfo,
    UpdateDepartmentInfo,
    // DeleteDepartmentInfo
}