const db1 = require('../config/db1');

const addCheck = async (doctor_name_id) => {
    const addCheck = 11;
    if (doctor_name_id > 0) {
        const query = `select addCheck from d_doctor_basic_info where id = ${doctor_name_id}`;
        var customerFeedback = await db1.query(query);
        var menu_data = customerFeedback.flat();
        total_add = addCheck + menu_data[0].addCheck;

        const query1 = `UPDATE d_doctor_basic_info SET addCheck = ${total_add} where id =${doctor_name_id}`
        var customerFeedback1 = await db1.query(query1);
    } else {
        msg = "hospital_name_id is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = addCheck;