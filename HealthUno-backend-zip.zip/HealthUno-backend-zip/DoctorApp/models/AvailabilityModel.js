const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const SecondOpinion = require('../models/SecondOpinionModel');

const AvailabilityInfo = sequelize.define("d_availability_info", {
    doctor_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    second_option_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    period_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    fees_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    inst_time: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    inst_consult: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    avail_chat: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    avail_consult: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

AvailabilityInfo.belongsTo(DoctorInfo, { foreignKey: 'doctor_name_id' });
AvailabilityInfo.belongsTo(SecondOpinion, { foreignKey: 'second_option_id' });

AvailabilityInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_availability_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

AvailabilityInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_availability_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = AvailabilityInfo;