const express = require('express');
const router = express();
const LabOfficeUseController = require('../controller/LabOfficeUseController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabOfficeUseController.FetchOfficeUse);
router.get('/:lab_name_id', verify_token, LabOfficeUseController.FetchOfficeUse);
router.post('/', verify_token, LabOfficeUseController.NewOfficeUse);
router.put('/:id', verify_token, LabOfficeUseController.UpdateOfficeUse);
router.delete('/:id', verify_token, LabOfficeUseController.DeleteOfficeUse);

module.exports = router;