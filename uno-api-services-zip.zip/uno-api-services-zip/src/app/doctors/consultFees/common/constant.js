const PAYMENTINFO = {
    NAME: "d_consulted_fees",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID:"doctor_id",
       VIDEO_CONSULTING_FEE : "video_consulting_fee",
       V_DISPLAY_AMT: "v_display_amt",
        V_PLATFORM_CHARGE: "v_platform_charge",
        V_HOW_MOUCH_TOU_GET: "v_how_mouch_you_get",
       WALK_CONSULTING_FEE : "walk_consulting_fee",

        W_DISPLAY_AMT: "w_display_amt",
        W_PLATFORM_CHARGE: "w_platform_charge",
        W_HOW_MOUCH_TOU_GET: "w_how_mouch_you_get",

        INSTTANT_CONSULTING_FEE: "instant_consulting_fee",
        I_DISPLAY_AMT: "i_display_amt",
        I_PLATFORM_CHARGE: "i_platform_charge",
        I_HOW_MOUCH_TOU_GET: "i_how_mouch_you_get",

         SECOND_OPINION_FEE:"second_opinion_fee",
        S_DISPLAY_AMT: "s_display_amt",
        S_PLATFORM_CHARGE: "s_platform_charge",
        S_HOW_MOUCH_TOU_GET: "s_how_mouch_you_get",

          CHAT_CONSULTING_FEE: "chat_consulting_fee",
        C_DISPLAY_AMT: "c_display_amt",
        C_PLATFORM_CHARGE: "c_platform_charge",
        C_HOW_MOUCH_TOU_GET: "c_how_mouch_you_get",

        CHECK: "check",
        ACTIVE:"active"
    }
};

module.exports = {
    PAYMENTINFO
};