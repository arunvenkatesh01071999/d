const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const session_services = require('../services/session_type_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');

const FetchSession = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await session_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_session_services');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await session_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_session_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewSession = async (req, res, next) => {
    session_type = req.body.session_type;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (session_type) {
        sl_data = {
            session_type: session_type,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await session_services.CreateSession(sl_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_consultation_slots')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "session_type and active is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewSession,
    FetchSession
}