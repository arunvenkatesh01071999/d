const LOGINQUESTION = {
  NAME: "login_questions",
  COLUMNS: {
    ID: "id",
    CATEGORY_QUESTION_ID: "category_ques_id",
    QUESTIONS: "questions",
    SUGGESTION:"suggestion",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }


};

const ALLCATEGIORYLOGINQUESTION = {
  NAME: "login_questions_category",
  COLUMNS: {
    ID: "id",
    QUESTION_CATEGORY: "question_category",
    QUESTION_CATEGORY_IMG: "question_category_img",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }

};
const ANSWER = {
  NAME: "login_questions_answer",
  COLUMNS: {
    ID: "id",
    CATEGORY_QUES_ID: "category_ques_id",
    LOGIN_QUES_ID: "login_ques_id",
    LOGIN_QUESTION_ANSWER: "login_question_answer",
    PATIENT_ID:"patient_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }

};

module.exports = {
  LOGINQUESTION,ALLCATEGIORYLOGINQUESTION,ANSWER
};

