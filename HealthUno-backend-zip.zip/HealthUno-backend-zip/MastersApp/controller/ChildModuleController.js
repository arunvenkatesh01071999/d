const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const child_module_services = require('../services/child_module_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchChildModules = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await child_module_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_child_module');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await child_module_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_child_module', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewChildModule = async (req, res, next) => {
    child_module_name = req.body.child_module_name;
    parent_module_id = req.body.parent_module_id;
    main_module_id = req.body.main_module_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (child_module_name && parent_module_id && main_module_id) {
        cm_data = {
            child_module_name: child_module_name,
            parent_module_id: parent_module_id,
            main_module_id: main_module_id,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await child_module_services.GetbyName(child_module_name)
            .then(services_data => {
                if (services_data.length > 0) {
                    msg = "ChildModule Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    child_module_services.CreateChildModule(cm_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_child_module')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "child_module_name, parent_module_id, main_module_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateChildModule = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        child_module_name = req.body.child_module_name;
        parent_module_id = req.body.parent_module_id;
        main_module_id = req.body.main_module_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (child_module_name && parent_module_id && main_module_id) {
            cm_data = {
                child_module_name: child_module_name,
                parent_module_id: parent_module_id,
                main_module_id: main_module_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await child_module_services.UpdateChildModule(cm_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_child_module')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else {
            msg = "child_module_name, parent_module_id, main_module_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteChildModule = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await child_module_services.DestroyChildModule(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_child_module')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewChildModule,
    FetchChildModules,
    UpdateChildModule,
    DeleteChildModule
}