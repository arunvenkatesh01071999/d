## Patients Dashboard

## Banners Masters

Table Fileds.

1. banner_name
2. banner_description
3. banner_title
4. banner_images
5. banner_link
6. banner_type
   1. is_top_banner - 1
   2. is_home_care - 2
   3. is_ayurvedic - 3
   4. is_insurance - 4

## Banners APIs

1. all curd apis needed

## Our Services

Table fields:

1. service_name
2. service_description
3. service_title
4. service_images
5. service_link
6. is_active

## Our Services APIs

1. all curd apis needed

## Availbale doctors Count APIs

## Logic

1. Total active doctors count
2. Total active doctors count nearby patient login locations

## Specalities API

1. Fetch all specalities which are active

Note : Specality master,Illness, symptomps, lab test, scan tests image upload to done.
