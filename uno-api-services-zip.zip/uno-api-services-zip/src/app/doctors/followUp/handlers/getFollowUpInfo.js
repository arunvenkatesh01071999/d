const getFollowUpDetail = require('../services/getFollowUpInfo');

function getFollowUpInfoHandler(fastify) {
    const getFollowDetailInfo = getFollowUpDetail.getFollowUpPostInfoService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        
        const response = await getFollowDetailInfo({
            body,
            params,
            logTrace
        });
        return reply.code(200).send(response);
    };
}


function getehrsubmitInfoHandler(fastify) {
    const getehrsubmitDetailInfo = getFollowUpDetail.getehrsubmitPostInfoService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        
        const response = await getehrsubmitDetailInfo({
            body,
            params,
            logTrace
        });
        return reply.code(200).send(response);
    };
}

//////-----------------------ADMIN PANEL ----------------------------

function adminFollowUpInfoHandler(fastify) {
    const getFollowDetailInfo = getFollowUpDetail.adminFollowUpPostInfoService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        
        const response = await getFollowDetailInfo({
            body,
            params,
            logTrace
        });
        return reply.code(200).send(response);
    };
}

module.exports = {
    getFollowUpInfoHandler,
    getehrsubmitInfoHandler,
    adminFollowUpInfoHandler
}