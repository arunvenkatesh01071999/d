const HOSPITAL_BASIC_INFO = {
  NAME: "h_hospital_basic_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_NAME: "hospital_name",
    HOSPITAL_TYPE_ID: "hospital_type_id",
    SECTOR_ID: "sector_id",
    ACCREDATION_ID: "accredation_id",
    REGNO: "regNo",
    ABOUT: "about",
    CERTIFICATE_PATH: "certicate_path",
    ADDCHECK: "addCheck",
    APPROVED_BY: "approved_by",
    RESASON: "reason",
    APPROVE_DATE: "approve_date",
    ISAPPROVED: "isApproved",
    HOSPITAL_IMAGE: "hospital_image",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    HOSPITAL_USER: "hospital_user",
    RATING: "rating"
  }
};

const HOSPITAL_SECTOR = {
  NAME: "hospital_sector",
  COLUMNS: {
    ID: "id",
    HOSPITAL_SECTOR_NAME: "hospital_sector_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const ACCREDATION = {
  NAME: "accredation",
  COLUMNS: {
    ID: "id",
    ACCREDATION_NAME: "accredation_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_ADDRESS_INFO = {
  NAME: "h_address_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_NAME_ID: "hospital_name_id",
    ADDRESS1: "address1",
    ADDRESS2: "address2",
    CITY_ID: "city_id",
    STATE_ID: "state_id",
    COUNTRY_ID: "country_id",
    PINCODE: "pincode",
    LOCATION: "location",
    LONGITUDE: "longitude",
    LATITUDE: "latitude",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const CITIES = {
  NAME: "cities",
  COLUMNS: {
    ID: "id",
    CITYNAME: "city_name",
    STATEID: "state_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const STATES = {
  NAME: "states",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    COUNTRYID: "country_id"
  }
};
const COUNTRIES = {
  NAME: "countries",
  COLUMNS: {
    ID: "id",
    SHORTNAME: "shortname",
    NAME: "name",
    PHONECODE: "phonecode",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_CONTACT_INFO = {
  NAME: "h_contact_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    MOBILE_NO: "mobile_no",
    EMERGENY_NO: "emergency_no",
    TOLL_FREE_NO: "toll_free_no",
    HELPLINE_NO: "helpline_no",
    FAX_NO: "fax_no",
    FOREIGN_WING: "foreign_international_wing",
    WEBSITE: "webiste_URL",
    EMAIL1: "email_address_1",
    EMAIL2: "email_address_2",
    ESTABLISHEDIN: "established_in",
    TELEPHONE_NO: "telephone_no",
    AMBULANCE_NO: "ambulance_no",
    BLOOD_BANK_NO: "blood_bank_no",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_INFRASTRUCTURE = {
  NAME: "h_infrastructure",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    NO_OF_DOCTORS: "no_of_doctor",
    NO_OF_AMBULANCES: "no_of_ambulances",
    ANESTH_DOCTOR: "anesth_doctor",
    ANOTOMY_DOCTOR: "anotomy_doctor",
    CARDIO_DOCTOR: "cardio_doctor",
    OPERATION_THEATER: "operation_theatre",
    ICU: "icu",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const ROOM_TYPE = {
  NAME: "room_type",
  COLUMNS: {
    ID: "id",
    ROOM_TYPE: "room_type_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_ROOM_INFO = {
  NAME: "h_room_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    ROOM_TYPE_ID: "room_type_id",
    COST_ID: "cost_id",
    NO_OF_DAYS: "no_of_days",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DEPARTMENT_MASTER = {
  NAME: "department_master",
  COLUMNS: {
    ID: "id",
    DEAPARTMENT_NAME: "department_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_DEPARTMENT = {
  NAME: "h_department_info",
  COLUMNS: {
    ID: "id",
    DEAPARTMENT_NAME_ID: "department_name_id",
    HOSPITAL_ID: "hospital_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const SPECIALITIES = {
  NAME: "specialities",
  COLUMNS: {
    ID: "id",
    SPECIALITIY_NAME: "speciality_name",
    LOGO_IMAGE: "logo_image",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_SPECIALITY_INFO = {
  NAME: "h_speciality_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    SPECIALITIY_NAME_ID: "speciality_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_SERVICE_INFO = {
  NAME: "h_service_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    SERVICE_NAME_ID: "service_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_SERVICES_MASTER = {
  NAME: "hospital_services_master",
  COLUMNS: {
    ID: "id",
    SERVICE_NAME: "service_name",
    LOGO_IMAGE: "logo_image",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_LAB_INFO = {
  NAME: "h_lab_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    HOSPITAL_ID: "hospital_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SERVICE = {
  NAME: "lab_service",
  COLUMNS: {
    ID: "id",
    SERVICE_NAME: "service_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_SCAN_INFO = {
  NAME: "h_scan_info",
  COLUMNS: {
    ID: "id",
    SCAN_NAME_ID: "scan_name_id",
    HOSPITAL_ID: "hospital_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const SCAN_TEST_MASTER = {
  NAME: "scan_test_master",
  COLUMNS: {
    ID: "id",
    SCAN_TEST_NAME: "scan_test_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_INSURANCE_INFO = {
  NAME: "h_insurance_info",
  COLUMNS: {
    ID: "id",
    INSURANCE_NAME_ID: "insurance_name_id",
    HOSPITAL_ID: "hospital_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const INSURANCE = {
  NAME: "insurance",
  COLUMNS: {
    ID: "id",
    INSURANCE_NAME: "insurance_name",
    LOGO_IMAGE: "logo_image",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_OFFICE_USE = {
  NAME: "h_office_use",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    PERSON_NAME: "person_name",
    PERSON_EMAIL_ID: "person_email_id",
    DESIGNATION: "designation",
    MOBILE: "mobile",
    TELEPHONE: "telephone",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_TERMS_CONDITION = {
  NAME: "h_terms_condition",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    TERMS: "terms",
    CONDITION: "condition",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAL_PAYMENT_INFO = {
  NAME: "h_payment_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    FEES_TYPE_ID: "fees_type_id",
    FEES_AMT: "fees_amt",
    COMMISION: "commision",
    CHECK: "check",
    N_DISPLAY_AMT: "N_display_amt",
    N_COMMISION: "N_commision",
    S_DISPLAY_AMT: "s_display_amt",
    S_COMMISION: "s_commision",
    S_PAYOUT: "s_payout",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const FEES_TYPE_MASTER = {
  NAME: "fees_type_master",
  COLUMNS: {
    ID: "id",
    FEES_TYPE_NAME: "fees_type_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const DOCTORBASICINFO = {
  NAME: "d_doctor_basic_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    DOCTOR_NAME: "doctor_name",
    GENDER_ID: "gender_id",
    SPECIALITY_ID: "speciality_id",
    EMAIL: "email",
    PHONE_NO: "phone_no",
    DOB: "dob",
    AGE: "age",
    ABOUT: "about",
    IMAGE_PATH: "image_path",
    SIGNATURE_PATH: "signature_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    RATING: "rating",
    ISAPPROVED: "isApproved"
  }
};
const GENDER = {
  NAME: "gender",
  COLUMNS: {
    ID: "id",
    GENDER_NAME: "gender_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTORAVAILABILITY = {
  NAME: "d_availability_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    SECOND_OPTION_ID: "second_option_id",
    INST_TIME: "inst_time",
    INST_CONSULT: "inst_consult",
    AVAIL_CHAT: "avail_chat",
    AVAIL_CONSULT: "avail_consult",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    UPDATED_BY: "fees_id",
    UPDATED_BY: "period_id"
  }
};
const DOCTOR_EXPERIENCE = {
  NAME: "d_experience_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    SPECIALIZATION_ID: "specialization_id",
    DEPARTMENT_ID: "department_id",
    UPLOAD_CERTIFICATE: "upload_certicate",
    EXPERIENCE: "experience",
    SPECIALIZED_FILE: "specialized_file",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTOR_FEES = {
  NAME: "d_consulted_fees",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    VIDEO_FESS: "video_consulting_fee",
    VIDEO_DISPLAY_AMOUNT: "v_display_amt",
    VIDEO_PLATFORM_CHARGE: "v_platform_charge",
    VIDEO_COMM: "v_how_mouch_you_get",
    WALKIN_FEE: "walk_consulting_fee",
    WALKIN_DISPLAY_AMOUNT: "w_display_amt",
    WALKIN_PLATFORM_CHARGE: "w_platform_charge",
    WALKIN_HOW_MUCH_YOU_GET: "w_how_mouch_you_get",
    INSTANT_CONSULTING_FEE: "instant_consulting_fee",
    INSTANT_DISPLAY_AMOUNT: "i_display_amt",
    INSTANT_PLATFORM_CHARGE: "i_platform_charge",
    INSTANT_HOW_MUCH_YOU_GET: "i_how_mouch_you_get",
    SECOND_OPINION_FEE: "second_opinion_fee",
    SECOND_OPINION_DISPLAY_AMOUNT: "s_display_amt",
    SECOND_OPINION_PLATFORM_CHARGE: "s_platform_charge",
    SECOND_OPINION_HOW_MUCH_YOU_GET: "s_how_mouch_you_get",
    CHAT_CONSULTING_FEE: "chat_consulting_fee",
    CHAT_DISPLAY_AMOUNT: "c_display_amt",
    CHAT_PLATFORM_CHARGE: "c_platform_charge",
    CHAT_HOW_MUCH_YOU_GET: "c_how_mouch_you_get",
    CHECK: "check",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HOSPITAl_IMAGES = {
  NAME: "h_hospital_image",
  COLUMNS: {
    ID: "id",
    HOSPITAL_NAME_ID: "hospital_name_id",
    HOSPITAL_IMAGE: "hospital_image",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTORLANGUAGEINFO = {
  NAME: "d_language_info",
  COLUMNS: {
    ID: "id",
    LANGUAGE_NAME_ID: "language_name_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LANGUAGES = {
  NAME: "languages",
  COLUMNS: {
    ID: "id",
    LANGUAGENAME: "language_name",
    NATIVENAME: "native_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  HOSPITAL_BASIC_INFO,
  HOSPITAL_SECTOR,
  ACCREDATION,
  HOSPITAL_ADDRESS_INFO,
  CITIES,
  STATES,
  COUNTRIES,
  HOSPITAL_CONTACT_INFO,
  HOSPITAL_INFRASTRUCTURE,
  ROOM_TYPE,
  HOSPITAL_ROOM_INFO,
  DEPARTMENT_MASTER,
  HOSPITAL_DEPARTMENT,
  SPECIALITIES,
  HOSPITAL_SPECIALITY_INFO,
  HOSPITAL_SERVICE_INFO,
  HOSPITAL_SERVICES_MASTER,
  HOSPITAL_LAB_INFO,
  LAB_SERVICE,
  HOSPITAL_SCAN_INFO,
  SCAN_TEST_MASTER,
  HOSPITAL_INSURANCE_INFO,
  INSURANCE,
  HOSPITAL_OFFICE_USE,
  HOSPITAL_TERMS_CONDITION,
  HOSPITAL_PAYMENT_INFO,
  FEES_TYPE_MASTER,
  DOCTORBASICINFO,
  GENDER,
  DOCTORAVAILABILITY,
  DOCTOR_EXPERIENCE,
  DOCTOR_FEES,
  HOSPITAl_IMAGES,
  DOCTORLANGUAGEINFO,
  LANGUAGES
};
