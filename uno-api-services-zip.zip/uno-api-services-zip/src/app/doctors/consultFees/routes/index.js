const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/consult-fees",
    preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.createConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fees",
    preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.getConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesHandlerGet(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fees/:doctor_id",
    preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.getConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesByIdHandler(fastify)
  });


  fastify.route({
    method: "PUT",
    url: "/consult-fees/:doctor_id",
    preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.updateConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesPutHandler(fastify)
  });


  //admin_panel

  fastify.route({
    method: "POST",
    url: "/consult-fees/admin_panel",
    // preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.createConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fees/admin_panel",
    // preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.getConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesHandlerGet(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fees/admin_panel/:doctor_id",
    // preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.getConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesByIdHandler(fastify)
  });


  fastify.route({
    method: "PUT",
    url: "/consult-fees/admin_panel/:doctor_id",
    // preHandler: fastify.authenticate, 
    schema: schemas.getConsultFeesSchema.updateConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesPutHandler(fastify)
  });

};
