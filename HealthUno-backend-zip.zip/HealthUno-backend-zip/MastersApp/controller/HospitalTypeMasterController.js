// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const hospital_type_master_service = require('../services/hospital_type_master_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');


// const FetchHospitalTypes = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospital_type_master_service.GetbyId(id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         data = await cache.GET(req.user.id + '_hospital_type_master');
//         if (data) {
//             res.status(200).json(success_func(JSON.parse(data)))
//         } else {
//             await hospital_type_master_service.Get()
//                 .then(data => {
//                     cache.SET(req.user.id + '_hospital_type_master', data)
//                     res.status(200).json(success_func(data))
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         }
//     }
// }

// const NewHospitalType = async (req, res, next) => {
//     hospital_type_name = req.body.hospital_type_name;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     if (hospital_type_name) {
//         ht_data = {
//             hospital_type_name: hospital_type_name,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         await hospital_type_master_service.GetbyName(hospital_type_name)
//             .then(hospital_type_data => {
//                 if (hospital_type_data.length > 0) {
//                     msg = "Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     hospital_type_master_service.CreateHospitalType(ht_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_hospital_type_master')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     } else {
//         msg = "hospital_type_name and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateHospitalType = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         hospital_type_name = req.body.hospital_type_name;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (hospital_type_name) {
//             ht_data = {
//                 hospital_type_name: hospital_type_name,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }

//             hospital_type_master_service.UpdateHospitalType(id, ht_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_hospital_type_master')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })

//         } else {
//             msg = "hospital_type_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteHospitalType = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospital_type_master_service.DestroyHospitalType(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_hospital_type_master')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


// module.exports = {
//     NewHospitalType,
//     FetchHospitalTypes,
//     UpdateHospitalType,
//     DeleteHospitalType
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const hospital_type_master_service = require('../services/hospital_type_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchHospitalTypes = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospital_type_master_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_hospital_type_master');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await hospital_type_master_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_hospital_type_master', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewHospitalType = async (req, res, next) => {
    hospital_type_name = req.body.hospital_type_name;
    try {
        logo_image = req.files.logo_image;
    } catch {
        logo_image = null
    }
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (hospital_type_name) {
        ht_data = {
            hospital_type_name: hospital_type_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }

        if (logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = logo_image.name;
            const buffer = logo_image.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Upload the image to GCS
            await file.save(buffer);

            ht_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
        } else {
            ht_data.logo_image = null; // Set logo_image to null if not provided
        }
        await hospital_type_master_service.GetbyName(hospital_type_name)
            .then(hospital_type_data => {
                if (hospital_type_data.length > 0) {
                    msg = "Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    hospital_type_master_service.CreateHospitalType(ht_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_hospital_type_master')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "hospital_type_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}



// const UpdateHospitalType = async (req, res, next) => {
//     try {
//         const id = req.params.id;

//         if (!id) {
//             const msg = "ID is required";
//             return res.status(400).json(failure_func(msg));
//         }

//         const hospital_type_name = req.body.hospital_type_name;
//         let logo_image_data;

//         if (req.body.logo_image && req.body.logo_image !== 'undefined') {
//             logo_image_data = req.body.logo_image;
//         } else {
//             const logo_image = req.files.logo_image;

//             if (logo_image) {
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 const fileName = logo_image.name;
//                 const buffer = logo_image.data;
//                 const path = `images/${fileName}`;

//                 const file = storage.bucket(bucketName).file(path);

//                 // Upload the image to GCS
//                 await file.save(buffer);

//                 logo_image_data = `https://storage.googleapis.com/${bucketName}/${path}`;
//             }
//         }

//         const active = req.body.active;
//         const updated_by = req.user.id;
//         const updated_at = date();

//         if (!hospital_type_name) {
//             const msg = "hospital_type_name and active are required";
//             return res.status(400).json(failure_func(msg));
//         }

//         const i_data = {
//             hospital_type_name: hospital_type_name,
//             logo_image: logo_image_data,
//             active: active,
//             updated_by: updated_by,
//             updated_at: updated_at
//         };

//         const data = await hospital_type_master_service.UpdateHospitalType(id, i_data);

//         if (data == 1) {
//             const msg = "Updated successfully";
//             cache.DEL(req.user.id + '_hospital_type_master_service');
//             res.status(200).json(success_func(msg));
//         } else {
//             const msg = "ID doesn't exist";
//             res.status(400).json(failure_func(msg));
//         }
//     } catch (err) {
//         const msg = err.message || "An error occurred";
//         res.status(400).json(failure_func(msg));
//     }
// };

const UpdateHospitalType = async (req, res, next) => {
    img_data = req.body.logo_image
    id = req.params.id;
    if (id) {
        hospital_type_name = req.body.hospital_type_name;
        active = req.body.active;
        if (img_data && img_data != 'undefined') {
            logo_image_data = img_data
        }
        else {
            logo_image = req.files.logo_image;
            if (logo_image) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = logo_image.name;
                const buffer = logo_image.data;
                const path = `images/${fileName}`;

                const file = storage.bucket(bucketName).file(path);

                // Upload the image to GCS
                await file.save(buffer);

                logo_image_data = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
        }
        updated_by = req.user.id;
        updated_at = date();
        if (hospital_type_name) {
            ht_data = {
                hospital_type_name: hospital_type_name,
                logo_image: logo_image_data,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            hospital_type_master_service.UpdateHospitalType(id, ht_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_hospital_type_master')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "hospital_type_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


const DeleteHospitalType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospital_type_master_service.DestroyHospitalType(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_hospital_type_master')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewHospitalType,
    FetchHospitalTypes,
    UpdateHospitalType,
    DeleteHospitalType
}