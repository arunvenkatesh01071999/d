const LabTestCatetory = require('../models/LabInfoModel');
const LabCatetory = require('../../MastersApp/models/LabTestCategoryModel');
const LabInfo = require('../models/LabBasicInfoModel');
const LabTestMaster = require('../../MastersApp/models/LabTestModel');


const Get = async () => {
    await LabTestCatetory.findAll({ include: [LabTestMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (lab_name_id) => {
    await LabTestCatetory.findAll({ where: { lab_name_id: lab_name_id }, include: [LabTestMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyNameId = async (lab_name_id, lab_test_id) => {
    await LabTestCatetory.findAll({ where: { lab_test_id: lab_test_id, lab_name_id: lab_name_id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabService = async (l_data) => {
    await LabTestCatetory.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};


const DestroyLabService = async (id) => {
    await LabTestCatetory.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    GetbyNameId,
    CreateLabService,
    DestroyLabService
};