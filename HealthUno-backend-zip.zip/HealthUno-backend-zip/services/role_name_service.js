const db1 = require('../config/db1');

const roleName = async (id) => {
    const query = `select role_name from roles where id =${id}`;
    const data = await db1.query(query)
    const final = data.flat()
    return final[0].role_name;
}

const serviceName = async (id) => {
    const query = `select role_name, service_id from roles where id =${id}`;
    const data = await db1.query(query)
    const final = data.flat()
    return final[0].service_name;
}

module.exports = roleName, serviceName