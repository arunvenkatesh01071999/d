const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const LabTestCategory = require('../models/LabTestCategoryModel');
const ScanTestMaster = require('../models/ScanTestMasterModel');
const logger = require('../../config/activity_logger');


const LabTestCategoryScanMapping = sequelize.define("lab_tests_category_scan_mapping", {
    lab_test_category_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "lab_test_category_id is required"
            }
        }
    },
    scan_test_master_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

LabTestCategoryScanMapping.belongsTo(LabTestCategory, { foreignKey: 'lab_test_category_id' });
LabTestCategoryScanMapping.belongsTo(ScanTestMaster, { foreignKey: 'scan_test_master_id' });

LabTestCategoryScanMapping.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'lab_tests_category_scan_mapping',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabTestCategoryScanMapping.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'lab_tests_category_scan_mapping',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = LabTestCategoryScanMapping;