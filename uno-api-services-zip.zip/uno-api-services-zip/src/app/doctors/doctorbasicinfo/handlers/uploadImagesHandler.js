const UploadImageService = require("../services/UploadImageService");

function uploadImagesHandler(fastify) {
  const doctorLogin = UploadImageService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await doctorLogin({ body, logTrace, request, reply });
    return reply.code(200).send(response);
  };
}

module.exports = uploadImagesHandler;