## Surgical Care Search

Case 1: By symptoms Ex. chest pain, head ache

Case 2: By Illness (Disease) Ex. Dengu , Malria

Case 3: By Specality

Case 4: By Hospital Name

Case 5. By Surgery

## Logic:

1. List all hospital based on search case, and order by Location ASC (shortest should show first)
