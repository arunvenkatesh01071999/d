const Period = require('../models/PeriodMasterModel');

const Get = async () => {
    await Period.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await Period.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreatePeriod = async (cs_data) => {
    await Period.create(cs_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdatePeriod = async (id, cs_data) => {
    await Period.update(cs_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyPeriod = async (id) => {
    await Period.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (period) => {
    await Period.findAll({ where: { period: period }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreatePeriod,
    UpdatePeriod,
    DestroyPeriod,
    GetbyName
};
