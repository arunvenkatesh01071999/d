const DoctorBasicInfo = require('../../DoctorApp/models/DoctorBasicInfoModel');
const speciality = require('../models/SpecialitiesModel');
const HospitalBasic = require('../../HospitalApp/models/HospitalBasicInfoModel');
const HospitalImages = require('../../HospitalApp/models/HospitalImgModel');





const Get = async () => {

    DoctorBasicInfo.belongsTo(speciality, { foreignKey: 'speciality_id' });
 
    // DoctorBasicInfo.belongsTo(HospitalBasic, { foreignKey: 'hospital_name_id' });
    // HospitalImages .belongsTo(HospitalBasic, { foreignKey: 'hospital_name_id' });
      DoctorBasicInfo.belongsTo(HospitalBasic, { as: 'posts', foreignKey: 'id' });

    await DoctorBasicInfo.findAll({
        include: [speciality,HospitalBasic
          ],
      })


    // await DoctorBasicInfo.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}



module.exports = {
    Get
 
};