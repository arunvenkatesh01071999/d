const hospitalRepo = require("../repository/hospitals");
const {
  getHospitalInfoTransformers
} = require("../transformers/getHospitalInfoTransformers");

function getHospitalService(fastify) {
  const { getHospital } = hospitalRepo(fastify);

  return async ({ body, params, query, logTrace }) => {
    const knex = fastify.knexMaster;
    let lat = query.lat || 13.067439;
    let long = query.long || 80.237617;
    const response = await getHospital.call(knex, {
      params,
      logTrace,
      lat,
      long
    });
    return response;
  };
}
function getHospitalFilterService(fastify) {
  const { getHospitalFilter } = hospitalRepo(fastify);

  return async ({ body, params, query, logTrace }) => {
    const knex = fastify.knexMaster;
    let lat = query.lat || 13.067439;
    let long = query.long || 80.237617;
    const response = await getHospitalFilter.call(knex, {
      params,
      logTrace,
      lat,
      long
    });
    return response;
  };
}

function assignHospitalUserServices(fastify) {
  const { assignHospitalUser } = hospitalRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const response = await assignHospitalUser.call(knex, {
      params,
      body,
      logTrace
    });
    return response;
  };
}
function getHospitalInfoService(fastify) {
  const {
    getHospitalInfo,
    getHospitalAddressInfo,
    getHospitalContactInfo,
    getHospitalInfraInfo,
    getHospitalRoomInfo,
    getHospitalDepartmentInfo,
    getHospitalSpecialityInfo,
    getHospitalServiceInfo,
    getHospitalLabInfo,
    getHospitalScanInfo,
    getHospitalInsuranceInfo,
    getHospitalOfficialInfo,
    getHospitalTermsInfo,
    getHospitalPaymentInfo,
    getHospitalDoctorInfo
  } = hospitalRepo(fastify);

  return async ({ body, params, query, logTrace }) => {
    const knex = fastify.knexMaster;
    let lat = query.lat || 13.067439;
    let long = query.long || 80.237617;
    const promise1 = getHospitalInfo.call(knex, {
      params,
      logTrace
    });
    const promise2 = getHospitalAddressInfo.call(knex, {
      params,
      logTrace,
      lat,
      long
    });
    const promise3 = getHospitalContactInfo.call(knex, {
      params,
      logTrace
    });
    const promise4 = getHospitalInfraInfo.call(knex, {
      params,
      logTrace
    });
    const promise5 = getHospitalRoomInfo.call(knex, {
      params,
      logTrace
    });
    const promise6 = getHospitalDepartmentInfo.call(knex, {
      params,
      logTrace
    });
    const promise7 = getHospitalSpecialityInfo.call(knex, {
      params,
      logTrace
    });
    const promise8 = getHospitalServiceInfo.call(knex, {
      params,
      logTrace
    });
    const promise9 = getHospitalLabInfo.call(knex, {
      params,
      logTrace
    });
    const promise10 = getHospitalScanInfo.call(knex, {
      params,
      logTrace
    });
    const promise11 = getHospitalInsuranceInfo.call(knex, {
      params,
      logTrace
    });
    const promise12 = getHospitalOfficialInfo.call(knex, {
      params,
      logTrace
    });
    const promise13 = getHospitalTermsInfo.call(knex, {
      params,
      logTrace
    });
    const promise14 = getHospitalPaymentInfo.call(knex, {
      params,
      logTrace
    });
    const promise15 = getHospitalDoctorInfo.call(knex, {
      params,
      logTrace
    });

    const [
      hospitalInfo,
      hospitalAddressInfo,
      hospitalContactInfo,
      hospitalInfraInfo,
      hospitalRoomInfo,
      hospitalDepartInfo,
      hospitalSpecialityInfo,
      hospitalServiceInfo,
      hospitalLabInfo,
      hospitalScanInfo,
      hospitalInsuranceInfo,
      hospitalOfficalInfo,
      hospitalTermsInfo,
      hospitalPaymentInfo,
      hospitalDoctorInfo
    ] = await Promise.all([
      promise1,
      promise2,
      promise3,
      promise4,
      promise5,
      promise6,
      promise7,
      promise8,
      promise9,
      promise10,
      promise11,
      promise12,
      promise13,
      promise14,
      promise15
    ]);

    hospitalPaymentInfoTransformed = hospitalPaymentInfo.map(item => {
      let payment_name;
      switch (item.check) {
        case 0:
          payment_name = "SMARTCARD";
          break;
        case 1:
          payment_name = "NORMAL";
          break;

        default:
          payment_name = ""; // Default value if no match
          break;
      }
      return {
        payment_name,
        ...item
      };
    });

    return getHospitalInfoTransformers({
      hospitalInfo,
      hospitalAddressInfo,
      hospitalContactInfo,
      hospitalInfraInfo,
      hospitalRoomInfo,
      hospitalDepartInfo,
      hospitalSpecialityInfo,
      hospitalServiceInfo,
      hospitalLabInfo,
      hospitalScanInfo,
      hospitalInsuranceInfo,
      hospitalOfficalInfo,
      hospitalTermsInfo,
      hospitalPaymentInfoTransformed,
      hospitalDoctorInfo
    });
  };
}
function getHospitalInfoByUserService(fastify) {
  const { getHospitalInfoByUser } = hospitalRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = getHospitalInfoByUser.call(knex, {
      params,
      logTrace
    });

    const [hospitalInfo] = await Promise.all([promise1]);

    return getHospitalInfoTransformers({
      hospitalInfo
    });
  };
}

module.exports = {
  getHospitalService,
  getHospitalInfoService,
  getHospitalFilterService,
  assignHospitalUserServices,
  getHospitalInfoByUserService
};
