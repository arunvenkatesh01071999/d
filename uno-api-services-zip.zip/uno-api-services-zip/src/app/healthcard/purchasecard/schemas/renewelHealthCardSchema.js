const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const renewelHealthCardSchema = {
  tags: ["HEALTH CARD RENEWEL"],
  summary: "This API is to purchase health cards",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["patient_id", "card_type_id", "razor_payment_id", "card_id"],
    properties: {
      card_id: { type: "integer" },
      patient_id: { type: "integer" },
      card_type_id: { type: "integer" },
      razor_payment_id: { type: "string" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = renewelHealthCardSchema;
