const getBannerBasicInfos = require("../services/getBannerBasicInfo");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream")
// const pump = util.promisify(pipeline);


function getBannerBasicInfoHandler(fastify) {
  const getBannerBasicInfo =
    getBannerBasicInfos.getbannerBasicInfoService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getBannerBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}


function getBannerBasicInfoByIdHandler(fastify) {
  const getBannerBasicInfo =
    getBannerBasicInfos.getbannerBasicInfoByIdService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getBannerBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

// function getBannerBasicpostInfoHandler(fastify) {
//   const getBannerBasicInfo =
//     getBannerBasicInfos.getbannerpostBasicInfoService(fastify);

//   return async (request, reply) => {
//     // const partes = request.body.banner_images;
//     const originalObject = request.body;

//     const convertedData = {};
//     for (const key in originalObject) {

//       if (Object.hasOwnProperty.call(originalObject, key)) {
//         convertedData[key] = originalObject[key].value;
//       }
//     }

//     // if (partes.filename == '') {
//     //   convertedData[partes.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
//     //   convertedData[partes.fieldname] = partes.filename;

//     // }
//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await getBannerBasicInfo({
//       body,
//       params,
//       logTrace,
//       userDetails,
//       convertedData
//     });
//     return reply.code(200).send(response);
//   };
// }

function getBannerBasicpostInfoHandler(fastify) {
  const getBannerBasicInfo =
    getBannerBasicInfos.getbannerpostBasicInfoService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getBannerBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

// function getBannerBasicputInfoHandler(fastify) {
//   const getBannerBasicInfo =
//     getBannerBasicInfos.getbannerputBasicInfoService(fastify);

//   return async (request, reply) => {

//     // const partes = request.body.banner_images;
//     const originalObject = request.body;
//     const convertedData = {};


//     for (const key in originalObject) {

//       if (Object.hasOwnProperty.call(originalObject, key)) {
//         convertedData[key] = originalObject[key].value;
//       }
//     }

//     // if (partes.filename == '') {
//     //   convertedData[partes.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
//     //   convertedData[partes.fieldname] = partes.filename;

//     // }
//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await getBannerBasicInfo({
//       body,
//       params,
//       logTrace,
//       userDetails,
//       convertedData
//     });
//     return reply.code(200).send(response);
//   };
// }

function getBannerBasicputInfoHandler(fastify) {
  const getBannerBasicInfo =
    getBannerBasicInfos.getbannerputBasicInfoService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getBannerBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getBannerBasicdeleteInfoHandler(fastify) {
  const getBannerBasicInfo =
    getBannerBasicInfos.getbannerdeleteBasicInfoService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getBannerBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = {
  getBannerBasicInfoHandler,
  getBannerBasicInfoByIdHandler,
  getBannerBasicpostInfoHandler,
  getBannerBasicputInfoHandler,
  getBannerBasicdeleteInfoHandler
};
