// const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "GET",
    url: "/ehr-pdf/:patient_id/:doctor_id",
    // schema: schemas.getCheifComplaintsSchema.getCheifComplaintsSchema,
    handler: handlers.getEhrPdfHandler.getEhrPdfInfoHandler(fastify)
  });

}