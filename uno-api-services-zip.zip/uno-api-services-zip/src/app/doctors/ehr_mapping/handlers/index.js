const getEhrMapping = require('./getEhrMapping');

module.exports = {
    getEhrMapping
}