const getFollowUpInfo = require('../repository/getFollowUpInfo');

function getFollowUpPostInfoService(fastify) {

  const { getAddFollow } = getFollowUpInfo.followupRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexPatient;

    const promise1 = getAddFollow.call(knex, {
      logTrace,
      params,
      body
    });

    const [getAddFollowdata] = await Promise.all([promise1]);

    return getAddFollowdata;
  };
}

function getehrsubmitPostInfoService(fastify) {

  const { getAddEhrSubmit } = getFollowUpInfo.getAddEhrSubmitRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexPatient;

    const promise1 = getAddEhrSubmit.call(knex, {
      logTrace,
      params,
      body
    });

    const [getAddEhrSubmitdata] = await Promise.all([promise1]);

    return getAddEhrSubmitdata;
  };
}

///---------------------- ADMIN PANEL ------------------

function adminFollowUpPostInfoService(fastify) {

  const { adminaGetAddFollow } = getFollowUpInfo.adminFollowupRepos(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexPatient;

    const promise1 = adminaGetAddFollow.call(knex, {
      logTrace,
      params,
      body
    });

    const [getAddFollowdata] = await Promise.all([promise1]);

    return getAddFollowdata;
  };
}

module.exports = {
  getFollowUpPostInfoService,
  getehrsubmitPostInfoService,
  adminFollowUpPostInfoService
}