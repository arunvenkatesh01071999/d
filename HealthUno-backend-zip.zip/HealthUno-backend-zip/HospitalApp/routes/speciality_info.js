const express = require('express');
const router = express();
const SpecialityMappingController = require('../controller/SpecialityInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, SpecialityMappingController.FetchSpecialityInfo);
router.get('/:hospital_name_id', verify_token, SpecialityMappingController.FetchSpecialityInfo);
router.post('/', verify_token, SpecialityMappingController.NewSpecialityInfo);
router.put('/:hospital_name_id', verify_token, SpecialityMappingController.UpdateSpecialityInfo);

module.exports = router;