const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { PASTMEDICALHISTORY } = require("../commons/constants");

const { ILLNESSTYPE } = require("../commons/constants");

const { CustomError } = require("../../../../errorHandler");

const UploadImageService = require("../../../../commons/imageupload");

function postPastMedicalHistoryRepositoryBasic(fastify) {
  async function PastMedicalHistoryAdd({ logTrace, body }) {

    const knex = this;

    const processedDiseases = []
    const processedDiseases1 = []


    // const health_record_details = body.health_record_details;

    // if(health_record_details.filename != ''){

    //   const img = UploadImageService(health_record_details, fastify);
    //   var imgurl = img.image_url;
    // }else{
    //     var imgurl = null;
    // }

    // if (health_record_details !== '' && health_record_details !== undefined) {
    //   if (health_record_details.filename !== undefined && health_record_details.filename !== '') {
    //     const img = await UploadImageService(health_record_details, fastify);
    //     var imgurl = img.image_url;
    //   }
    //   else {
    //     var imgurl = null;
    //   }
    // }
    // else {
    //   var imgurl = null;
    // }
    const medicineArray = [];
    const surgeryArray = [];
    const allergyArray = [];
    const vacinationArray = [];

    const medicine = body.past_medicine
    console.log(medicine,"medicine");
    medicineArray.push(medicine);
    console.log(medicineArray,"medicineArray");
    var medicineResult = medicineArray.join(" , ");
    console.log(medicineResult,"medicineResult");

    const surgery = body.past_surgeries
    surgeryArray.push(surgery)
    var surgeryResult = surgeryArray.join(" , ");

    var allergy = body.history_of_allergy
    allergyArray.push(allergy)
    var allergyResult = allergyArray.join(" , ");

    var vacination = body.previous_vacination
    vacinationArray.push(vacination)
    var vacinationResult = vacinationArray.join(" , ");

    let past_illness = body.past_illness
    processedDiseases1.push(past_illness)

    const illnessNames = await knex.raw(`select illness_type_name from illness_types`)
      .then(response => response.map(illness => illness.illness_type_name));

    for (let disease of processedDiseases1) {

      if (!illnessNames.includes(disease)) {
        try {
          await knex(`${ILLNESSTYPE.NAME}`).insert({
            [ILLNESSTYPE.COLUMNS.ILLNESS_TYPE_NAME]: disease,
            [ILLNESSTYPE.COLUMNS.LOGO_IMAGE]: null,
            [ILLNESSTYPE.COLUMNS.ACTIVE]: body.active,
            [ILLNESSTYPE.COLUMNS.CREATED_BY]: body.created_by,
            [ILLNESSTYPE.COLUMNS.UPDATED_BY]: body.created_by,
            [ILLNESSTYPE.COLUMNS.CREATED_AT]: new Date(),
            [ILLNESSTYPE.COLUMNS.UPDATED_AT]: new Date()
          });
        } catch (error) {
          console.error("Error Inserting Disease:", error);
        }
      }
      processedDiseases.push(disease);
    }
    let illnessResult = processedDiseases.join(',');

    let myObject = {
      doctor_id: body.doctor_id,
      patient_id: body.patient_id,
      imgurl: null,
      illnessResult: illnessResult,
      medicineResult: medicineResult,
      surgeryResult: surgeryResult,
      allergyResult: allergyResult,
      vacinationResult: vacinationResult,
      pregnancy: body.pregnancy,
      is_trimester: body.is_trimester,
      is_lactation: body.is_lactation,
      created_by: body.created_by,
      active: body.active
    }
    // console.log(myObject,"myObject");
    try {
      const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({
        [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: myObject.doctor_id,
        [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: myObject.patient_id,
        [PASTMEDICALHISTORY.COLUMNS.HEALTH_RECORD_DETAILS]: myObject.imgurl,
        [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: myObject.illnessResult,
        [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: myObject.medicineResult,
        [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERIES]: myObject.surgeryResult,
        [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: myObject.allergyResult,
        [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: myObject.vacinationResult,
        [PASTMEDICALHISTORY.COLUMNS.PREGNANCY]: myObject.pregnancy,
        [PASTMEDICALHISTORY.COLUMNS.IS_TRIMESTER]: myObject.is_trimester,
        [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: myObject.is_lactation,
        [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: myObject.created_by,
        [PASTMEDICALHISTORY.COLUMNS.ACTIVE]: myObject.active,
      });
    }
    catch (error) {
      console.error("Error Inserting Past medical history:", error);
    }
    return { success: true, message: "Insert successfully" };
  }
  return {
    PastMedicalHistoryAdd

  };
}

function updatePastMedicalHistoryRepository(fastify) {
  async function PastMedicalHistoryUpdate({ logTrace, body, params }) {
    const knex = this;

    var patient_id = params.patient_id;
    var doctor_id = body.doctor_id

    // console.log(doctor_id,"doctor_id");
    // const health_record_details = body.health_record_details;
    // if(health_record_details.filename != ''){
    //   const img = UploadImageService(health_record_details, fastify);
    //   var imgurl = img.image_url;
    // }else{
    //     var imgurl = null;
    // }
    // if (health_record_details !== '' && health_record_details !== undefined) {
    //   if (health_record_details.filename !== undefined && health_record_details.filename !== '') {
    //     const img = await UploadImageService(health_record_details, fastify);
    //     var imgurl = img.image_url;
    //   }
    //   else {
    //     var imgurl = null;
    //   }
    // }
    // else {
    //   var imgurl = null;
    // }
    const processedDiseases = []
    const processedDiseases1 = []

    const medicineArray = [];
    const surgeryArray = [];
    const allergyArray = [];
    const vacinationArray = [];

    const medicine = body.past_medicine
    // console.log(medicine,"medicine");
    medicineArray.push(medicine);
    // console.log(medicineArray,"medicineArray");
    var medicineResult = medicineArray.join(" , ");
    // console.log(medicineResult,"medicineResult");

    const surgery = body.past_surgeries
    surgeryArray.push(surgery)
    var surgeryResult = surgeryArray.join(" , ");

    var allergy = body.history_of_allergy
    allergyArray.push(allergy)
    var allergyResult = allergyArray.join(" , ");

    var vacination = body.previous_vacination
    vacinationArray.push(vacination)
    var vacinationResult = vacinationArray.join(" , ");

    let past_illness = body.past_illness
    processedDiseases1.push(past_illness)

    const past_illnessDb = await knex.raw(`select top 1 past_illness from e_past_medical_history
     where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)
      .then(response => response.map(illness => illness.past_illness));

    const difference = processedDiseases1.filter(item => !past_illnessDb.includes(item));
    
    const pastMedicalHistoryId = await knex.raw(`select top 1 id from e_past_medical_history
     where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)
    const id = pastMedicalHistoryId[0].id

    if (difference.length === 0) {

      const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, id)
        .del();

        processedDiseases.push(past_illness);
      illnessResult = processedDiseases.join(" , ")
      let myObject = {
        doctor_id: body.doctor_id,
        patient_id: body.patient_id,
        imgurl: null,
        illnessResult: illnessResult,
        medicineResult: medicineResult,
        surgeryResult: surgeryResult,
        allergyResult: allergyResult,
        vacinationResult: vacinationResult,
        pregnancy: body.pregnancy,
        is_trimester: body.is_trimester,
        is_lactation: body.is_lactation,
        created_by: body.created_by,
        active: body.active
      }
      try {
        const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({
          [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: myObject.doctor_id,
          [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: myObject.patient_id,
          [PASTMEDICALHISTORY.COLUMNS.HEALTH_RECORD_DETAILS]: myObject.imgurl,
          [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: myObject.illnessResult,
          [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: myObject.medicineResult,
          [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERIES]: myObject.surgeryResult,
          [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: myObject.allergyResult,
          [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: myObject.vacinationResult,
          [PASTMEDICALHISTORY.COLUMNS.PREGNANCY]: myObject.pregnancy,
          [PASTMEDICALHISTORY.COLUMNS.IS_TRIMESTER]: myObject.is_trimester,
          [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: myObject.is_lactation,
          [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: myObject.created_by,
          [PASTMEDICALHISTORY.COLUMNS.ACTIVE]: myObject.active
        });
      } catch (error) {
        console.error("Error Inserting Past Medical History:", error);
      }
    }
    else {
      const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, id)
        .del();

      processedDiseases.push(past_illness);
      illnessResult = processedDiseases.join(" , ")

      let myObject = {
        doctor_id: body.doctor_id,
        patient_id: body.patient_id,
        imgurl: null,
        illnessResult: illnessResult,
        medicineResult: medicineResult,
        surgeryResult: surgeryResult,
        allergyResult: allergyResult,
        vacinationResult: vacinationResult,
        pregnancy: body.pregnancy,
        is_trimester: body.is_trimester,
        is_lactation: body.is_lactation,
        created_by: body.created_by,
        active: body.active
      }
      try {
        const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({
          [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: myObject.doctor_id,
          [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: myObject.patient_id,
          [PASTMEDICALHISTORY.COLUMNS.HEALTH_RECORD_DETAILS]: myObject.imgurl,
          [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: myObject.illnessResult,
          [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: myObject.medicineResult,
          [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERIES]: myObject.surgeryResult,
          [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: myObject.allergyResult,
          [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: myObject.vacinationResult,
          [PASTMEDICALHISTORY.COLUMNS.PREGNANCY]: myObject.pregnancy,
          [PASTMEDICALHISTORY.COLUMNS.IS_TRIMESTER]: myObject.is_trimester,
          [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: myObject.is_lactation,
          [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: myObject.created_by,
          [PASTMEDICALHISTORY.COLUMNS.ACTIVE]: myObject.active,
        });
      } catch (error) {
        console.error("Error Inserting Chief Complaints:", error);
      }

      const illnessNames = await knex.raw(`select illness_type_name from illness_types`)
        .then(response => response.map(illness => illness.illness_type_name));

      for (let disease of difference) {
        if (!illnessNames.includes(disease)) {
          try {
            await knex(`${ILLNESSTYPE.NAME}`).insert({
              [ILLNESSTYPE.COLUMNS.ILLNESS_TYPE_NAME]: disease,
              [ILLNESSTYPE.COLUMNS.LOGO_IMAGE]: null,
              [ILLNESSTYPE.COLUMNS.ACTIVE]: body.active,
              [ILLNESSTYPE.COLUMNS.CREATED_BY]: body.created_by,
              [ILLNESSTYPE.COLUMNS.UPDATED_BY]: body.created_by,
              [ILLNESSTYPE.COLUMNS.CREATED_AT]: new Date(),
              [ILLNESSTYPE.COLUMNS.UPDATED_AT]: new Date()
            });
          } catch (error) {
            console.error("Error Inserting Disease:", error);
          }
        }
      }
    }
    return { success: true, message: "Update successfully" };
  }

  return {
    PastMedicalHistoryUpdate,
  };
}

function getPastMedicalHistoryRepository(fastify) {

  async function PastMedicalHistoryGetAlls({ logTrace }) {

    const knex = this;
    const query = knex.select('*').from(`${PASTMEDICALHISTORY.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get PastMedicalHistory Details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "PastMedicalHistory info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PastMedicalHistoryGetAlls
  };

}


function getPastMedicalHistoryRepositoryId(fastify) {

  async function PastMedicalHistoryGetOne({ logTrace, params }) {

    const knex = this;
    var patient_id = params.patient_id;
    var doctor_id = params.doctor_id;

    

    const query = knex.raw(`select top 1 * from e_past_medical_history
    where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)

    logQuery({
      logger: fastify.log,
      query,
      params,
      context: "Get PastMedicalHistory details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "PastMedicalHistory info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }

  return {
    PastMedicalHistoryGetOne
  };

}


function deletePastMedicalHistoryRepositoryId(fastify) {
  async function PastMedicalHistoryDelete({
    logTrace,
    params
  }) {
    const knex = this;

    var patient_id = params.patient_id;
    const doctor_id = params.doctor_id;

    const pastMedicalHistoryId = await knex.raw(`select top 1 id from e_past_medical_history
    where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)

    const id = pastMedicalHistoryId[0].id

    const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    PastMedicalHistoryDelete
  };
}


module.exports = {
  postPastMedicalHistoryRepositoryBasic,
  updatePastMedicalHistoryRepository,
  getPastMedicalHistoryRepository,
  getPastMedicalHistoryRepositoryId,
  deletePastMedicalHistoryRepositoryId

};
