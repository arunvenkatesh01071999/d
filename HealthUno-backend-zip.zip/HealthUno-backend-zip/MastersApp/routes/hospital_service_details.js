const express = require('express');
const router = express();
const HospitalServiceDetailsController = require('../controller/HospitalServicesDetailcontroller');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, HospitalServiceDetailsController.FetchHospitalServiceDetails);
router.get('/:hospital_services_id', verify_token, HospitalServiceDetailsController.FetchHospitalServiceDetails);
router.post('/', verify_token, HospitalServiceDetailsController.CreateHospitalServiceDetails);
router.put('/:hospital_services_id', verify_token, HospitalServiceDetailsController.UpdateHospitalServiceDetails);
router.delete('/:id', verify_token, HospitalServiceDetailsController.DeleteHospitalServiceDetails);


module.exports = router;