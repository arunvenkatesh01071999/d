const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/slot",
    preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getSlotInfoHandler(fastify)
  });


  fastify.route({
    method: "GET",
    url: "/slot/:doctor_name_id",
    preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getSlotInfoByIdHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/slot",
    preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotpostBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getslotInfoHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/slot/:doctor_name_id",
    preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotputBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getslotputInfoHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/slot/return",
    preHandler: fastify.authenticate,
    handler: handlers.getSlotBasicInfo.getslotGetReturnInfoHandler(fastify)
  });

  // fastify.route({
  //   method: "DELETE",
  //   url: "/Slot/delete/:id",
  //   schema: schemas.getSlotBasicInfo.getservicedeleteBasicInfoSchema,
  //   handler: handlers.getSlotBasicInfo.getSlotdeleteInfoHandler(fastify)
  // });

  // fastify.route({
  //   method: "POST",
  //   url: "/Slot/generateotp",
  //   // schema: schemas.getSlotBasicInfo.getservicedeleteBasicInfoSchema,
  //   handler: handlers.getSlotBasicInfo.getGenerateotp(fastify)
  // });



  //admin_panel


  fastify.route({
    method: "POST",
    url: "/slot/admin_panel",
    // preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotpostBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getslotInfoHandler(fastify)
  });


  fastify.route({
    method: "GET",
    url: "/slot/admin_panel/:doctor_name_id",
    // preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getSlotInfoByIdHandler(fastify)
  });

   fastify.route({
    method: "PUT",
    url: "/slot/admin_panel/:doctor_name_id",
    // preHandler: fastify.authenticate,
    // schema: schemas.getSlotBasicInfo.getSlotputBasicInfoSchema,
    handler: handlers.getSlotBasicInfo.getslotputInfoHandler(fastify)
  });

};
