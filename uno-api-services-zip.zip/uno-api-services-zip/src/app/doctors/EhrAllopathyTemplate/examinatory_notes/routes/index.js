const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/examinatory-notes",
    preHandler: fastify.authenticate,
    schema: schemas.getExaminatoryNotesSchema.createExaminatoryNotesSchema,
    handler: handlers.getExaminatoryNotesHandler.createExaminatoryNotesHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/examinatory-notes/:patient_id",
    preHandler: fastify.authenticate,
    schema: schemas.getExaminatoryNotesSchema.updateExaminatoryNotesSchema,
    handler: handlers.getExaminatoryNotesHandler.updateExaminatoryNotesHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/examinatory-notes",
    preHandler: fastify.authenticate,
    schema: schemas.getExaminatoryNotesSchema.getExaminatoryNotesSchema,
    handler: handlers.getExaminatoryNotesHandler.getExaminatoryNotesHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/examinatory-notes/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
   schema: schemas.getExaminatoryNotesSchema.getExaminatoryNotesSchema,
    handler: handlers.getExaminatoryNotesHandler.getExaminatoryNotesHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/examinatory-notes/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
   schema: schemas.getExaminatoryNotesSchema.deleteExaminatoryNotesSchema,
    handler: handlers.getExaminatoryNotesHandler.deleteExaminatoryNotesHandler(fastify)
  });

};
