const express = require('express');
const router = express();
const FeesTypeMasterController = require('../controller/FeesTypeMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, FeesTypeMasterController.FetchFeesTypes);
router.get('/:id', verify_token, FeesTypeMasterController.FetchFeesTypes);
router.post('/', verify_token, FeesTypeMasterController.NewFeesTypes);
router.put('/:id', verify_token, FeesTypeMasterController.UpdateFeesTypes);
router.delete('/:id', verify_token, FeesTypeMasterController.DeleteFeesTypes);

module.exports = router;