const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const specialities_service = require('../services/specialities_service');
const speciality_illness_mapping_service = require('../services/speciality_illness_mapping_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();


const FetchSpecialities = async (req, res, next) => {
    const id = req.params.id;
    if (id) {
        await specialities_service.GetbyRelationsbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        //    const data = await cache.GET(req.user.id + '_specialities');
        //     if (data) {
        //         res.status(200).json(success_func(JSON.parse(data)))
        //     } else {
        await specialities_service.GetbyRelations()
            .then(data => {
                // cache.SET(req.user.id + '_specialities', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        // }
    }
}

// const NewSpeciality = async (req, res, next) => {
//     const speciality_name = req.body.speciality_name;
//     const illness_type_ids = req.body.illness_type_ids;
//     const active = req.body.active;
//     const created_by = req.user.id;
//     const updated_by = req.user.id;
//     // if (speciality_name) {
//     if (speciality_name && illness_type_ids && Array.isArray(illness_type_ids)) {
//         s_data = {
//             speciality_name: speciality_name,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         // await specialities_service.GetbyName(speciality_name)
//         //     .then(type_data => {
//         //         if (type_data.length > 0) {
//         //             msg = "Scan Type Name already exists";
//         //             return res.status(200).json(failure_func(msg))
//         //         } else {
//         specialities_service.CreateSpeciality(s_data)
//             .then(data => {
//                 if (data.errors) {
//                     msg = data.errors[0].message;
//                     res.status(400).json(failure_func(msg))
//                 } else {

//                     splty_data = data.dataValues;
//                     splty_id = splty_data.id;
//                     // console.log(splty_data);
//                     if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
//                         for (const i of illness_type_ids) { // Use for...of loop
//                             const nt_data = {
//                                 speciality_id: splty_id,
//                                 illness_type_id: i,
//                                 active: active,
//                                 created_by: created_by,
//                                 updated_by: updated_by
//                             }
//                             // console.log(nt_data);
//                             speciality_illness_mapping_service.CreateSpecialityIllnessMapping(nt_data);
//                         }
//                     }
//                     msg = "Created Successfully"
//                     cache.DEL(req.user.id + '_specialities')
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//         //     }
//         // })
//     } else {
//         // msg = "speciality_name and active is required";
//         msg = "speciality_name, illness_type_ids and active is required and illness_type_ids should be an array";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const NewSpeciality = async (req, res, next) => {
//     // try {
//         const speciality_name = req.body.speciality_name;
//         let illness_type_ids = req.body.illness_type_ids;
//         const logo_image = req.files.logo_image;
//         const active = req.body.active;
//         const created_by = req.user.id;
//         const updated_by = req.user.id;
//         // Convert string to array if it's a string
//         if (typeof illness_type_ids === 'string') {
//             illness_type_ids = JSON.parse(illness_type_ids);
//         }
//         if (speciality_name && Array.isArray(illness_type_ids) && active !== undefined) {
//             const s_data = {
//                 speciality_name: speciality_name,
//                 active: active,
//                 created_by: created_by,
//                 updated_by: updated_by
//             };
//             if (logo_image) {
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 const fileName = logo_image.name;
//                 const buffer = logo_image.data;
//                 const path = `images/${fileName}`;
//                 const file = storage.bucket(bucketName).file(path);
//                 // Upload the image to GCS
//                 await file.save(buffer);
//                 s_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
//             } else {
//                 s_data.logo_image = null;
//             }
//             const specialityData = await specialities_service.CreateSpeciality(s_data);
//             if (specialityData.errors) {
//                 const msg = specialityData.errors[0].message;
//                 return res.status(400).json(failure_func(msg));
//             }
//             const splty_id = specialityData.dataValues.id;
//             if (illness_type_ids.length > 0) {
//                 for (const i of illness_type_ids) {
//                     const nt_data = {
//                         speciality_id: splty_id,
//                         illness_type_id: i,
//                         active: active,
//                         created_by: created_by,
//                         updated_by: updated_by
//                     };
//                     await speciality_illness_mapping_service.CreateSpecialityIllnessMapping(nt_data);
//                 }
//             }
//             const msg = "Created Successfully";
//             cache.DEL(req.user.id + '_specialities');
//             res.status(200).json(success_func(msg));
//         } else {
//             const msg = "speciality_name, illness_type_ids, and active are required, and illness_type_ids should be an array";
//             res.status(400).json(failure_func(msg));
//         }
//     // }
//     // catch (err) {
//     //     res.status(500).json(failure_func(err.message));
//     // }
// };

// const UpdateSpeciality = async (req, res, next) => {
//     try {
//         const id = req.params.id;
//         if (!id) {
//             const msg = "ID is required";
//             return res.status(400).json(failure_func(msg));
//         }
//         const speciality_name = req.body.speciality_name;
//         let illness_type_ids = req.body.illness_type_ids;
//         if (req.files && req.files.logo_image && req.files.logo_image.name) {
//             logo_image = req.files.logo_image;
//         } else {

//             logo_image = req.body.logo_image;
//         }
//         const active = req.body.active;
//         const created_by = req.user.id;
//         const updated_by = req.user.id;
//         const updated_at = date();
//         // Convert string to array if it's a string
//         if (typeof illness_type_ids === 'string') {
//             illness_type_ids = JSON.parse(illness_type_ids);
//         }
//         if (speciality_name && Array.isArray(illness_type_ids) && active !== undefined) {
//             const s_data = {
//                 speciality_name: speciality_name,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             };
//             if (typeof logo_image === "string") {
//                 s_data.logo_image = logo_image;
//             }
//             else {
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 const fileName = logo_image.name;
//                 const buffer = logo_image.data;
//                 const path = `images/${fileName}`;

//                 const file = storage.bucket(bucketName).file(path);

//                 // Upload the image to GCS
//                 await file.save(buffer);
//                 s_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;

//             }

//             // if (req.files && req.files.logo_image) {

//                 // const bucketName = process.env.GCP_BUCKET_NAME;
//                 // const fileName = req.files.logo_image.name;
//                 // const buffer = req.files.logo_image.data;
//                 // const path = `images/${fileName}`;
//                 // const file = storage.bucket(bucketName).file(path);
//                 // // Upload the image to GCS
//                 // await file.save(buffer);
//                 // s_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
//             // }
//             const updateResult = await specialities_service.UpdateSpeciality(id, s_data);
//             if (updateResult === 1) {
//                 if (illness_type_ids.length > 0) {
//                     // Delete existing mappings
//                     await speciality_illness_mapping_service.DestroySpecialityIllnessMappingbySpeciality(id);
//                     // Create new mappings
//                     for (const i of illness_type_ids) {
//                         const nt_data = {
//                             speciality_id: id,
//                             illness_type_id: i,
//                             active: active,
//                             created_by: created_by,
//                             updated_by: updated_by
//                         };
//                         await speciality_illness_mapping_service.CreateSpecialityIllnessMapping(nt_data);
//                     }
//                 }
//                 const msg = "Updated successfully";
//                 cache.DEL(req.user.id + '_specialities');
//                 return res.status(200).json(success_func(msg));
//             } else {
//                 const msg = "ID doesn't exist";
//                 return res.status(400).json(failure_func(msg));
//             }
//         } else {
//             const msg = "speciality_name, illness_type_ids, and active are required, and illness_type_ids should be an array";
//             return res.status(400).json(failure_func(msg));
//         }
//     } catch (err) {
//         return res.status(500).json(failure_func(err.message));
//     }
// };

const NewSpeciality = async (req, res, next) => {
    const speciality_name = req.body.speciality_name;
    const logo_image =req.files ? req.files.logo_image : null;
    const active = req.body.active;
    const created_by = 2
    const updated_by = created_by
    var illness_type_id=req.body.illness_type_ids
    const illness_type_ids = illness_type_id.split(',').map(Number)
    if (speciality_name && Array.isArray(illness_type_ids) && active !== undefined) {
        const s_data = {
            speciality_name: speciality_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };
        if (logo_image != null) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = logo_image.name;
            const buffer = logo_image.data;
            const path = `images/${fileName}`;
            const file = storage.bucket(bucketName).file(path);
            await file.save(buffer);
            s_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            s_data.logo_image = null;
        }
        const specialityData = await specialities_service.CreateSpeciality(s_data);
        console.log(specialityData,"specialityData");
        if (specialityData.errors) {
            const msg = specialityData.errors[0].message;
            return res.status(400).json(failure_func(msg));
        }
        const splty_id = specialityData.dataValues.id;
            for (let j = 0; j < illness_type_ids.length; j++) {
                const i = illness_type_ids[j];
                const nt_data = {
                    speciality_id: splty_id,
                    illness_type_id: i,
                    active: parseInt(active),
                    created_by: parseInt(created_by),
                    updated_by: parseInt(updated_by)
                };
                await speciality_illness_mapping_service.CreateSpecialityIllnessMapping(nt_data);
            }
        const msg = "Created Successfully";
        // cache.DEL(req.user.id + '_specialities');
        res.status(200).json(success_func(msg));
    }
     else {
        const msg = "speciality_name, illness_type_ids, and active are required, and illness_type_ids should be an array";
        res.status(400).json(failure_func(msg));
    }
};

const UpdateSpeciality = async (req, res, next) => {
    try {
        const id = req.params.id;
        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }
        const speciality_name = req.body.speciality_name;
        // var illness_type_ids = req.body.illness_type_ids;
        var illness_type_id=req.body.illness_type_ids
        const illness_type_ids = illness_type_id.split(',').map(Number)
        var logo_image = req.files ? req.files.logo_image : null;
        const active = req.body.active;
        var created_by = 2
        var updated_by = 2
        if (speciality_name && Array.isArray(illness_type_ids) && active !== undefined) {
            const s_data = {
                speciality_name: speciality_name,
                active: active,
                updated_by: 2
            }
            if (logo_image != null) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = logo_image.name;
                const buffer = logo_image.data;
                const path = `images/${fileName}`;
                const file = storage.bucket(bucketName).file(path);
                await file.save(buffer);
                s_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
            const updateResult = await specialities_service.UpdateSpeciality(id, s_data);
            if (updateResult === 1) {
                if (illness_type_ids.length > 0) {
                    await speciality_illness_mapping_service.DestroySpecialityIllnessMappingbySpeciality(id);
                    for (const i of illness_type_ids) {
                        const nt_data = {
                            speciality_id: id,
                            illness_type_id: i,
                            active: active,
                            created_by: created_by,
                            updated_by: updated_by
                        };
                        await speciality_illness_mapping_service.CreateSpecialityIllnessMapping(nt_data);
                    }
                }
                const msg = "Updated successfully";
                // cache.DEL(req.user.id + '_specialities');
                return res.status(200).json(success_func(msg));
            } else {
                const msg = "ID doesn't exist";
                return res.status(400).json(failure_func(msg));
            }
        } else {
            const msg = "speciality_name, illness_type_ids, and active are required, and illness_type_ids should be an array";
            return res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        return res.status(500).json(failure_func(err.message));
    }
};
// const UpdateSpeciality = async (req, res, next) => {
//     const id = req.params.id;
//     if (id) {
//         const speciality_name = req.body.speciality_name;
//         const illness_type_ids = req.body.illness_type_ids;
//         const active = req.body.active;
//         const created_by = req.user.id;
//         const updated_by = req.user.id;
//         const updated_at = date();
//         if (speciality_name) {
//             s_data = {
//                 speciality_name: speciality_name,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             // await specialities_service.GetbyName(speciality_name)
//             //     .then(type_data => {
//             //         if (type_data.length > 0) {
//             //             msg = "Scan Type Name already exists";
//             //             return res.status(200).json(failure_func(msg))
//             //         } else {
//             specialities_service.UpdateSpeciality(id, s_data)
//                 .then(data => {
//                     if (data == 1) {
//                         if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
//                             speciality_illness_mapping_service.DestroySpecialityIllnessMappingbySpeciality(id);

//                             for (const i of illness_type_ids) { // Use for...of loop
//                                 const nt_data = {
//                                     speciality_id: id,
//                                     illness_type_id: i,
//                                     active: active,
//                                     created_by: created_by,
//                                     updated_by: updated_by
//                                 }
//                                 console.log(nt_data);
//                                 speciality_illness_mapping_service.CreateSpecialityIllnessMapping(nt_data);

//                             }
//                         }
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_specialities')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//             //     }
//             // })
//         } else {
//             msg = "speciality_name, illness_type_ids and active is required and illness_type_ids should be an array";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const DeleteSpeciality = async (req, res, next) => {
    const id = req.params.id;
    if (id) {
        speciality_illness_mapping_service.DestroySpecialityIllnessMappingbySpeciality(id);
        await specialities_service.DestroySpeciality(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_specialities')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewSpeciality,
    FetchSpecialities,
    UpdateSpeciality,
    DeleteSpeciality
}