const scanRepo = require("../repository/labscans");

function getScanByLabService(fastify) {
  const { getScanByLab } = scanRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const response = await getScanByLab.call(knex, {
      params,
      logTrace
    });
    // Calculate sub_total for each test
    const transformedResponse = {
      data: response.data.map(item => {
        const cost = item.cost || 0;
        const discount = item.discount || 0;
        const sales_cost = cost - (cost * discount) / 100;
        const lab_scan_id = item.id;

        return {
          sales_cost,
          lab_scan_id,
          ...item
        };
      }),
      meta: response.meta
    };

    return transformedResponse;
  };
}

module.exports = {
  getScanByLabService
};
