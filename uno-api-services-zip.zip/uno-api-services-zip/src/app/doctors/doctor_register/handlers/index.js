const getRegisterBasicInfo = require("./getRegisterBasicInfo");

module.exports = {
  getRegisterBasicInfo
};
