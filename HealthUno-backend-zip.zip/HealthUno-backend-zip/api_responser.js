const success_func = (data) => {
    response = {
        status: 1,
        msg: "Success",
        response: data
    }
    return response
}

const failure_func = (data) => {

    response = {
        status: 0,
        msg: "Failed",
        response: data
    }
    return response
}

module.exports = {
    success_func,
    failure_func
}