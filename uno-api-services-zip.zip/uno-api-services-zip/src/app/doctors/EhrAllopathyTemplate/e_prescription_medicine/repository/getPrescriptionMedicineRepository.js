const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const {PRESCRIPTIONMEDICINE} = require("../commons/constants");
const {EHRUNIQUE} = require("../commons/constants");

const { CustomError } = require("../../../../errorHandler");

function uniquegetServiceRepositoryBasic(fastify) {
  async function ehruniqueAdd({ logTrace, body }) {
    const knex = this;

    const doctor_id = body.doctor_id
    const patient_id = body.patient_id

    const query =  await knex(`${EHRUNIQUE.NAME}`).insert({
      [EHRUNIQUE.COLUMNS.DOCTOR_ID]: doctor_id,
      [EHRUNIQUE.COLUMNS.PATIENT_ID]: patient_id,
      [EHRUNIQUE.COLUMNS.ACTIVE]: 1,
     
    })

    return { success: true, message: "Insert successfully"};
  }


  return {
    ehruniqueAdd

  };
}



function postPrescriptionMedicineRepositoryBasic(fastify) {
  async function PrescriptionMedicineAdd({ logTrace, body }) {
    const knex = this;

    const doctor_id = body.doctor_id
    const patient_id = body.patient_id



    const finalDiagnosisId = await knex.raw(`select top 1 * from e_ehrunique where doctor_id=${doctor_id} and patient_id=${patient_id}  and  end_consultation=0 order By id desc`);
    
    var id=parseInt(finalDiagnosisId[0].id);




    const query =  await knex(`${PRESCRIPTIONMEDICINE.NAME}`).insert({
      [PRESCRIPTIONMEDICINE.COLUMNS.MEDICINE_ID]: body.medicine_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.MEDICINE_NAME]: body.medicine_name,
      [PRESCRIPTIONMEDICINE.COLUMNS.FINAL_DIAGNOSIS_ID]: id,
      [PRESCRIPTIONMEDICINE.COLUMNS.QUANTITY]: body.quantity,
      [PRESCRIPTIONMEDICINE.COLUMNS.FREQUENCY]: body.frequency,
      [PRESCRIPTIONMEDICINE.COLUMNS.FREQUENCYNOTES]: body.frequencynotes,
      [PRESCRIPTIONMEDICINE.COLUMNS.TIMING]: body.timing,
      [PRESCRIPTIONMEDICINE.COLUMNS.TIMINGNOTES]: body.timingnotes,
      [PRESCRIPTIONMEDICINE.COLUMNS.DURATION]: body.duration,
      [PRESCRIPTIONMEDICINE.COLUMNS.INSTRUCTION]: body.instruction,
      [PRESCRIPTIONMEDICINE.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.PATIENT_ID]: body.patient_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.ACTIVE]: body.active,
      [PRESCRIPTIONMEDICINE.COLUMNS.CREATED_BY]: body.created_by
    })
    .returning('*');

    return { success: true, message: "Insert successfully","data":query};
  }


  return {
    PrescriptionMedicineAdd

  };
}

function updatePrescriptionMedicineRepository(fastify) {
  async function PrescriptionMedicineUpdate({ logTrace, body, params }) {
    const knex = this;
    
    const  id = params.id;

    const query = await knex(`${PRESCRIPTIONMEDICINE.NAME}`)
      .where(`${PRESCRIPTIONMEDICINE.COLUMNS.ID}`, id)
      .update({
        [PRESCRIPTIONMEDICINE.COLUMNS.MEDICINE_ID]: body.medicine_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.MEDICINE_NAME]: body.medicine_name,
      [PRESCRIPTIONMEDICINE.COLUMNS.FINAL_DIAGNOSIS_ID]: body.final_diagnosis_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.QUANTITY]: body.quantity,
      [PRESCRIPTIONMEDICINE.COLUMNS.FREQUENCY]: body.frequency,
      [PRESCRIPTIONMEDICINE.COLUMNS.FREQUENCYNOTES]: body.frequencynotes,
      [PRESCRIPTIONMEDICINE.COLUMNS.TIMING]: body.timing,
      [PRESCRIPTIONMEDICINE.COLUMNS.TIMINGNOTES]: body.timingnotes,
      [PRESCRIPTIONMEDICINE.COLUMNS.DURATION]: body.duration,
      [PRESCRIPTIONMEDICINE.COLUMNS.INSTRUCTION]: body.instruction,
      [PRESCRIPTIONMEDICINE.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.PATIENT_ID]: body.patient_id,
      [PRESCRIPTIONMEDICINE.COLUMNS.ACTIVE]: body.active,
      [PRESCRIPTIONMEDICINE.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }
  return {
    PrescriptionMedicineUpdate,
  };
}

function getPrescriptionMedicineRepository(fastify) {
  
  async function PrescriptionMedicineGetAlls({ logTrace , params }) {
  
    const knex = this;

    const final_diagnosis_id = params.final_diagnosis_id;

    // const query = knex.select('*').from(`${PRESCRIPTIONMEDICINE.NAME} where id `)
    const query = knex.raw(`select * from e_e_prescription_medicine where final_diagnosis_id = ${final_diagnosis_id} and end_consultation=0`)
    
    logQuery({
      logger: fastify.log,
      query,
      params,
      context: "Get e-prescription-medicine details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "e-prescription-medicine info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PrescriptionMedicineGetAlls
  };

}

function getPrescriptionMedicineRepositoryId(fastify) {
  
  async function PrescriptionMedicineGetOne({ logTrace, params }) {
    
    const knex = this;

    const id = params.id;


    const query = knex.raw(`select * from e_e_prescription_medicine  where id =${id} and end_consultation=0`)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get e-prescription-medicine details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "e-prescription-medicine info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PrescriptionMedicineGetOne
  };

}

function deletePrescriptionMedicineRepositoryId(fastify) {
  async function PrescriptionMedicineDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const  id  = params.id;
   
    const query = await knex(`${PRESCRIPTIONMEDICINE.NAME}`).
    where(`${PRESCRIPTIONMEDICINE.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    PrescriptionMedicineDelete
  };
}

function deleteAllPrescriptionMedicineRepositoryId(fastify) {
  async function PrescriptionMedicineDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const  final_diagnosis_id  = params.final_diagnosis_id;
   
    const query = await knex(`${PRESCRIPTIONMEDICINE.NAME}`).
    where(`${PRESCRIPTIONMEDICINE.COLUMNS.FINAL_DIAGNOSIS_ID}`, final_diagnosis_id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    PrescriptionMedicineDelete
  };
}

module.exports = {
  postPrescriptionMedicineRepositoryBasic,
  updatePrescriptionMedicineRepository,
  getPrescriptionMedicineRepository,
  getPrescriptionMedicineRepositoryId,
  deletePrescriptionMedicineRepositoryId,
  deleteAllPrescriptionMedicineRepositoryId,
  uniquegetServiceRepositoryBasic

};
