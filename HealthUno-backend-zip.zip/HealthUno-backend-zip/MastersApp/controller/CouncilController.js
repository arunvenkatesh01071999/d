const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const council_services = require('../services/council_service');
const cache = require('../../services/redis_cache_service');
const date = require('../../services/datetime_service');

const FetchCouncil = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await council_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_city_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await council_services.Get()
            .then(data => {
                // cache.SET(req.user.id + '_council_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }
const NewCouncil = async (req, res, next) => {
    council_name = req.body.council_name;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;

    if (council_name) {
        c_data = {
            council_name: council_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await council_services.GetbyName(council_name)
            .then(data => {
                if (data.length > 0) {
                    msg = " Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    council_services.CreateCouncil(c_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_council_services')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "Name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateCouncil = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        council_name = req.body.council_name;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (council_name) {
            c_data = {
                council_name: council_name,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // await council_services.GetbyName(council_name)
            //     .then(accredation_data => {
            //         if (accredation_data.length > 0) {
            //             msg = " Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            council_services.UpdateCouncil(id, c_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_council_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                //     }
                // })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "Name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteCouncil = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await council_services.DestroyCouncil(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_council_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    FetchCouncil,
    NewCouncil,
    UpdateCouncil,
    DeleteCouncil
}