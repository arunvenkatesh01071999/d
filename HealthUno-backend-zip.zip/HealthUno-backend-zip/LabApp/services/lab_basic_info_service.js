const LabBasicInfo = require('../models/LabBasicInfoModel');
const LabType = require('../../MastersApp/models/LabTypeMasterModel');
const SectorType = require('../../MastersApp/models/LabSectorModel');
const Accredation = require('../../MastersApp/models/AccredationModel');
const LabImage = require('../models/LabImageInfoModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');
const moment = require('moment/moment');

const Get = async () => {
    await LabBasicInfo.findAll({
        include: [SectorType, LabType, Accredation,
            {
                model: LabImage,
                as: 'Image',
                attributes: ['lab_name_id', 'lab_image']

            }

        ]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await LabBasicInfo.findAll({
        where: { id: id },
        include: [SectorType, LabType, Accredation,
            {
                model: LabImage,
                as: 'Image',
                attributes: ['lab_name_id', 'lab_image']

            }

        ],
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (lab_regNo) => {
    await LabBasicInfo.findAll({ where: { lab_regNo: lab_regNo }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabBasicInfo = async (i_data) => {

    await LabBasicInfo.create(i_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabBasicInfo = async (id, l_data) => {
    await LabBasicInfo.update(l_data, { where: { id: id } })
        .then(data => {
            res = data[0];
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabBasicInfo = async (id) => {
    await LabBasicInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const CreateApprove = async (id, a_data) => {

    const approve = moment(a_data.approve_date).format('L');
    const query = `UPDATE l_lab_basic_infos
    SET isApproved = ${a_data.isApproved}, approve_date = '${approve}', 
    approved_by = ${a_data.approved_by} , reason = '${a_data.reason}'
    WHERE id = ${id}`;

    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((err) => {
            res = err
        });

    return res
}


const UpdateIsapprove = async (id) => {

    var query = `UPDATE l_lab_basic_infos
    SET l_lab_basic_infos.isApproved = 0
    WHERE l_lab_basic_infos.isApproved = 1 OR l_lab_basic_infos.isApproved = 2
    AND l_lab_basic_infos.id =  ${id}`

    await db1.query(query, { type: Sequelize.QueryTypes })

        .then((data) => {
            res = data[0]
        })
        .catch((err) => {
            res = err
        });
    return res
}

const GetbyLabRegNoAll = async (lab_regNo) => {
    await LabBasicInfo.findAll({ where: { lab_regNo: lab_regNo }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyLabRegNoId = async (id) => {
    const query = `select * from l_lab_basic_infos where id = ${id}`;
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateLabBasicInfo,
    UpdateLabBasicInfo,
    DestroyLabBasicInfo,
    GetbyName,
    CreateApprove,
    UpdateIsapprove,
    GetbyLabRegNoId,
    GetbyLabRegNoAll
};