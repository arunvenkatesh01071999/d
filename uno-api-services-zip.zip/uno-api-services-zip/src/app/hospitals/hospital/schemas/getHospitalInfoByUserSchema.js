const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getHospitalInfoByUserSchema = {
  tags: ["HOSPITALS"],
  summary: "This API is to get hospitals information",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      user_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        hospital_name: { type: "string" },
        hospital_type_id: { type: "integer" },
        sector_id: { type: "integer" },
        hospital_sector_name: { type: "string" },
        accredation_id: { type: "integer" },
        accredation_name: { type: "string" },
        regNo: { type: "string" },
        about: { type: "string" },
        certicate_path: { type: "string" },
        addCheck: { type: "integer" },
        approved_by: { type: "integer" },
        approve_date: { type: "string", format: "date-time" },
        isApproved: { type: "integer" },
        hospital_image: { type: "string" },
        active: { type: "integer" },
        created_at: { type: "string", format: "date-time" },
        updated_at: { type: "string", format: "date-time" },
        created_by: { type: "integer" },
        updated_by: { type: "integer" },
        hospital_user: { type: "integer" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getHospitalInfoByUserSchema;
