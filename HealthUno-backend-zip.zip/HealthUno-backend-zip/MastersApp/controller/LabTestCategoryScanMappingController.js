const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_test_category_scan_mapping_service = require('../services/lab_test_category_scan_mapping_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchLabTestCategoryScanMapping = async (req, res, next) => {
    lab_test_category_id = req.params.lab_test_category_id;
    if (lab_test_category_id) {
        await lab_test_category_scan_mapping_service.GetbyId(lab_test_category_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_lab_test_category_scan_mapping');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await lab_test_category_scan_mapping_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_lab_test_category_scan_mapping', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewLabTestCategoryScanMapping = async (req, res, next) => {
    lab_test_category_id = req.body.lab_test_category_id;
    scan_test_master_id = req.body.scan_test_master_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;

    if (lab_test_category_id && scan_test_master_id && Array.isArray(scan_test_master_id) && scan_test_master_id.length > 0) {
        for (const i of scan_test_master_id) {
            const cs_data = {
                lab_test_category_id: lab_test_category_id,
                scan_test_master_id: i,
                active: active,
                created_by: created_by,
                updated_by: updated_by
            }
            console.log(cs_data);
            lab_test_category_scan_mapping_service.CreateLabTestsCategoryScanMapping(cs_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Created Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        msg = "Created Successfully"
        res.status(200).json(success_func(msg))
    } else {
        msg = "lab_test_category_id, scan_test_master_id and active is required";
        res.status(400).json(failure_func(msg))
    }

}

const UpdateLabTestCategoryScanMapping = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        lab_test_category_id = req.body.lab_test_category_id;
        scan_test_master_id = req.body.scan_test_master_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (lab_test_category_id && scan_test_master_id) {
            cs_data = {
                lab_test_category_id: lab_test_category_id,
                scan_test_master_id: scan_test_master_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await lab_test_category_scan_mapping_service.UpdateLabTestsCategoryScanMapping(id, cs_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_lab_test_category_scan_mapping')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "lab_test_category_id, scan_test_master_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteLabTestCategoryScanMapping = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await lab_test_category_scan_mapping_service.DestroyLabTestsCategoryScanMapping(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_lab_test_category_scan_mapping')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewLabTestCategoryScanMapping,
    FetchLabTestCategoryScanMapping,
    UpdateLabTestCategoryScanMapping,
    DeleteLabTestCategoryScanMapping
}