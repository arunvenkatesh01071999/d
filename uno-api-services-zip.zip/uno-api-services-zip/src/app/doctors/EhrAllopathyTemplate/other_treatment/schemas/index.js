const getOtherTreatmentSchema = require("./getOtherTreatment");

module.exports = {
  getOtherTreatmentSchema
};
