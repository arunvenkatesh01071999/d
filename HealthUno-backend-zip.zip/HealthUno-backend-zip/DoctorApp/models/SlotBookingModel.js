const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const DoctorInfo = require('../models/DoctorBasicInfoModel');

const SlotOnline = sequelize.define("d_slot_virtual", {
    doctor_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    day_id: {
        type: DataTypes.STRING,
        allowNull: true
    },
    day: {
        type: DataTypes.STRING,
        allowNull: true
    },
    fn: {
        type: DataTypes.STRING,
        allowNull: true
    },
    an: {
        type: DataTypes.STRING,
        allowNull: true
    },
    virtual: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

const SlotWalking = sequelize.define("d_slot_walking", {
    doctor_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    day_id: {
        type: DataTypes.STRING,
        allowNull: true
    },
    day: {
        type: DataTypes.STRING,
        allowNull: true
    },
    fn: {
        type: DataTypes.STRING,
        allowNull: true
    },
    an: {
        type: DataTypes.STRING,
        allowNull: true
    },
    virtual: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    walking: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

SlotOnline.belongsTo(DoctorInfo, { foreignKey: 'doctor_name_id' });

SlotOnline.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_slot_virtual',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

SlotOnline.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_slot_virtual',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

SlotWalking.belongsTo(DoctorInfo, { foreignKey: 'doctor_name_id' });

SlotWalking.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_slot_virtual',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

SlotWalking.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_slot_virtual',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = { SlotOnline, SlotWalking };