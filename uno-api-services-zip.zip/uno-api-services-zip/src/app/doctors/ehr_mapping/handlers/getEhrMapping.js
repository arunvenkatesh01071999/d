const getEhrDetailInfo = require("../services/getEhrMapping");

function getEhrMappingHandler(fastify) {
    const getEhrMapping =
        getEhrDetailInfo.getEhrMappingService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getEhrMapping({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getEhrMappingPostInfoHandler(fastify) {
    const getEhrMapping =
        getEhrDetailInfo.getEhrMappingPostService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getEhrMapping({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getEhrMappingPutInfoHandler(fastify) {
    const getEhrMapping =
        getEhrDetailInfo.getEhrMappingPutService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getEhrMapping({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getEhrMappingDeleteInfoHandler(fastify) {
    const getEhrMapping =
        getEhrDetailInfo.getEhrMappingDeleteService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getEhrMapping({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

module.exports = {
    getEhrMappingHandler,
    getEhrMappingPostInfoHandler,
    getEhrMappingPutInfoHandler,
    getEhrMappingDeleteInfoHandler
};
