const Specialities = require('../models/SpecialitiesModel');
const SpecialityIllnessMapping = require('../models/SpecialityIllnessMappingModel');
const IllnessTypes = require('../models/IllnessTypesModel');
const Get = async () => {
    await Specialities.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await Specialities.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSpeciality = async (s_data) => {
    await Specialities.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateSpeciality = async (id, s_data) => {
    await Specialities.update(s_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroySpeciality = async (id) => {
    await Specialities.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const GetbyRelations = async () => {
    let res;
    await Specialities.findAll({

        include: [{
            model: SpecialityIllnessMapping,
            as: 'a',
            include: IllnessTypes

        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}
const GetbyRelationsbyId = async (id) => {
    let res;
    await Specialities.findAll({
        where: {
            id: id
        },
        include: [{
            model: SpecialityIllnessMapping,
            as: 'a',
            include: IllnessTypes

        }],
        // logging: console.log // add this line to log the SQL queries
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}

module.exports = {
    Get,
    GetbyId,
    CreateSpeciality,
    UpdateSpeciality,
    DestroySpeciality,
    GetbyRelations,
    GetbyRelationsbyId
};
