const loginquesRepo = require("../repository/getloginquestion");
const otpGenerator = require("otp-generator");

function LoginquestionService(fastify) {
  const { getLoginques } = loginquesRepo.Loginques(fastify);

  return async ({ body,params, logTrace }) => {
    const knex = fastify.knexPatient;

    const response = await getLoginques.call(knex, {
      body,
      params,
      logTrace,
      body
    });

    const [getlogindata] = await Promise.all([response]);
    return getlogindata;
  };
}

function LoginallcatquestionService(fastify) {
  const { getallcatLoginques } =
  loginquesRepo.getallcatquestion(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexPatient;

    const response = await getallcatLoginques.call(knex, {
      body,
      logTrace
    });


    return {
      response
    };
  };
}
function LoginanspostService(fastify) {
  const { anspost } =
  loginquesRepo.questionpost(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexPatient;

    const response = await anspost.call(knex, {
      body,
      logTrace
    });


    return {
      response
    };
  };
}

function loginQuestionCatPostService(fastify) {
  const { loginQuestionCatPost } =
  loginquesRepo.loginQuestionCatPostRepo(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexPatient;

    const response = await loginQuestionCatPost.call(knex, {
      body,
      logTrace
    });


    return {
      response
    };
  };
}

function loginQuestionCatUpdateService(fastify) {
  const { loginQuestionCatUpdate } =
  loginquesRepo.loginQuestionCatUpdateRepo(fastify);

  return async ({ body, params,logTrace }) => {
    const knex = fastify.knexPatient;

    const response = await loginQuestionCatUpdate.call(knex, {
      body,
      params,
      logTrace
    });


    return {
      response
    };
  };
}

function loginQuestionCatDeleteService(fastify) {
  const { loginQuestionCatDelete } =
  loginquesRepo.loginQuestionCatDeleteRepo(fastify);

  return async ({ body, params,logTrace }) => {
    const knex = fastify.knexPatient;

    const response = await loginQuestionCatDelete.call(knex, {
      body,
      params,
      logTrace
    });


    return {
      response
    };
  };
}
module.exports = {
  LoginquestionService,
  LoginallcatquestionService,
  LoginanspostService,
  loginQuestionCatPostService,
  loginQuestionCatUpdateService,
  loginQuestionCatDeleteService
};
