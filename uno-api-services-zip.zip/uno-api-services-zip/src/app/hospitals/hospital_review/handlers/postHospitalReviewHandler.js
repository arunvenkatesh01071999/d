const hospitalReviewServices = require("../services/hospitalReviewServices");

function postHospitalReviewHandler(fastify) {
  const postReview = hospitalReviewServices(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await postReview({ body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = postHospitalReviewHandler;
