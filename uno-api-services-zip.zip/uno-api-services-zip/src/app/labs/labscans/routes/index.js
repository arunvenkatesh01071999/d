const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/labs/scans/:lab_id/:lab_or_scan/:page_size/:current_page/:search?",
    schema: schemas.getScanByLabSchema,
    handler: handlers.getScanByLabHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/labs/scans/healthpackages/:lab_id/:lab_or_scan/:page_size/:current_page/:search?",
    schema: schemas.getHealthPackageByScanSchema,
    handler: handlers.getHealthPackageByScanHandler(fastify)
  });
};
