const vlogArticleRepository = require("../repository/vlogArticleRepository");


function createVlogArticleServiceBasic(fastify) {
  const { vlogArticleAdd } = vlogArticleRepository.postVlogArticleRepositoryBasic(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleAdd.call(knex, {
      logTrace,
      body
    });

    const [vlogArticleAddData] = await Promise.all([promise1]);

    return vlogArticleAddData;
  };
}

function updateVlogArticleServiceBasic(fastify) {
  const { vlogArticleUpdate } = vlogArticleRepository.updateVlogArticleRepository(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedVlogArticleData] = await Promise.all([promise1]);

    return updatedVlogArticleData;
  };
}

function getVlogArticleInfoService(fastify) {
  const { vlogArticleGetAlls,getDoctorInfo } = vlogArticleRepository.getVlogArticleRepository(fastify);
  return async ({ logTrace, params,userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleGetAlls.call(knex, {
      logTrace,params
    });
    var [getVlogArticleAlldata] = await Promise.all([promise1]);
    var meta =getVlogArticleAlldata.meta
    const doctorInfo = await Promise.all(
      getVlogArticleAlldata.data.map(async doctor => {
        let doctor_id = doctor.doctor_id;
        if (doctor_id > 0) {
          const doctorDetails = await getDoctorInfo({ doctor_id, logTrace });
          return {
            ...doctor,
            doctorDetails // Adding doctor_info to each doctor object
          };
        } else {
          return {
            ...doctor,
            doctorDetails:"" // Adding doctor_info to each doctor object
          };
        }
      })
    );
    return {
      data:doctorInfo,
      meta
    }
  }
}

function getVlogArticleInfoServiceId(fastify) {

  const { vlogArticleGetOne } = vlogArticleRepository.getVlogArticleRepositoryId(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleGetOne.call(knex, {
      logTrace,
      params,
      body
    });
    const [vlogArticleGetOnedata] = await Promise.all([promise1]);
    return vlogArticleGetOnedata;
  }
}

function getVlogArticleInfoServicebyId(fastify) {

  const { vlogbyid } = vlogArticleRepository.getVlogArticleRepositorybyId(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogbyid.call(knex, {
      logTrace,
      params,
      body
    });
    const [vlogbyiddata] = await Promise.all([promise1]);
    return vlogbyiddata;
  }
}
function deleteVlogArticleServiceId(fastify) {

  const { vlogArticleDelete } = vlogArticleRepository.deleteVlogArticleRepositoryId(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleDelete.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });

    const [deleteVlogArticledata] = await Promise.all([promise1]);

    return deleteVlogArticledata;
  };
}


module.exports = {

  createVlogArticleServiceBasic,
  updateVlogArticleServiceBasic,
  getVlogArticleInfoService,
  getVlogArticleInfoServiceId,
  deleteVlogArticleServiceId,
  getVlogArticleInfoServicebyId
};
