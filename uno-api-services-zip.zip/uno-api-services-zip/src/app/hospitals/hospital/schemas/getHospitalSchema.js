const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getHospitalSchema = {
  tags: ["HOSPITALS"],
  summary: "This API is to get hospitals",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name: { type: "string" },
              hospital_type_id: { type: "string" },
              sector_id: { type: "integer" },
              hospital_sector_name: { type: "string" },
              accredation_id: { type: "integer" },
              accredation_name: { type: "string" },
              regNo: { type: "string" },
              about: { type: "string" },
              certicate_path: { type: "string" },
              addCheck: { type: "integer" },
              approved_by: { type: "integer" },
              reason: { type: "string" },
              approve_date: { type: "string", format: "date-time" },
              isApproved: { type: "integer" },
              hospital_image: { type: "string" },
              active: { type: "boolean" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              longitude: { type: "string" },
              latitude: { type: "string" },
              distance: { type: "number" },
              rating: { type: "number" },
              address1: { type: "string" },
              address2: { type: "string" },
              images: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    hospital_name_id: { type: "integer" },
                    hospital_image: { type: "string" },
                    active: { type: "integer" },
                    created_at: { type: "string" },
                    updated_at: { type: "string" },
                    created_by: { type: "integer" },
                    updated_by: { type: "integer" }
                  }
                }
              }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getHospitalSchema;
