const getPatientRecordsService = require("../services/getPatientRecordsService");


function getPatientRecordsFrontHandlerPost(fastify) {

  const getPatientRecords = getPatientRecordsService.getPatientRecordsFrontInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params,body } = request;
    const response = await getPatientRecords({
      logTrace,body,
      params

    });
    return reply.code(200).send(response);
  };

}

function getPatientRecordsDateFilterHandlerPost(fastify) {

  const getPatientRecords = getPatientRecordsService.getPatientRecordsDateFilterInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params,body } = request;
    const response = await getPatientRecords({
      logTrace,body,
      params

    });
    return reply.code(200).send(response);
  };

}

function getPatientRecordsOldHandlerPost(fastify) {

  const getPatientRecords = getPatientRecordsService.getPatientRecordsOldInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params,body } = request;
    const response = await getPatientRecords({
      logTrace,body,
      params

    });
    return reply.code(200).send(response);
  };

}







module.exports = {
  getPatientRecordsFrontHandlerPost,
  getPatientRecordsDateFilterHandlerPost,
  getPatientRecordsOldHandlerPost
};
