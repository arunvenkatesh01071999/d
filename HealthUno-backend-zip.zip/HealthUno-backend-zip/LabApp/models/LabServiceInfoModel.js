const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const LabInfo = require('./LabBasicInfoModel');
const LabServiceModel = require('../../MastersApp/models/LabServiceMasterModel');
const logger = require('../../config/activity_logger');


const ServiceInfo = sequelize.define("l_lab_service_info", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "lab_name_id is required"
            }
        }
    },
    service_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "service_name_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 1,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

ServiceInfo.belongsTo(LabServiceModel, { foreignKey: 'service_name_id' });
ServiceInfo.belongsTo(LabInfo, { foreignKey: 'lab_name_id' });


ServiceInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_service_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ServiceInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_service_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = ServiceInfo;