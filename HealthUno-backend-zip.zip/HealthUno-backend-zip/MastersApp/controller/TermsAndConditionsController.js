const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const terms_and_conditions_service = require('../services/terms_and_conditions_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchTermsandConditions = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await terms_and_conditions_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_terms_and_conditions');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await terms_and_conditions_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_terms_and_conditions', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewTermsandConditions = async (req, res, next) => {
    terms_and_conditions = req.body.terms_and_conditions;
    terms_and_conditions_title = req.body.terms_and_conditions_title;
    is_for = req.body.is_for;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (terms_and_conditions && terms_and_conditions_title && is_for) {
        tc_data = {
            terms_and_conditions: terms_and_conditions,
            terms_and_conditions_title: terms_and_conditions_title,
            is_for: is_for,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await terms_and_conditions_service.CreateTermsAndConditions(tc_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_terms_and_conditions')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "terms_and_conditions, terms_and_conditions_title, is_for and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateTermsandConditions = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        terms_and_conditions = req.body.terms_and_conditions;
        terms_and_conditions_title = req.body.terms_and_conditions_title;
        is_for = req.body.is_for;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (terms_and_conditions && terms_and_conditions_title && is_for) {
            pp_data = {
                terms_and_conditions: terms_and_conditions,
                terms_and_conditions_title: terms_and_conditions_title,
                is_for: is_for,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await terms_and_conditions_service.UpdateTermsAndConditions(id, pp_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_terms_and_conditions')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "terms_and_conditions, terms_and_conditions_title, is_for and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteTermsandConditions = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await terms_and_conditions_service.DestroyTermsAndConditions(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_terms_and_conditions')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewTermsandConditions,
    FetchTermsandConditions,
    UpdateTermsandConditions,
    DeleteTermsandConditions
}