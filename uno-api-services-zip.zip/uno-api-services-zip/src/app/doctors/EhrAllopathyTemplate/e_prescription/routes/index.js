const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/e-prescription",
    preHandler: fastify.authenticate,
    // schema: schemas.getPrescriptionSchema.createPrescriptionSchema,
    handler: handlers.getPrescriptionHandler.createPrescriptionHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/e-prescription/:id",
    preHandler: fastify.authenticate,
    schema: schemas.getPrescriptionSchema.updatePrescriptionSchema,
    handler: handlers.getPrescriptionHandler.updatePrescriptionHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/e-prescription",
    preHandler: fastify.authenticate,
    schema: schemas.getPrescriptionSchema.getPrescriptionSchema,
    handler: handlers.getPrescriptionHandler.getPrescriptionHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/e-prescription/:id",
    preHandler: fastify.authenticate,
  //  schema: schemas.getPrescriptionSchema.getPrescriptionSchema,
    handler: handlers.getPrescriptionHandler.getPrescriptionHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/e-prescription/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
   schema: schemas.getPrescriptionSchema.deletePrescriptionSchema,
    handler: handlers.getPrescriptionHandler.deletePrescriptionHandler(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/e-prescription/deleteAll",
    preHandler: fastify.authenticate,
  //  schema: schemas.getPrescriptionSchema.deletePrescriptionAllSchema,
    handler: handlers.getPrescriptionHandler.deleteAllPrescriptionHandler(fastify)
  });

};
