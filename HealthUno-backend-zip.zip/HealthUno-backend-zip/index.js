require('dotenv').config();
const PORT=process.env.PORT;
const HOSTNAME = process.env.HOSTNAME;
const app=require('./app');
const http=require('http');

const server=http.createServer(app);

server.listen(PORT, HOSTNAME, (err)=>{
    console.log(`server running at http://${HOSTNAME}:${PORT}`)
})