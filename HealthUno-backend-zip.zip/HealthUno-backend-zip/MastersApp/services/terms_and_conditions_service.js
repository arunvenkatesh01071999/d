const Services = require('../../models/ServiceModel');
const TermsAndConditions = require('../models/Terms&ConditionsModel');

const Get = async () => {
    await TermsAndConditions.findAll({ include: [Services] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await TermsAndConditions.findAll({ where: { id: id }, include: [Services] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateTermsAndConditions = async (tc_data) => {
    await TermsAndConditions.create(tc_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateTermsAndConditions = async (id, tc_data) => {
    await TermsAndConditions.update(tc_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyTermsAndConditions = async (id) => {
    await TermsAndConditions.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateTermsAndConditions,
    UpdateTermsAndConditions,
    DestroyTermsAndConditions
};
