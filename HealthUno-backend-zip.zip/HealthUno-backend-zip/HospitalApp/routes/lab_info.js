const express = require('express');
const router = express();
const LabInfoController = require('../controller/LabInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabInfoController.FetchLabInfo);
router.get('/:hospital_name_id', verify_token, LabInfoController.FetchLabInfo);
router.post('/', verify_token, LabInfoController.NewLabInfo);
router.put('/:hospital_name_id', verify_token, LabInfoController.UpdateLabInfo);
// router.delete('/:id', verify_token, LabInfoController.DeleteLabInfo);

module.exports = router;