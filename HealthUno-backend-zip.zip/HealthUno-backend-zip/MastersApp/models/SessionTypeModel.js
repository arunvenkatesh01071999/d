const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');


const SessionMaster = sequelize.define("session_master", {
    session_type: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Session is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });


SessionMaster.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'session_master',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

SessionMaster.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'session_master',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = SessionMaster;