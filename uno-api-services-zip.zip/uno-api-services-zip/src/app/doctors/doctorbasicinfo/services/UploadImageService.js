const { CustomError } = require("../../../errorHandler");
const { StatusCodes } = require("http-status-codes");

function UploadImageService(fastify) {
    return async ({ body, logTrace, request, reply }) => {
        const { file } = body;

        if (!file) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: "No file uploaded",
                property: "",
                code: "NOT_FOUND"
            });
        }
        // Log the received file name and size
        // console.log('Received file:', body.file.filename);
        const inputBuffer = await body.file.toBuffer();
        // console.log('File converted to buffer:', inputBuffer.length, 'bytes');
        const media_path = 'images/' + body.file.filename;
        const result = await fastify.bucketOperations.saveFileBuffer({
            file_path: media_path,
            buffer: inputBuffer
        });
        
        if (!result) {
            throw CustomError.create({
                httpCode: StatusCodes.NOT_FOUND,
                message: console.log(result),
                property: "",
                code: "NOT_FOUND"
            });
        }
        // Construct the full URL based on your cloud storage configuration
        const cloudStorageBaseUrl = process.env.GCS_URL+'/'+process.env.GCP_BUCKET_NAME;
        const fullUrl = `${cloudStorageBaseUrl}/${media_path}`;
        return {
            'message': 'File uploaded successfully',
            'image_url':fullUrl
        };
    };
}

module.exports = UploadImageService;