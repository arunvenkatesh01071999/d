const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getAdminOrderSchema = {
  tags: ["ORDERS"],
  summary: "This API is to get patients orders",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      patient_id: { type: "integer" },
      lab_id: { type: "integer" },
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              patient_id: { type: "integer" },
              lab_id: { type: "string" },
              lab_name: { type: "string" },
              lab_image: { type: "string" },
              lab_order_total: { type: "number" },
              lab_order_total_savings: { type: "number" },
              no_of_tests: { type: "number" },
              no_of_packages: { type: "number" },
              tests_cart_items_total: { type: "number" },
              tests_cart_total_savings: { type: "number" },
              pack_cart_items_total: { type: "number" },
              packages_cart_total_savings: { type: "number" },
              payment_refno: { type: "string" },
              appointment_time: { type: "string" },
              appointment_date: { type: "string", format: "date-time" },
              order_mode: { type: "integer" },
              order_type: { type: "integer" },
              report_status: { type: "integer" },
              report_status_text: { type: "string" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              patient_info: {
                type: "object", // Assuming patient info is an object
                properties: {
                  id: { type: "integer" },
                  name: { type: "string" },
                  email: { type: "string" },
                  gender_id: { type: "integer" },
                  dob: { type: "string" },
                  mobile: { type: "string" },
                  profile_image: { type: "string" },
                  martial_status_id: { type: "integer" }
                }
              },
              tests_cart_lines: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    lab_order_id: { type: "integer" },
                    patient_id: { type: "integer" },
                    lab_id: { type: "integer" },
                    lab_test_id: { type: "integer" },
                    test_name: { type: "string" },
                    cost: { type: "number" },
                    discount: { type: "number" },
                    tests_cart_items_total: { type: "number" },
                    test_cart_items_total_savings: { type: "number" },
                    is_test_or_package: { type: "boolean" },
                    pretest_prepare: { type: "string" },
                    lab_report_status_link: { type: "string" }
                  }
                }
              },
              tests_packages_cart_lines: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    lab_order_id: { type: "integer" },
                    patient_id: { type: "integer" },
                    lab_id: { type: "integer" },
                    lab_package_id: { type: "integer" },
                    lab_pack_name: { type: "string" },
                    pack_cart_items_total: { type: "number" },
                    pack_cart_items_total_savings: { type: "number" },
                    cost: { type: "number" },
                    offer_percent: { type: "number" },
                    is_test_or_package: { type: "boolean" },
                    lab_report_status_link: { type: "string" },
                    lab_tests: {
                      type: "array",
                      items: { type: "string" } // Update lab_tests to be an array of strings
                    }
                  }
                }
              }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getAdminOrderSchema;
