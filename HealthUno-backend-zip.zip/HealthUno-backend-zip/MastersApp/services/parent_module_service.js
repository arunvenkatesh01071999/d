const MainModule = require('../models/MainModuleModel');
const ParentModule = require('../models/ParentModuleModel');

const Get = async () => {
    await ParentModule.findAll({ include: [MainModule] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await ParentModule.findAll({ where: { id: id }, include: [MainModule] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await ParentModule.findAll({ where: { parent_module_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateParentModule = async (pm_data) => {
    await ParentModule.create(pm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateParentModule = async (id, pm_data) => {
    await ParentModule.update(pm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyParentModule = async (id) => {
    await ParentModule.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateParentModule,
    UpdateParentModule,
    DestroyParentModule,
    GetbyName
};
