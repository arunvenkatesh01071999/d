const createMeetServices = require("../services/createMeetServices");

function createMeetHandler(fastify) {
  const createMeet = createMeetServices(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await createMeet({ body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = createMeetHandler;
