const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const { Storage } = require('@google-cloud/storage');
const morgan = require('morgan');
const cors = require('cors');
const fileupload = require("express-fileupload");
const app = express();
const LoginRouter = require('./routes/login');
const RolesRouter = require('./routes/role');
const UsersRouter = require('./routes/user');
const ServiceRouter = require('./routes/service');
const MastersRouter = require('./MastersApp/app');
const HospitalRouter = require('./HospitalApp/app');
const DoctorRouter = require('./DoctorApp/app');
const LabRouter = require('./LabApp/app');
const writer = require("./config/api_logger");
morgan.token('body', function (req, res) { return JSON.stringify(req.body) })
app.use(morgan('"date":":date[clf]", "client":":remote-addr", "method":":method", "url":":url HTTP/:http-version", "status":":status", "res_length":":res[content-length]", "body"::body, "agent":":user-agent"', { "stream": writer }));

const storage = new Storage({
    keyFilename: 'uno-api-services-staging.json', // Replace with your service account key file path
  });

app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());
app.use(fileupload());
app.use(express.static('media')); // serve static files from the media directory


// const storage = new Storage();
// const bucket = storage.bucket(process.env.GCP_BUCKET_NAME);

// const storageOptions = {
//   destination: (req, file, callback) => {
//     const filename = Date.now() + '-' + file.originalname;
//     callback(null, filename);
//   },
// };

app.use('/api', LoginRouter);
app.use('/api', RolesRouter);
app.use('/api', UsersRouter);
app.use('/api', ServiceRouter);
app.use('/api', MastersRouter);
app.use('/api', HospitalRouter);
app.use('/api', DoctorRouter);
app.use('/api', LabRouter);

module.exports = app;