const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const LabInfo = require('./LabBasicInfoModel');
const scanModel = require('../../MastersApp/models/ScanTestMasterModel');
const logger = require('../../config/activity_logger');


const ScanInfo = sequelize.define("l_lab_scan_info", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    scan_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    pack_name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    cost: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    discount:{
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

ScanInfo.belongsTo(scanModel, { foreignKey: 'scan_name_id' });
ScanInfo.belongsTo(LabInfo, { foreignKey: 'lab_name_id' });


ScanInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_scan_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ScanInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_scan_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = ScanInfo;