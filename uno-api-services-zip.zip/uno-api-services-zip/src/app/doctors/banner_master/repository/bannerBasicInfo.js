const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { BANNERINFO } = require("../commons/constants");
const UploadImageService = require("../../../commons/imageupload");
const { CustomError } = require("../../../errorHandler");

function bannerallBasicInfoRepo(fastify) {
  async function getBannerBasicInfo({ logTrace }) {
    const knex = this;

    const query = knex.select(`*`).from(`${BANNERINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Banner details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Banner info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getBannerBasicInfo
  };
}

function bannerallBasicInfoByIdRepo(fastify) {
  async function getBannerBasicInfoById({ logTrace, params }) {
    const knex = this;
    const { id } = params;
    const query = knex.select(`*`).from(`${BANNERINFO.NAME}`).where(`${BANNERINFO.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Banner details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Banner info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getBannerBasicInfoById
  };
}

// function bannerallBasicInfoRepos(fastify) {
//   async function getpostBannerBasicInfo({ logTrace,convertedData, body, userDetails }) {
//     const knex = this;

//     const query = await knex(`${BANNERINFO.NAME}`).insert({
//       [BANNERINFO.COLUMNS.BANNER_NAME]: convertedData.banner_name,
//       [BANNERINFO.COLUMNS.BANNER_DESCRIPTION]: convertedData.banner_description,
//       [BANNERINFO.COLUMNS.BANNER_TITLE]: convertedData.banner_title,
//       [BANNERINFO.COLUMNS.BANNER_IMAGES]: null,
//       [BANNERINFO.COLUMNS.BANNER_TYPE]: convertedData.banner_type,
//       [BANNERINFO.COLUMNS.BANNER_LINK]: convertedData.banner_link,
//       [BANNERINFO.COLUMNS.CREATED_BY]: convertedData.created_by,
//       [BANNERINFO.COLUMNS.ACTIVE]: convertedData.active

//     });

//     const response = await query;

//     return { success: true, message: "Insert successfully" };
//   }

//   return {
//     getpostBannerBasicInfo
//   };
// }

function bannerallBasicInfoRepos(fastify) {
  async function getpostBannerBasicInfo({ logTrace, body, userDetails }) {
    const knex = this;
    const banner_images = body.banner_images;

    if (banner_images !== '' && banner_images !== undefined) {

      if (banner_images.filename !== undefined && banner_images.filename !== '') {
        
        const img = await UploadImageService(banner_images, fastify);
        var imgurl = img.image_url;
      }
      else {
        var imgurl = null;

      }
    }
    else {
      var imgurl = null;
    }
    
    const query = await knex(`${BANNERINFO.NAME}`).insert({
      [BANNERINFO.COLUMNS.BANNER_NAME]: body.banner_name.value,
      [BANNERINFO.COLUMNS.BANNER_DESCRIPTION]: body.banner_description.value,
      [BANNERINFO.COLUMNS.BANNER_TITLE]: body.banner_title.value,
      [BANNERINFO.COLUMNS.BANNER_IMAGES]: imgurl,
      [BANNERINFO.COLUMNS.BANNER_TYPE]: body.banner_type.value,
      [BANNERINFO.COLUMNS.BANNER_LINK]: body.banner_link.value,
      [BANNERINFO.COLUMNS.CREATED_BY]: body.created_by.value,
      [BANNERINFO.COLUMNS.ACTIVE]: body.created_by.active
    });
    const response = await query;
    return { success: true, message: "Insert successfully" };
  }
  return {
    getpostBannerBasicInfo
  };
}

// function bannerputBasicInfoRepos(fastify) {
//   async function getputBannerBasicInfo({
//     logTrace,convertedData,
//     body,
//     params,
//     userDetails
//   }) {
//     const knex = this;
//     const { id } = params;

//     const query = await knex(`${BANNERINFO.NAME}`)
//       .where(`${BANNERINFO.COLUMNS.ID}`, id)
//       .update({
//         [BANNERINFO.COLUMNS.BANNER_NAME]: convertedData.banner_name,
//         [BANNERINFO.COLUMNS.BANNER_DESCRIPTION]: convertedData.banner_description,
//         [BANNERINFO.COLUMNS.BANNER_TITLE]: convertedData.banner_title,
//         [BANNERINFO.COLUMNS.BANNER_IMAGES]: null,
//         [BANNERINFO.COLUMNS.BANNER_TYPE]: convertedData.banner_type,
//         [BANNERINFO.COLUMNS.BANNER_LINK]: convertedData.banner_link,
//         [BANNERINFO.COLUMNS.UPDATED_BY]: convertedData.created_by,
//         [BANNERINFO.COLUMNS.ACTIVE]: convertedData.active

//       });

//     const response = await query;

//     return { success: true, message: "Updated successfully" };
//   }

//   return {
//     getputBannerBasicInfo
//   };
// }

function bannerputBasicInfoRepos(fastify) {
  async function getputBannerBasicInfo({
    logTrace,
    body,
    params,
    userDetails
  }) {
    const knex = this;
    const { id } = params;
    const banner_images = body.banner_images;

    if (banner_images !== '' && banner_images !== undefined) {

      if (banner_images.filename !== undefined && banner_images.filename !== '') {
        
        const img = await UploadImageService(banner_images, fastify);
        var imgurl = img.image_url;
      }
      else {
        var imgurl = null;

      }

    }
    else {
      var imgurl = null;
    }
    const query = await knex(`${BANNERINFO.NAME}`)
      .where(`${BANNERINFO.COLUMNS.ID}`, id)
      .update({
        [BANNERINFO.COLUMNS.BANNER_NAME]: body.banner_name.value,
        [BANNERINFO.COLUMNS.BANNER_DESCRIPTION]: body.banner_description.value,
        [BANNERINFO.COLUMNS.BANNER_TITLE]: body.banner_title.value,
        [BANNERINFO.COLUMNS.BANNER_IMAGES]: imgurl,
        [BANNERINFO.COLUMNS.BANNER_TYPE]: body.banner_type.value,
        [BANNERINFO.COLUMNS.BANNER_LINK]: body.banner_link.value,
        [BANNERINFO.COLUMNS.CREATED_BY]: body.created_by.value,
        [BANNERINFO.COLUMNS.ACTIVE]: body.created_by.active
      });
    const response = await query;
    return { success: true, message: "Updated successfully" };
  }
  return {
    getputBannerBasicInfo
  };
}

function bannerdeleteBasicInfoRepos(fastify) {
  async function getdeleteBannerBasicInfo({
    logTrace,
    body,
    params,
    userDetails
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${BANNERINFO.NAME}`)
      .where(`${BANNERINFO.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    getdeleteBannerBasicInfo
  };
}

module.exports = {
  bannerallBasicInfoRepo,
  bannerallBasicInfoByIdRepo,
  bannerallBasicInfoRepos,
  bannerputBasicInfoRepos,
  bannerdeleteBasicInfoRepos
};
