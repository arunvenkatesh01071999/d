const labRepo = require("../repository/labscans");

function getHealthPackageService(fastify) {
  const { getHealthPackage } = labRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const response = await getHealthPackage.call(knex, {
      params,
      logTrace
    });

    const transformedResponse = {
      data: response.data.map(item => {
        let is_lab_or_scan;
        switch (item.lab_or_scan) {
          case 0:
            is_lab_or_scan = "LABS";
            break;
          case 1:
            is_lab_or_scan = "SCANS";
            break;
          default:
            is_lab_or_scan = ""; // Default value if no match
            break;
        }
        return {
          ...item,
          is_lab_or_scan,
          lab_tests: item.lab_category_id
        };
      }),
      meta: response.meta
    };

    return transformedResponse;
  };
}
function getHealthPackageByScanService(fastify) {
  const { getHealthPackageByScan } = labRepo(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const response = await getHealthPackageByScan.call(knex, {
      params,
      logTrace
    });

    const transformedResponse = {
      data: response.data.map(item => {
        let is_lab_or_scan;
        switch (item.lab_or_scan) {
          case 0:
            is_lab_or_scan = "LABS";
            break;
          case 1:
            is_lab_or_scan = "SCANS";
            break;
          default:
            is_lab_or_scan = ""; // Default value if no match
            break;
        }

        const scan_tests = item.scan_name_id.split(",");
        const cost = item.cost || 0;
        const discount = item.offer_percent || 0;
        const sales_cost = cost - (cost * discount) / 100;
        const lab_scan_package_id = item.id;
        return {
          ...item,
          is_lab_or_scan,
          scan_tests,
          sales_cost,
          lab_scan_package_id
        };
      }),
      meta: response.meta
    };

    return transformedResponse;
  };
}

module.exports = {
  getHealthPackageService,
  getHealthPackageByScanService
};
