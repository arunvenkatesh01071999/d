const getBannerBasicInfo = require("./getBannerBasicInfo");

module.exports = {
  getBannerBasicInfo
};
