const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { PATIENTDETAILS } = require("../commons/constants");
const { PAITENTBOOKINGINFO } = require("../commons/constants");
const { PATIENT_RECORD } = require("../commons/constants");
const { REGISTERINFO } = require("../commons/constants");
const { DOCTORBASICINFO } = require("../commons/constants");
const { WALLET_LEDGER } = require("../commons/constants")

const moment = require("moment");
const getalldocdistance = require("../../../doctors/doctorCount/repository/AvilDoctorCount");
const meet = require("../../../videomeet/repository/generatemeet");

const { CustomError } = require("../../../errorHandler");

function getpatientwithfilter(fastify) {
  async function patientfilterwithdatefilter({ logTrace, body }) {
    const knexPatient = fastify.knexPatient;

    const knex = this;

    var doctor_id = body.doctor_id;
    var appointment_date = body.appointment_date;
    var check_video_walking = body.check_video_walking;

    if (check_video_walking == 0) {
      // const query =
      //   knexPatient.raw(`select b.name,a.patient_id,b.mobile,b.logitute,b.latitude,a.appointment_day,a.appointment_date,
      // a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul,a.doctor_id,a.appointment_status,
      // b.profile_image,b.email,a.patient_url,a.doctor_url
      // from patient_booking as a
      // left join patient_registration as b on b.id=a.patient_id
      // where a.doctor_id=${doctor_id} and a.appointment_status !=3 and a.hospitalcounsul_or_videoconsul=0 and convert(DATE, a.appointment_date) = '${appointment_date}' order by  convert(TIME, a.appointment_from_time) desc`);
      // var responsePatientDetails = await query;
      const query = knexPatient
      .select(
        'b.name',
        'a.patient_id',
        'b.mobile',
        'b.logitute',
        'b.latitude',
        'a.appointment_day',
        'a.appointment_date',
        'a.appointment_from_time',
        'a.appointment_to_time',
        'a.hospitalcounsul_or_videoconsul',
        'a.doctor_id',
        'a.appointment_status',
        'b.profile_image',
        'b.email',
        'a.patient_url',
        'a.doctor_url'
      )
      .from('patient_booking as a')
      .leftJoin('patient_registration as b', 'b.id', 'a.patient_id')
      .where('a.doctor_id', doctor_id)
      .andWhereNot('a.appointment_status', 3)
      .andWhere('a.hospitalcounsul_or_videoconsul', 0)
      .andWhereRaw('convert(DATE, a.appointment_date) = ?', [appointment_date])
      .orderByRaw('convert(TIME, a.appointment_from_time) asc');
    
    // Execute the query
    const response = await query;
  
      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patients details",
        logTrace
      });

      if (!response.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patients info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return response;
    } else {
      // const query =
      //   knexPatient.raw(`select b.name,a.patient_id,b.mobile,b.logitute,b.latitude,a.appointment_day,a.appointment_date,
      //   a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul,a.doctor_id,a.appointment_status,
      //   b.profile_image,b.email,a.patient_url,a.doctor_url
      // from patient_booking as a
      // left join patient_registration as b on b.id=a.patient_id
      //  where a.doctor_id=${doctor_id}  and a.appointment_status !=3 and a.hospitalcounsul_or_videoconsul=1 and convert(DATE, a.appointment_date) = '${appointment_date}' order by  convert(TIME, a.appointment_from_time) desc`);

      // const responsePatientDetails = await query;
      const query = knexPatient
      .select(
        'b.name',
        'a.patient_id',
        'b.mobile',
        'b.logitute',
        'b.latitude',
        'a.appointment_day',
        'a.appointment_date',
        'a.appointment_from_time',
        'a.appointment_to_time',
        'a.hospitalcounsul_or_videoconsul',
        'a.doctor_id',
        'a.appointment_status',
        'b.profile_image',
        'b.email',
        'a.patient_url',
        'a.doctor_url'
      )
      .from('patient_booking as a')
      .leftJoin('patient_registration as b', 'b.id', 'a.patient_id')
      .where('a.doctor_id', doctor_id)
      .andWhereNot('a.appointment_status', 3)
      .andWhere('a.hospitalcounsul_or_videoconsul', 1)
      .andWhereRaw('convert(DATE, a.appointment_date) = ?', [appointment_date])
      .orderByRaw('convert(TIME, a.appointment_from_time) asc');
      const response = await query;
      var final = [];
      for (let i = 0; i < response.length; i++) {
        const doctor_id = response[i].doctor_id;
        console.log('doctor_id',doctor_id);
        const data = await knex.raw(`
        select * from d_doctor_basic_info where id=${doctor_id}`);
        const hospital_id = data[0].hospital_name_id;
      
        if (hospital_id != "1543") {
          const data2 = await knex.raw(`select * from h_hospital_basic_info where id=${hospital_id}`);
          response[i].hospital_name = data2[0].hospital_name;
        }
        else {
          response[i].hospital_name = "";
        }
      
        final.push(response[i]);
      }

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patients details",
        logTrace
      });

      if (!final.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patients info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return final;
    }
  }

  return {
    patientfilterwithdatefilter
  };
}

function getPatientDetailsRepositoryPostImg(fastify) {
  async function PatientDetailsGetOnePostImg({ logTrace, params, body }) {
    const knex = this;
    const knexPatient = fastify.knexPatient;

    const patient_upload = body.patient_upload;

    if (patient_upload !== "" && patient_upload !== undefined) {
      if (
        patient_upload.filename !== undefined &&
        patient_upload.filename !== ""
      ) {
        const img = await UploadImageService(patient_upload, fastify);
        var imgurl = img.image_url;
      } else {
        var imgurl = null;
      }
    } else {
      var imgurl = null;
    }

    const query = await knexPatient(`${PATIENTDETAILS.NAME}`).insert({
      [PATIENTDETAILS.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
      [PATIENTDETAILS.COLUMNS.PATIENT_ID]: body.patient_id.value,
      [PATIENTDETAILS.COLUMNS.PATIENT_UPLOAD]: imgurl,
      [PATIENTDETAILS.COLUMNS.ACTIVE]: body.active.value,
      [PATIENTDETAILS.COLUMNS.CREATED_BY]: body.created_by.value
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }

  return {
    PatientDetailsGetOnePostImg
  };
}

function getreschedulepostDetailsPost(fastify) {
  async function reschedulepost({ logTrace, params, body }) {
    const knex = this;
    const knexPatient = fastify.knexPatient;
    var doctor_id = body.doctor_id;
    var patient_id = body.patient_id;
    var appointment_date = body.appointment_date;
    var appoinment_time = body.appoinment_time;
    var hospitalcounsul_or_videoconsul = body.hospitalcounsul_or_videoconsul;
    var logitute = body.logitute ? body.logitute : "11.0168";
    var latitude = body.latitude ? body.latitude : "76.9558";

    const validate = [
      "d_address_info",
      "d_education_info",
      "d_experience_info",
      "d_language_info",
      "d_council_info",
      "d_consulted_fees",
      "doct_avil_slot"
    ];
    for (let i = 0; i < validate.length; i++) {
      if (validate[i] === "d_consulted_fees") {
        const check_d_id = knex.raw(
          `select * from ${validate[i]} where doctor_id=${doctor_id}`
        );
        const response_data = await check_d_id;
        var check_d_id_array = response_data.flat();
      } else {
        const check_d_id = knex.raw(
          `select * from ${validate[i]} where doctor_name_id=${doctor_id}`
        );
        const response_data = await check_d_id;
        var check_d_id_array = response_data.flat();
      }

      if (check_d_id_array.length > 0) {
        const val = true;
      } else {
        if (validate[i] === "doct_avil_slot") {
          throw CustomError.create({
            httpCode: StatusCodes.NOT_FOUND,
            message: `DOCTOR DETAILS NOT EXIST IN ${ele.toUpperCase()}`,
            property: "",
            code: "NOT_FOUND"
          });
        } else {
          const d_str = validate[i].toString();
          const desired_substring = d_str.slice(2);
          throw CustomError.create({
            httpCode: StatusCodes.NOT_FOUND,
            message: `DOCTOR DETAILS NOT EXIST IN ${desired_substring.toUpperCase()}`,
            property: "",
            code: "NOT_FOUND"
          });
        }
      }
    }

    const query = knexPatient.raw(`select * from patient_booking as a
    where a.appointment_status!=3 and a.appointment_status!=4 and a.appointment_status!=2 and a.is_followup!=1 and  doctor_id=${doctor_id}`);
    const response = await query;
    const flattenedArray = response.flat();
    const total = [];
    if (flattenedArray.length > 0) {
      const query1 = knex.raw(`SELECT *,
        FORMAT(
            DATEADD(DAY, 
                CASE
                    WHEN day = DATENAME(WEEKDAY, GETDATE()) THEN 0
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 1, GETDATE())) THEN 1
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 2, GETDATE())) THEN 2
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 3, GETDATE())) THEN 3
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 4, GETDATE())) THEN 4
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 5, GETDATE())) THEN 5
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 6, GETDATE())) THEN 6
                    ELSE 7
                END, GETDATE()), 'MMM d, yyyy, ddd') AS formatted_date
                FROM doct_avil_slot
                WHERE doctor_name_id =${doctor_id}
                ORDER BY
                CASE
                  WHEN day = DATENAME(WEEKDAY, GETDATE()) THEN 1
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 1, GETDATE())) THEN 2
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 2, GETDATE())) THEN 3
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 3, GETDATE())) THEN 4
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 4, GETDATE())) THEN 5
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 5, GETDATE())) THEN 6
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 6, GETDATE())) THEN 7
                  ELSE 8
                END;
                `);

      // const query1 = knex.raw(`select * from doct_avil_slot where doctor_name_id=${doctor_id}`);
      const response1 = await query1;
      const flattenedArray_data = response1.flat();
      for (let i = 0; i < flattenedArray.length; i++) {
        for (let j = 0; j < flattenedArray_data.length; j++) {
          const value = flattenedArray_data[j].slot_1;
          const data = flattenedArray_data[j].slot_active;
          var outputDate = moment(
            flattenedArray_data[j].formatted_date,
            "MMM D, yyyy, d"
          ).format("YYYY-MM-DD");
          const storedValue = value;
          const slot_data1 = [];
          const slot_data2 = [];
          const slot_data3 = [];

          if (storedValue != "" && storedValue != undefined) {
            const [startTimeStr, endTimeStr, active] = storedValue.split(",");
            if (active == 1) {
              const startTime = moment(startTimeStr.trim(), "hh:mma");
              const endTime = moment(endTimeStr.trim(), "hh:mma");

              function generateTimeSlots(startTime, endTime, intervalMinutes) {
                const timeSlots = [];
                const currentTime = moment(startTime);

                while (currentTime.isBefore(endTime)) {
                  timeSlots.push(currentTime.format("hh:mm A"));
                  currentTime.add(intervalMinutes, "minutes");
                }

                return timeSlots;
              }

              const inputString = flattenedArray_data[j].duration;
              const intervalMinutes = parseInt(inputString);
              const timeSlots1 = generateTimeSlots(
                startTime,
                endTime,
                intervalMinutes
              );

              timeSlots1.forEach(slot => {
                const slot_ch = slot.replace(/\s/g, "");
                if (
                  flattenedArray[i].appointment_from_time === slot_ch &&
                  flattenedArray[i].doctor_id ===
                    flattenedArray_data[j].doctor_name_id &&
                  outputDate === flattenedArray[i].appointment_date
                ) {
                  const t1 = {
                    slot1: "slot1",
                    doctor_id: flattenedArray[i].doctor_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "booked"
                  };
                  slot_data1.push(t1);
                } else {
                  const t1 = {
                    slot1: "slot1",
                    doctor_id: flattenedArray_data[j].doctor_name_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "avilable"
                  };
                  slot_data1.push(t1);
                }
              });
            }
          }
          const value_slot_2 = flattenedArray_data[j].slot_2;
          const storedValue_slot_2 = value_slot_2;

          if (storedValue_slot_2 != "" && storedValue_slot_2 != undefined) {
            const [startTimeStr_slot2, endTimeStr_slot2, active] =
              storedValue_slot_2.split(",");

            if (active == 1) {
              const startTime_slot_2 = moment(
                startTimeStr_slot2.trim(),
                "hh:mma"
              );
              const endTime_slot_2 = moment(endTimeStr_slot2.trim(), "hh:mma");

              function generateTimeSlots(
                startTime_slot_2,
                endTime_slot_2,
                intervalMinutes
              ) {
                const timeSlots = [];
                const currentTime = moment(startTime_slot_2);

                while (currentTime.isBefore(endTime_slot_2)) {
                  timeSlots.push(currentTime.format("hh:mm A"));
                  currentTime.add(intervalMinutes, "minutes");
                }

                return timeSlots;
              }

              const inputString = flattenedArray_data[j].duration;
              const intervalMinutes = parseInt(inputString);
              const timeSlots2 = generateTimeSlots(
                startTime_slot_2,
                endTime_slot_2,
                intervalMinutes
              );

              timeSlots2.forEach(slot => {
                const slot_ch = slot.replace(/\s/g, "");
            

                if (
                  flattenedArray[i].appointment_from_time == slot_ch &&
                  flattenedArray[i].doctor_id ==
                    flattenedArray_data[j].doctor_name_id &&
                  outputDate === flattenedArray[i].appointment_date
                ) {
                  const t2 = {
                    slot2: "slot2",
                    doctor_id: flattenedArray[i].doctor_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "booked"
                  };
                  slot_data2.push(t2);
                } else {
                  const t2 = {
                    slot2: "slot2",
                    doctor_id: flattenedArray_data[j].doctor_name_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "avilable"
                  };
                  slot_data2.push(t2);
                }
              });
            }
          }

          const value_slot_3 = flattenedArray_data[j].slot_3;
          const storedValue_slot_3 = value_slot_3;

          if (storedValue_slot_3 != "" && storedValue_slot_3 != undefined) {
            const [startTimeStr_slot3, endTimeStr_slot3, active] =
              storedValue_slot_3.split(",");
            if (active == 1) {
              const startTime_slot_3 = moment(
                startTimeStr_slot3.trim(),
                "hh:mma"
              );
              const endTime_slot_3 = moment(endTimeStr_slot3.trim(), "hh:mma");

              function generateTimeSlots(
                startTime_slot_3,
                endTime_slot_3,
                intervalMinutes
              ) {
                const timeSlots = [];
                const currentTime = moment(startTime_slot_3);

                while (currentTime.isBefore(endTime_slot_3)) {
                  timeSlots.push(currentTime.format("hh:mm A"));
                  currentTime.add(intervalMinutes, "minutes");
                }

                return timeSlots;
              }

              const inputString = flattenedArray_data[j].duration;
              const intervalMinutes = parseInt(inputString);
              const timeSlots3 = generateTimeSlots(
                startTime_slot_3,
                endTime_slot_3,
                intervalMinutes
              );

              timeSlots3.forEach(slot => {
                const slot_ch = slot.replace(/\s/g, "");
               

                if (
                  flattenedArray[i].appointment_from_time == slot_ch &&
                  flattenedArray[i].doctor_id ==
                    flattenedArray_data[j].doctor_name_id &&
                  outputDate === flattenedArray[i].appointment_date
                ) {
                  const t3 = {
                    slot3: "slot3",
                    doctor_id: flattenedArray[i].doctor_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "booked"
                  };
                  slot_data3.push(t3);
                } else {
                  const t3 = {
                    slot3: "slot3",
                    doctor_id: flattenedArray_data[j].doctor_name_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "avilable"
                  };
                  slot_data3.push(t3);
                }
              });
            }
          }

          const doctor_name_id = flattenedArray_data[j].doctor_name_id;
          const day = flattenedArray_data[j].day;
          const video = flattenedArray_data[j].video;
          const walking = flattenedArray_data[j].walkin;
          const formatted_date = moment(flattenedArray_data[j].formatted_date, "MMM D, YYYY, ddd").format("MMM D, ddd");
          const video_walking = body.video_walking;
          // const video_walking =
          //   flattenedArray[i].hospitalcounsul_or_videoconsul;
          total.push({
            doctor_name_id,
            formatted_date,
            day,
            video,
            walking,
            video_walking,
            slot_data1,
            slot_data2,
            slot_data3
          });
        }
      }

      const start_slot = [];
      total.map(ele => {
        if (
          ele.slot_data1.length > 0 ||
          ele.slot_data2.length > 0 ||
          ele.slot_data3.length > 0
        ) {
          const d1 = ele.slot_data1;
          const d2 = ele.slot_data2;
          const d3 = ele.slot_data3;
          d1.forEach(slot => {
            if (slot.slot_booked_or_not == "booked") {
              start_slot.push(slot);
            }
          });

          d2.forEach(slot => {
            if (slot.slot_booked_or_not == "booked") {
              start_slot.push(slot);
            }
          });

          d3.forEach(slot => {
            if (slot.slot_booked_or_not == "booked") {
              start_slot.push(slot);
            }
          });
        }
      });
      start_slot.forEach(start_slot_data => {
        const d_id = start_slot_data.doctor_id;
        const date = moment(start_slot_data.formatted_date, "MMM D, d").format(
          "YYYY-MM-DD"
        );
        const appoinment_time = start_slot_data.appoinment_time;
        const slot1 = start_slot_data.slot1;

        total.forEach(data => {
          data.slot_data1.map(slot => {
            if (
              slot.doctor_id == d_id &&
              moment(slot.formatted_date, "MMM D, d").format("YYYY-MM-DD") ==
                date &&
              slot.avilable_slot == start_slot_data.avilable_slot
            ) {
              slot.slot_booked_or_not = "booked";
            }
          });
        });

        total.forEach(data => {
          data.slot_data2.map(slot => {
            if (
              slot.doctor_id == d_id &&
              moment(slot.formatted_date, "MMM D, d").format("YYYY-MM-DD") ==
                date &&
              slot.avilable_slot == start_slot_data.avilable_slot
            ) {
              slot.slot_booked_or_not = "booked";
            }
          });
        });

        total.forEach(data => {
          data.slot_data3.map(slot => {
            if (
              slot.doctor_id == d_id &&
              moment(slot.formatted_date, "MMM D, d").format("YYYY-MM-DD") ==
                date &&
              slot.avilable_slot == start_slot_data.avilable_slot
            ) {
              slot.slot_booked_or_not = "booked";
            }
          });
        });
      });
      const paitent_booking_total = [];
      const paitent_booking =
        knexPatient.raw(`select DISTINCT  doctor_id from patient_booking as a
      where a.appointment_status!=3 and a.appointment_status!=4 and a.appointment_status!=2 and a.is_followup!=1 and doctor_id=${doctor_id}`);
      const paitent_booking_response = await paitent_booking;
      const paitent_booking_flattenedArray = paitent_booking_response.flat();

      var uniqueData = Array.from(
        new Set(total.map(JSON.stringify)),
        JSON.parse
      );

      const doc_all_id = knex.raw(`SELECT
      a.id AS doctor_id,
      a.doctor_name,
      a.gender_id,
      a.email,
      a.phone_no,
      a.dob,
      a.age,
      a.about,
      a.image_path,
      a.active,
      a.created_at,
      a.updated_at,
      a.created_by,
      a.updated_by,
      a.addCheck,
      a.reason,
      a.isApproved,
      a.doctor_type_id,
      a.hospital_name_id,
      a.approved_by,
      a.approve_date,
      a.last_otp,
      a.workplacetype,
      a.update_on_whatsapp,
      a.rating,
      b.doctor_name_id AS address_doctor_name_id,
      b.address1,
      b.address2,
      b.city_id,
      b.state_id,
      b.country_id,
      b.pincode,
      b.location,
      b.longitude,
      b.latitude,
      b.longitude1,
      b.latitude1,
      b.pincode1,
      c.experience,
      c.specialization_id,
      f.speciality_name,
      g.registration_no,
      g.registration_date,
      STRING_AGG(e.language_name, ', ') AS concatenated_languages
  FROM d_doctor_basic_info AS a
  LEFT JOIN d_address_info AS b ON b.doctor_name_id = a.id
  LEFT JOIN d_experience_info AS c ON c.doctor_name_id = a.id and b.doctor_name_id = a.id
  LEFT JOIN d_language_info AS d ON d.doctor_name_id = a.id and b.doctor_name_id = a.id and c.doctor_name_id = a.id
   LEFT JOIN d_council_info AS g ON g.doctor_name_id = a.id and b.doctor_name_id = a.id and c.doctor_name_id = a.id
  LEFT JOIN languages AS e ON e.id = d.language_name_id 
  LEFT JOIN specialities AS f ON f.id = a.speciality_id
  WHERE a.active = 1 and a.id=${doctor_id} and a.isApproved =1
  GROUP BY
      a.id,
      a.doctor_name,
      a.gender_id,
      a.email,
      a.phone_no,
      a.dob,
      a.age,
      a.about,
      a.image_path,
      a.active,
      a.created_at,
      a.updated_at,
      a.created_by,
      a.updated_by,
      a.addCheck,
      a.reason,
      a.isApproved,
      a.doctor_type_id,
      a.hospital_name_id,
      a.approved_by,
      a.approve_date,
      a.last_otp,
      a.workplacetype,
      a.update_on_whatsapp,
       a.rating,
      b.doctor_name_id,
      b.address1,
      b.address2,
      b.city_id,
      b.state_id,
      b.country_id,
      b.pincode,
      b.location,
      b.longitude,
      b.latitude,
      b.longitude1,
      b.latitude1,
      b.pincode1,
      c.experience,
      c.specialization_id,
      f.speciality_name,
      g.registration_no,
      g.registration_date`);

      const doc_all_id_data = await doc_all_id;
      const get_doc_id = doc_all_id_data.flat();

      if (get_doc_id.length == 0) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Please Update Address AND Experience Detailes",
          property: "",
          code: "NOT_FOUND"
        });
      }

      const final = [];
      const { getalldocInfobyid } = getalldocdistance.getdocslotByid(fastify);
      const userlong = logitute;
      const userlat = latitude;
      const video_walking_detailes = hospitalcounsul_or_videoconsul;
      const d_id = body.doctor_id;
      const promise1 = getalldocInfobyid.call(knex, {
        logTrace,
        d_id,
        userlong,
        userlat
      });
      const getappadddata = await Promise.all([promise1]);
      const get_dis_all_doc = getappadddata.flat();

      const get_payment = knex.raw(
        `SELECT * FROM d_consulted_fees where doctor_id=${doctor_id} `
      );
      const get_payment_all = await get_payment;

      const get_payment_detailes = get_payment_all.find(
        ele => ele.doctor_id == d_id
      );
      if (video_walking_detailes === 0) {
        if (get_payment_detailes != undefined) {
          var payment = get_payment_detailes.v_how_mouch_you_get;
        }
      }
      if (video_walking_detailes === 1) {
        if (get_payment_detailes != undefined) {
          var payment = get_payment_detailes.w_how_mouch_you_get;
        }
      }

      final.push({
        slot: uniqueData,
        doctor_detailes: get_doc_id[0],
        payment: payment,
        distance: get_dis_all_doc[0].dis
      });

      if (final.length == 0) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Result is Empty",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return final;
    }
  }

  return {
    reschedulepost
  };
}

function getreschedulepostv2DetailsPost(fastify) {
  async function reschedulepostv2({ logTrace, params, body }) {
    const knex = this;
    const knexPatients = fastify.knexPatient;
    var doctor_id = body.doctor_id;
    var patient_id = body.patient_id;
    var appointment_date = body.appointment_date;
    var appoinment_time = body.appoinment_time;
    var hospitalcounsul_or_videoconsul = body.hospitalcounsul_or_videoconsul;
    var logitute = body.logitute ? body.logitute : "11.0168";
    var latitude = body.latitude ? body.latitude : "76.9558";
    const query = knexPatients.raw(`select * from patient_booking as a
    where a.appointment_status!=3 and a.appointment_status!=4 and a.appointment_status!=2 and a.is_followup!=1 and  doctor_id=${doctor_id}`);
    const response = await query;
    const flattenedArray = response.flat();
    var total = [];
    if (flattenedArray.length > 0) {
      const query1 = knex.raw(`SELECT *,
        FORMAT(
            DATEADD(DAY, 
                CASE
                    WHEN day = DATENAME(WEEKDAY, GETDATE()) THEN 0
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 1, GETDATE())) THEN 1
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 2, GETDATE())) THEN 2
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 3, GETDATE())) THEN 3
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 4, GETDATE())) THEN 4
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 5, GETDATE())) THEN 5
                    WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 6, GETDATE())) THEN 6
                    ELSE 7
                END, GETDATE()), 'MMM d, yyyy, ddd') AS formatted_date
                FROM doct_avil_slot
                WHERE doctor_name_id =${doctor_id}
                ORDER BY
                CASE
                  WHEN day = DATENAME(WEEKDAY, GETDATE()) THEN 1
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 1, GETDATE())) THEN 2
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 2, GETDATE())) THEN 3
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 3, GETDATE())) THEN 4
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 4, GETDATE())) THEN 5
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 5, GETDATE())) THEN 6
                  WHEN day = DATENAME(WEEKDAY, DATEADD(DAY, 6, GETDATE())) THEN 7
                  ELSE 8
                END;
                `);

      // const query1 = knex.raw(`select * from doct_avil_slot where doctor_name_id=${doctor_id}`);
      const response1 = await query1;
      const flattenedArray_data = response1.flat();
      for (let i = 0; i < flattenedArray.length; i++) {
        for (let j = 0; j < flattenedArray_data.length; j++) {
          const value = flattenedArray_data[j].slot_1;
          const data = flattenedArray_data[j].slot_active;
          var outputDate = moment(
            flattenedArray_data[j].formatted_date,
            "MMM D, yyyy, d"
          ).format("YYYY-MM-DD");
          const storedValue = value;
          const slot_data1 = [];
          const slot_data2 = [];
          const slot_data3 = [];

          if (storedValue != "" && storedValue != undefined) {
            const [startTimeStr, endTimeStr, active] = storedValue.split(",");
            if (active == 1) {
              const startTime = moment(startTimeStr.trim(), "hh:mma");
              const endTime = moment(endTimeStr.trim(), "hh:mma");

              function generateTimeSlots(startTime, endTime, intervalMinutes) {
                const timeSlots = [];
                const currentTime = moment(startTime);

                while (currentTime.isBefore(endTime)) {
                  timeSlots.push(currentTime.format("hh:mm A"));
                  currentTime.add(intervalMinutes, "minutes");
                }

                return timeSlots;
              }

              const inputString = flattenedArray_data[j].duration;
              const intervalMinutes = parseInt(inputString);
              const timeSlots1 = generateTimeSlots(
                startTime,
                endTime,
                intervalMinutes
              );

              timeSlots1.forEach(slot => {
                const slot_ch = slot.replace(/\s/g, "");

                if (
                  flattenedArray[i].appointment_from_time === slot_ch &&
                  flattenedArray[i].doctor_id ===
                    flattenedArray_data[j].doctor_name_id &&
                  outputDate === flattenedArray[i].appointment_date
                ) {
                  const t1 = {
                    slot1: "slot1",
                    doctor_id: flattenedArray[i].doctor_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "booked"
                  };
                  slot_data1.push(t1);
                } else {
                  const t1 = {
                    slot1: "slot1",
                    doctor_id: flattenedArray_data[j].doctor_name_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "avilable"
                  };
                  slot_data1.push(t1);
                }
              });
            }
          }
          const value_slot_2 = flattenedArray_data[j].slot_2;
          const storedValue_slot_2 = value_slot_2;

          if (storedValue_slot_2 != "" && storedValue_slot_2 != undefined) {
            const [startTimeStr_slot2, endTimeStr_slot2, active] =
              storedValue_slot_2.split(",");

            if (active == 1) {
              const startTime_slot_2 = moment(
                startTimeStr_slot2.trim(),
                "hh:mma"
              );
              const endTime_slot_2 = moment(endTimeStr_slot2.trim(), "hh:mma");

              function generateTimeSlots(
                startTime_slot_2,
                endTime_slot_2,
                intervalMinutes
              ) {
                const timeSlots = [];
                const currentTime = moment(startTime_slot_2);

                while (currentTime.isBefore(endTime_slot_2)) {
                  timeSlots.push(currentTime.format("hh:mm A"));
                  currentTime.add(intervalMinutes, "minutes");
                }

                return timeSlots;
              }

              const inputString = flattenedArray_data[j].duration;
              const intervalMinutes = parseInt(inputString);
              const timeSlots2 = generateTimeSlots(
                startTime_slot_2,
                endTime_slot_2,
                intervalMinutes
              );

              timeSlots2.forEach(slot => {
                const slot_ch = slot.replace(/\s/g, "");

                if (
                  flattenedArray[i].appointment_from_time == slot_ch &&
                  flattenedArray[i].doctor_id ==
                    flattenedArray_data[j].doctor_name_id &&
                  outputDate === flattenedArray[i].appointment_date
                ) {
                  const t2 = {
                    slot2: "slot2",
                    doctor_id: flattenedArray[i].doctor_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "booked"
                  };
                  slot_data2.push(t2);
                } else {
                  const t2 = {
                    slot2: "slot2",
                    doctor_id: flattenedArray_data[j].doctor_name_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "avilable"
                  };
                  slot_data2.push(t2);
                }
              });
            }
          }

          const value_slot_3 = flattenedArray_data[j].slot_3;
          const storedValue_slot_3 = value_slot_3;

          if (storedValue_slot_3 != "" && storedValue_slot_3 != undefined) {
            const [startTimeStr_slot3, endTimeStr_slot3, active] =
              storedValue_slot_3.split(",");
            if (active == 1) {
              const startTime_slot_3 = moment(
                startTimeStr_slot3.trim(),
                "hh:mma"
              );
              const endTime_slot_3 = moment(endTimeStr_slot3.trim(), "hh:mma");

              function generateTimeSlots(
                startTime_slot_3,
                endTime_slot_3,
                intervalMinutes
              ) {
                const timeSlots = [];
                const currentTime = moment(startTime_slot_3);

                while (currentTime.isBefore(endTime_slot_3)) {
                  timeSlots.push(currentTime.format("hh:mm A"));
                  currentTime.add(intervalMinutes, "minutes");
                }

                return timeSlots;
              }

              const inputString = flattenedArray_data[j].duration;
              const intervalMinutes = parseInt(inputString);
              const timeSlots3 = generateTimeSlots(
                startTime_slot_3,
                endTime_slot_3,
                intervalMinutes
              );

              timeSlots3.forEach(slot => {
                const slot_ch = slot.replace(/\s/g, "");

                if (
                  flattenedArray[i].appointment_from_time == slot_ch &&
                  flattenedArray[i].doctor_id ==
                    flattenedArray_data[j].doctor_name_id &&
                  outputDate === flattenedArray[i].appointment_date
                ) {
                  const t3 = {
                    slot3: "slot3",
                    doctor_id: flattenedArray[i].doctor_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "booked"
                  };
                  slot_data3.push(t3);
                } else {
                  const t3 = {
                    slot3: "slot3",
                    doctor_id: flattenedArray_data[j].doctor_name_id,
                    duration: flattenedArray[i].appointment_duartion,
                    formatted_date: outputDate,
                    day: flattenedArray_data[j].day,
                    avilable_slot: slot_ch,
                    slot_booked_or_not: "avilable"
                  };
                  slot_data3.push(t3);
                }
              });
            }
          }

          const doctor_name_id = flattenedArray_data[j].doctor_name_id;
          const day = flattenedArray_data[j].day;
          const video = flattenedArray_data[j].video;
          const walking = flattenedArray_data[j].walkin;
          const formatted_date = moment(flattenedArray_data[j].formatted_date, "MMM D, YYYY, ddd").format("MMM D, ddd");
          const video_walking = body.video_walking;
          // flattenedArray[i].hospitalcounsul_or_videoconsul;
          total.push({
            doctor_name_id,
            formatted_date,
            day,
            video,
            walking,
            video_walking,
            slot_data1,
            slot_data2,
            slot_data3
          });
        }
      }
      const { getalldocInfobyid } = getalldocdistance.getdocslotByid(fastify);
      const userlong = body.longitude;
      const userlat = body.latitude;
      const video_walking_detailes = body.video_walking;
      const d_id = body.doctor_id;
      const promise1 = getalldocInfobyid.call(knex, {
        logTrace,
        d_id,
        userlong,
        userlat
      });
      const getappadddata = await Promise.all([promise1]);
      const get_dis_all_doc = getappadddata.flat();

      const doc_all_id = knex.raw(`SELECT
      a.id AS doctor_id,
      a.doctor_name,
      a.gender_id,
      a.email,
      a.phone_no,
      a.dob,
      a.age,
      a.about,
      a.image_path,
      a.active,
      a.created_at,
      a.updated_at,
      a.created_by,
      a.updated_by,
      a.addCheck,
      a.reason,
      a.isApproved,
      a.doctor_type_id,
      a.hospital_name_id,
      a.approved_by,
      a.approve_date,
      a.last_otp,
      a.workplacetype,
      a.update_on_whatsapp,
      a.rating,
      b.doctor_name_id AS address_doctor_name_id,
      b.address1,
      b.address2,
      b.city_id,
      b.state_id,
      b.country_id,
      b.pincode,
      b.location,
      b.longitude,
      b.latitude,
      b.longitude1,
      b.latitude1,
      b.pincode1,
      c.experience,
      c.specialization_id,
      f.speciality_name,
      g.registration_no,
      g.registration_date,
      STRING_AGG(e.language_name, ', ') AS concatenated_languages
  FROM d_doctor_basic_info AS a
  LEFT JOIN d_address_info AS b ON b.doctor_name_id = a.id
  LEFT JOIN d_experience_info AS c ON c.doctor_name_id = a.id and b.doctor_name_id = a.id
  LEFT JOIN d_language_info AS d ON d.doctor_name_id = a.id and b.doctor_name_id = a.id and c.doctor_name_id = a.id
   LEFT JOIN d_council_info AS g ON g.doctor_name_id = a.id and b.doctor_name_id = a.id and c.doctor_name_id = a.id
  LEFT JOIN languages AS e ON e.id = d.language_name_id 
  LEFT JOIN specialities AS f ON f.id = a.speciality_id
  WHERE a.active = 1 and a.id=${doctor_id} and a.isApproved =1
  GROUP BY
      a.id,
      a.doctor_name,
      a.gender_id,
      a.email,
      a.phone_no,
      a.dob,
      a.age,
      a.about,
      a.image_path,
      a.active,
      a.created_at,
      a.updated_at,
      a.created_by,
      a.updated_by,
      a.addCheck,
      a.reason,
      a.isApproved,
      a.doctor_type_id,
      a.hospital_name_id,
      a.approved_by,
      a.approve_date,
      a.last_otp,
      a.workplacetype,
      a.update_on_whatsapp,
       a.rating,
      b.doctor_name_id,
      b.address1,
      b.address2,
      b.city_id,
      b.state_id,
      b.country_id,
      b.pincode,
      b.location,
      b.longitude,
      b.latitude,
      b.longitude1,
      b.latitude1,
      b.pincode1,
      c.experience,
      c.specialization_id,
      f.speciality_name,
      g.registration_no,
      g.registration_date`);

      const doc_all_id_data = await doc_all_id;
      const get_doc_id = doc_all_id_data.flat();
      if (get_doc_id.length == 0) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Please Update Address AND Experience Detailes",
          property: "",
          code: "NOT_FOUND"
        });
      }

      const finall = [];

      const get_payment = knex.raw(
        `SELECT * FROM d_consulted_fees where doctor_id=${doctor_id} `
      );
      const get_payment_all = await get_payment;
      get_doc_id.forEach(details => {
        var get_doc_dis_all;
        const get_doc_dis = get_dis_all_doc.find(
          ele => ele.doctor_id == details.doctor_id
        );
        if (get_doc_dis != undefined) {
          get_doc_dis_all = get_doc_dis.dis;
        }

        var doctorIds = total.map(item => {
          if (item.doctor_name_id == details.doctor_id) {
            finall.push(
              item
              // doctor_basic_detailes: details,
              // doc_distance: { distance: get_doc_dis_all }
            );
          }
        });
      });
      // return finall
      const start_slot = [];
      finall.map(ele => {
        if (
          ele.slot_data1.length > 0 ||
          ele.slot_data2.length > 0 ||
          ele.slot_data3.length > 0
        ) {
          const d1 = ele.slot_data1;
          const d2 = ele.slot_data2;
          const d3 = ele.slot_data3;
          d1.forEach(slot => {
            if (slot.slot_booked_or_not == "booked") {
              start_slot.push(slot);
            }
          });

          d2.forEach(slot => {
            if (slot.slot_booked_or_not == "booked") {
              start_slot.push(slot);
            }
          });

          d3.forEach(slot => {
            if (slot.slot_booked_or_not == "booked") {
              start_slot.push(slot);
            }
          });
        }
      });

      start_slot.forEach(start_slot_data => {
        const d_id = start_slot_data.doctor_id;
        const day = start_slot_data.day;
        const appoinment_time = start_slot_data.appoinment_time;
        const slot1 = start_slot_data.slot1;

        finall.forEach(data => {
          data.slot_data1.map(slot => {
            if (
              slot.doctor_id == d_id &&
              slot.day == day &&
              slot.avilable_slot == start_slot_data.avilable_slot
            ) {
              slot.slot_booked_or_not = "booked";
            }
          });
        });

        finall.forEach(data => {
          data.slot_data2.map(slot => {
            if (
              slot.doctor_id == d_id &&
              slot.day == day &&
              slot.avilable_slot == start_slot_data.avilable_slot
            ) {
              slot.slot_booked_or_not = "booked";
            }
          });
        });

        finall.forEach(data => {
          data.slot_data3.map(slot => {
            if (
              slot.doctor_id == d_id &&
              slot.day == day &&
              slot.avilable_slot == start_slot_data.avilable_slot
            ) {
              slot.slot_booked_or_not = "booked";
            }
          });
        });
      });

      const uniqueData = Array.from(
        new Set(finall.map(JSON.stringify)),
        JSON.parse
      );

      if (uniqueData.length == 0) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Result is Empty",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return uniqueData;
    }
  }

  return {
    reschedulepostv2
  };
}

function getreschedulepostfinal(fastify) {
  async function reschedulepostfinal({ logTrace, params, body }) {
    const knex = this;
    const knexPatient = fastify.knexPatient;
    var doctor_id = body.doctor_id;
    var patient_id = body.patient_id;
    var appointment_date = body.appointment_date;
    var appoinment_time = body.appoinment_time;
    var hospitalcounsul_or_videoconsul = body.hospitalcounsul_or_videoconsul;
    var logitute = body.logitute ? body.logitute : "11.0168";
    var latitude = body.latitude ? body.latitude : "76.9558";

    var new_appointment_date = body.new_appointment_date;
    var new_appoinment_time = body.new_appoinment_time;
    var new_reason = body.new_reason;
    try {
      var response = await knexPatient('patient_booking')
        .select('*')
        .where('doctor_id', doctor_id)
        .where('patient_id', patient_id)
        .where('appointment_date', appointment_date)
        .where('appointment_from_time', appoinment_time)
        .where('hospitalcounsul_or_videoconsul', hospitalcounsul_or_videoconsul);
  
      if(response.length===0){
        return  CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Appoinment not found",
          property: "",
          code: "NOT_FOUND"
        });
      }
    } 
    catch (error) {
      console.error('er',error);
      throw error;
    }
    // const query =
    //   knexPatient.raw(`select * from patient_booking where doctor_id=${doctor_id} and patient_id=${patient_id} and 
    // appointment_date='${appointment_date}'
    //  and appointment_from_time='${appoinment_time}' and hospitalcounsul_or_videoconsul=${hospitalcounsul_or_videoconsul}`);
    // const response = await query;
    // if(response.length===0){
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Appoinment not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }
    const patient_booking_id = response[0].id;
   
    var booking_amt_exist = response[0].booking_amt;
    var d_platform_charge = response[0].d_platform_charge;

    const query1 = await knexPatient(`${PAITENTBOOKINGINFO.NAME}`)
      .where(`${PAITENTBOOKINGINFO.COLUMNS.ID}`, patient_booking_id)
      .update({
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]: 2
      });

    const { createMeet } = meet(fastify);
    const meet_name = "Health Uno";
    const meet_id = "Health Uno"; //appointment id
    const hostuser = "Health Uno"; // docter name or huno name
    const participant_id = "TEST" + patient_id;
    const starts_at = new Date(
      `${new_appointment_date} ${new_appoinment_time}`
    );
    const starts_at_time = new_appoinment_time; // Note the correct time format

    // Parse the time and add 20 minutes
    const ends_at = new Date(starts_at);
    const [hours, minutes] = starts_at_time.split(":").map(Number);
    ends_at.setHours(hours);
    ends_at.setMinutes(minutes + 20);

    const starts_at_unix = new Date(starts_at).getTime(); // Get timestamp in milliseconds
    const ends_at_unix = new Date(ends_at).getTime(); // Get timestamp in milliseconds
    // const starts_at_unix = starts_at.getTime();
    // const ends_at_unix = ends_at.getTime();

    const hostuid = Buffer.from(hostuser).toString("base64");
    const participantuid = Buffer.from(participant_id).toString("base64");
    const displayName = Buffer.from(process.env.VIDEO_SESSION_NAME).toString(
      "base64"
    );

    const result = await createMeet(
      meet_name,
      meet_id,
      hostuser,
      starts_at_unix,
      ends_at_unix
    );
    const session_id = result.sessionId;
    const doctor_url =
      "https://healthuno.invc.vc/" +
      result.sessionId +
      "?displayName=" +
      displayName +
      "&projectId=" +
      process.env.VIDEO_PROJECT_ID +
      "&uid=" +
      hostuid;
    const patient_url =
      "https://healthuno.invc.vc/" +
      result.sessionId +
      "?projectId=" +
      process.env.VIDEO_PROJECT_ID +
      "&uid=" +
      participantuid;

    const date = new Date(new_appointment_date);
    const daysOfWeek = [
      "Sunday",
      "Monday",
      "Tuesday",
      "Wednesday",
      "Thursday",
      "Friday",
      "Saturday"
    ];

    const dayIndex = date.getDay();
    const dayOfWeek = daysOfWeek[dayIndex];
    const query2 = await knexPatient(`${PAITENTBOOKINGINFO.NAME}`)
      .insert({
        [PAITENTBOOKINGINFO.COLUMNS.DOTOR_ID]: doctor_id,
        [PAITENTBOOKINGINFO.COLUMNS.PATIENT_ID]: patient_id,
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DATE]: new_appointment_date,
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DAY]: dayOfWeek,
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_FROM_TIME]: new_appoinment_time,
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_TO_TIME]: "",
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]: 1, // "1-booked," ,"available" ,"4-cancelled," or "attended","3-completed",2-rescheduled
        [PAITENTBOOKINGINFO.COLUMNS.REASON]: new_reason,
        [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DURATION]:
          response[0].appointment_duartion,
        [PAITENTBOOKINGINFO.COLUMNS.CLINICAL_ID]: 0,
        [PAITENTBOOKINGINFO.COLUMNS.HOSPITAL_ID]: 0,
        [PAITENTBOOKINGINFO.COLUMNS.CONFIRMATION_STATUS]: 0, //1 for confirmed ,0-booked ,
        [PAITENTBOOKINGINFO.COLUMNS.IS_FOLLOWUP]: 0, //1 for followup, 0 un followup
        [PAITENTBOOKINGINFO.COLUMNS.HOSPITALCONSUl_OR_VIDEOCONSUL]:
          hospitalcounsul_or_videoconsul,
        [PAITENTBOOKINGINFO.COLUMNS.D_PLATFORM_CHARGE]: 0,
        [PAITENTBOOKINGINFO.COLUMNS.BOOKING_AMT]: 0,
        [PAITENTBOOKINGINFO.COLUMNS.CREATED_AT]: new Date(),
        [PAITENTBOOKINGINFO.COLUMNS.CREATED_BY]: 1,
        [PAITENTBOOKINGINFO.COLUMNS.RAZOR_PAYMENT_ID]:
          response[0].razor_payment_id,
        [PAITENTBOOKINGINFO.COLUMNS.BOOKING_REFERAL_ID]: response[0].id,
        [PAITENTBOOKINGINFO.COLUMNS.DOCTOR_URL]: doctor_url,
        [PAITENTBOOKINGINFO.COLUMNS.PATIENT_URL]: patient_url,
        [PAITENTBOOKINGINFO.COLUMNS.SESSION_ID]: session_id
      })
      .returning(PAITENTBOOKINGINFO.COLUMNS.ID);

    const response2 = query2;

    // const get_payment = knex.raw(
    //   `SELECT * FROM d_consulted_fees where doctor_id=${doctor_id} `
    // );
    // const get_payment_all = await get_payment;

    // if(parseInt(hospitalcounsul_or_videoconsul)===0){
    //    var booking_amt=get_payment_all[0].v_how_mouch_you_get;
    //    var platform_charge= get_payment_all[0].v_platform_charge;
    // }
    // if(parseInt(hospitalcounsul_or_videoconsul)===1){
    //   var booking_amt=get_payment_all[0].w_how_mouch_you_get;
    //   var platform_charge= get_payment_all[0].w_platform_charge;
    // }
    const data_id = response2[0].id;

    const query3 = await knexPatient(`${PAITENTBOOKINGINFO.NAME}`)
      .where(`${PAITENTBOOKINGINFO.COLUMNS.ID}`, data_id)
      .update({
        [PAITENTBOOKINGINFO.COLUMNS.D_PLATFORM_CHARGE]: d_platform_charge
          ? d_platform_charge
          : 0,
        [PAITENTBOOKINGINFO.COLUMNS.BOOKING_AMT]: booking_amt_exist
          ? booking_amt_exist
          : 0
      });

    return { success: true, message: "Reschedule Successfully" };
  }
  async function getPatientInfo({ patient_id, logTrace }) {
    const knex = fastify.knexPatient;

    const query = knex(REGISTERINFO.NAME).where(
      REGISTERINFO.COLUMNS.ID,
      patient_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get patient details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "patient not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function getDoctorInfo({ doctor_id, logTrace }) {
    const knex = fastify.knexMaster;

    const query = knex(DOCTORBASICINFO.NAME).where(
      DOCTORBASICINFO.COLUMNS.ID,
      doctor_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "doctor not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }

  return {
    reschedulepostfinal,
    getPatientInfo,
    getDoctorInfo
  };
}

function getcancelpostfinal(fastify) {
  async function cancelpostfinal({ logTrace, params, body }) {
    const knex = this;
    const knexPatient = fastify.knexPatient;
    var doctor_id = body.doctor_id;
    var patient_id = body.patient_id;
    var reason = body.reason;
    var appointment_date = body.appointment_date;
    var appoinment_time = body.appoinment_time;
    var hospitalcounsul_or_videoconsul = body.hospitalcounsul_or_videoconsul;
    var logitute = body.logitute ? body.logitute : "11.0168";
    var latitude = body.latitude ? body.latitude : "76.9558";

    const query =
      knexPatient.raw(`select * from patient_booking where doctor_id=${doctor_id} and patient_id=${patient_id} and 
    appointment_date='${appointment_date}'
     and appointment_from_time='${appoinment_time}' and hospitalcounsul_or_videoconsul=${hospitalcounsul_or_videoconsul} order By id desc`);
    const response = await query;
    if(response.length===0){
      return  CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Appoinment not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    const patient_booking_id = response[0].id;
    const booking_amt = response[0].booking_amt;
    if (booking_amt === null) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Your Booking Amt is Not Added Please Call HelpLine",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const query1_provies_blnc = await knexPatient(`${REGISTERINFO.NAME}`).where(
      `${REGISTERINFO.COLUMNS.ID}`,
      patient_id
    );
    const totall_wallet =
      parseInt(booking_amt) + parseInt(query1_provies_blnc[0].wallet_amt);
    // if(totall_wallet){
    const query1 = await knexPatient(`${REGISTERINFO.NAME}`)
      .where(`${REGISTERINFO.COLUMNS.ID}`, patient_id)
      .update({
        [REGISTERINFO.COLUMNS.WALLET_AMT]: totall_wallet
      });

    if (query1) {
      const query2 = await knexPatient(`${PAITENTBOOKINGINFO.NAME}`)
        .where(`${PAITENTBOOKINGINFO.COLUMNS.ID}`, patient_booking_id)
        .update({
          [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]: 4,
          [PAITENTBOOKINGINFO.COLUMNS.REASON]: reason
          // [PAITENTBOOKINGINFO.COLUMNS.BOOKING_AMT]: 0,
        });

        if(response[0].is_wallet ===1){
          var value=1;
        }
        if(response[0].is_healthcard===1){
          var value=2;
        }
        if(response[0].is_wallet ===0 && response[0].is_healthcard===0 ){
          var value=3;
        }
       

        const query4 = await knexPatient(`${WALLET_LEDGER.NAME}`).insert({
          [WALLET_LEDGER.COLUMNS.APPOINMENT_DATE]:appointment_date ,
          [WALLET_LEDGER.COLUMNS.PATIENT_ID]:patient_id,
          [WALLET_LEDGER.COLUMNS.DOCTOR_ID]:doctor_id,
          [WALLET_LEDGER.COLUMNS.PATIENT_BOOKING_ID]:patient_booking_id,
          [WALLET_LEDGER.COLUMNS.DEBIT]:'-',
          [WALLET_LEDGER.COLUMNS.CREDIT]: parseInt(booking_amt),
          [WALLET_LEDGER.COLUMNS.WALLET_HEALTHCARD]:value     //1-wallet,2-healthcard,3-normel
         
         });

        const response4 = await query4;

      return { success: true, message: "Cancelled Successfully" };
    }
    // }
  }



  async function getPatientInfo({ patient_id, logTrace }) {
    const knex = fastify.knexPatient;

    const query = knex(REGISTERINFO.NAME).where(
      REGISTERINFO.COLUMNS.ID,
      patient_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get patient details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "patient not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function getDoctorInfo({ doctor_id, logTrace }) {
    const knex = fastify.knexMaster;

    const query = knex(DOCTORBASICINFO.NAME).where(
      DOCTORBASICINFO.COLUMNS.ID,
      doctor_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "doctor not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }

  return {
    cancelpostfinal,
    getPatientInfo,
    getDoctorInfo
  };
}

// function getPatientDetailsPost(fastify) {
//   async function PatientDetailsGetOne({ logTrace, body }) {
//     const knex = this;
//     const knexPatient = fastify.knexPatient;
//     const doctor_id = body.doctor_id;
//     const check_video_walking = body.check_video_walking;
//     const currentTimestamp = Date.now();
//     // Convert the timestamp to a Date object
//     const currentDate = new Date(currentTimestamp);
//     // Extract the date part in ISO format (YYYY-MM-DD)
//     const formattedDate = currentDate.toISOString().split('T')[0];
//     // console.log(formattedDate,"formattedDate");

//     var fullDetail = []

//     if (check_video_walking == 0) {
//       const query =
//         knexPatient.raw(`select b.name,b.dob,b.gender_id,a.patient_id,b.mobile,b.logitute,b.latitude,a.appointment_day,a.appointment_date,
//       a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul,a.doctor_url,a.patient_url,
//       b.profile_image,b.email
//       from patient_booking as a
//       left join patient_registration as b on b.id=a.patient_id
//       where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  a.hospitalcounsul_or_videoconsul=0 and a.appointment_date = '${formattedDate}'`);
//       var responsePatientDetails = await query;

//       for (let i = 0; i < responsePatientDetails.length; i++) {

//         const patientId = responsePatientDetails[i].patient_id;

//         const query2 = knexPatient(PATIENT_RECORD.NAME)
//         .where(PATIENT_RECORD.COLUMNS.PATIENT_ID, patientId)
//         .orderBy(PATIENT_RECORD.COLUMNS.FILE_FLAG, "asc");

//         const responseEhrDetails = await query2

//          const fileFlagMapping = {
//         1: "EHRS",
//         2: "PRESCRPTION",
//         3: "INVESTIGATION",
//         4: "DIAGNOSIS",
//         5: "LABREPORTS",
//         6: "SCANREPORTS"
//       };
//       var groupedRecords = {
//         EHRS: [],
//         PRESCRPTION: [],
//         INVESTIGATION: [],
//         DIAGNOSIS: [],
//         LABREPORTS: [],
//         SCANREPORTS: []
//       };
//       responseEhrDetails.forEach(record => {
//         const { file_flag } = record;
//         const fileFlagKey = fileFlagMapping[file_flag];
//         if (fileFlagKey && groupedRecords[fileFlagKey]) {
//           const {
//             active,
//             created_at,
//             updated_at,
//             created_by,
//             updated_by,
//             ...filteredRecord
//           } = record;
//           groupedRecords[fileFlagKey].push(filteredRecord);
//         }
//       });

//     fullDetail.push({"patient_detailes":responsePatientDetails[i],"Records":groupedRecords})

//     }

// return fullDetail

//   }

//      else {
//       const query =
//         knexPatient.raw(`select b.name,b.dob,b.gender_id,a.patient_id,a.appointment_date,
//       a.appointment_day,b.mobile,b.logitute,b.latitude,b.profile_image,b.email,
//       a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul,a.doctor_url,a.patient_url
//       from patient_booking as a
//       left join patient_registration as b on b.id=a.patient_id
//        where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  a.hospitalcounsul_or_videoconsul=1 and a.appointment_date = '${formattedDate}'`);
//        const responsePatientDetails = await query;

//        for (let i = 0; i < responsePatientDetails.length; i++) {

//         const patientId = responsePatientDetails[i].patient_id;

//         const query2 = knexPatient(PATIENT_RECORD.NAME)
//         .where(PATIENT_RECORD.COLUMNS.PATIENT_ID, patientId)
//         .orderBy(PATIENT_RECORD.COLUMNS.FILE_FLAG, "asc");

//         const responseEhrDetails = await query2

//          const fileFlagMapping = {
//         1: "EHRS",
//         2: "PRESCRPTION",
//         3: "INVESTIGATION",
//         4: "DIAGNOSIS",
//         5: "LABREPORTS",
//         6: "SCANREPORTS"
//       };
//       var groupedRecords = {
//         EHRS: [],
//         PRESCRPTION: [],
//         INVESTIGATION: [],
//         DIAGNOSIS: [],
//         LABREPORTS: [],
//         SCANREPORTS: []
//       };
//       responseEhrDetails.forEach(record => {
//         const { file_flag } = record;
//         const fileFlagKey = fileFlagMapping[file_flag];
//         if (fileFlagKey && groupedRecords[fileFlagKey]) {
//           const {
//             active,
//             created_at,
//             updated_at,
//             created_by,
//             updated_by,
//             ...filteredRecord
//           } = record;
//           groupedRecords[fileFlagKey].push(filteredRecord);
//         }
//       });

//     fullDetail.push({"patient_detailes":responsePatientDetails[i],"Records":groupedRecords})

//     }

// return fullDetail

//     }
//   }
//   return {
//     PatientDetailsGetOne
//   };
// }
function getPatientDetailsPost(fastify) {
  async function PatientDetailsGetOne({ logTrace, body }) {
    const knex = this;
    const knexPatient = fastify.knexPatient;
    const doctor_id = body.doctor_id;
    const check_video_walking = body.check_video_walking;
    const currentTimestamp = Date.now();
    const currentDate = new Date(currentTimestamp);
    const formattedDate = currentDate.toISOString().split("T")[0];

    if (check_video_walking == 0) {
      const query =
        knexPatient.raw(`select b.name,a.patient_id,b.mobile,b.logitute,b.latitude,a.appointment_day,a.appointment_date,
      a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul,a.doctor_id,
      b.profile_image,b.email
      from patient_booking as a
      left join patient_registration as b on b.id=a.patient_id
      where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  a.hospitalcounsul_or_videoconsul=0 and a.appointment_date = '${formattedDate}'`);
      var responsePatientDetails = await query;

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patients details",
        logTrace
      });

      if (!responsePatientDetails.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patients info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return responsePatientDetails;
    } else {
      const query =
        knexPatient.raw(`select b.name,a.patient_id,b.mobile,b.logitute,b.latitude,a.appointment_day,a.appointment_date,
        a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul,a.doctor_id,
        b.profile_image,b.email
      from patient_booking as a
      left join patient_registration as b on b.id=a.patient_id
       where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  a.hospitalcounsul_or_videoconsul=1 and a.appointment_date = '${formattedDate}'`);
      const responsePatientDetails = await query;

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patients details",
        logTrace
      });

      if (!responsePatientDetails.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patients info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      return responsePatientDetails;
    }
  }

  return {
    PatientDetailsGetOne
  };
}

function getPatientDetailsWithEhrPost(fastify) {
  async function patientalldetailswithehr({ logTrace, body }) {
    const knexPatient = fastify.knexPatient;

    const knex = this;

    var doctor_id = body.doctor_id;
    var patient_id = body.patient_id;
    var appointment_date = body.appointment_date;
    var appoinment_time = body.appoinment_time;
    var hospitalcounsul_or_videoconsul = body.hospitalcounsul_or_videoconsul;
    var logitute = body.logitute;
    var latitude = body.latitude;

    if (hospitalcounsul_or_videoconsul == 0) {
      const query =
        knexPatient.raw(`select a.id,a.doctor_id,a.patient_id,a.appointment_date,
      a.appointment_from_time,a.appointment_status,a.reason,a.appointment_duartion,a.is_followup,a.hospitalcounsul_or_videoconsul,
      a.appointment_day,a.doctor_url,a.patient_url,b.name,b.email,b.gender_id,b.dob,b.mobile,b.blood_group_id,b.profile_image,
      b.logitute,b.latitude,b.address,b.age
      from patient_booking  as a 
           left join patient_registration as b on b.id=a.patient_id
           where a.doctor_id=${doctor_id} and a.patient_id=${patient_id} and
         a.appointment_date='${appointment_date}'
          and a.appointment_from_time='${appoinment_time}' and a.hospitalcounsul_or_videoconsul=${hospitalcounsul_or_videoconsul}`);

      const responsePatientDetails = await query;

      var data1_modified = { patientDetails: responsePatientDetails };

      const query2 = knexPatient(PATIENT_RECORD.NAME)
        .where(PATIENT_RECORD.COLUMNS.PATIENT_ID, patient_id)
        .orderBy(PATIENT_RECORD.COLUMNS.FILE_FLAG, "asc");

      const responseEhrDetails = await query2;

      const fileFlagMapping = {
        1: "EHRS",
        2: "PRESCRPTION",
        3: "INVESTIGATION",
        4: "DIAGNOSIS",
        5: "LABREPORTS",
        6: "SCANREPORTS"
      };

      const groupedRecords = {
        EHRS: [],
        PRESCRPTION: [],
        INVESTIGATION: [],
        DIAGNOSIS: [],
        LABREPORTS: [],
        SCANREPORTS: []
      };

      responseEhrDetails.forEach(record => {
        const { file_flag } = record;
        const fileFlagKey = fileFlagMapping[file_flag];
        if (fileFlagKey && groupedRecords[fileFlagKey]) {
          const {
            active,
            created_at,
            updated_at,
            created_by,
            updated_by,
            ...filteredRecord
          } = record;
          groupedRecords[fileFlagKey].push(filteredRecord);
        }
      });

      for (const key in groupedRecords) {
        if (groupedRecords.hasOwnProperty(key)) {
          if (data1_modified.hasOwnProperty(key)) {
            data1_modified[key] = data1_modified[key].concat(
              groupedRecords[key]
            );
          } else {
            data1_modified[key] = groupedRecords[key];
          }
        }
      }

      return data1_modified;
    } else {
      const query =
        knexPatient.raw(`select a.id,a.doctor_id,a.patient_id,a.appointment_date,
      a.appointment_from_time,a.appointment_status,a.reason,a.appointment_duartion,a.is_followup,a.hospitalcounsul_or_videoconsul,
      a.appointment_day,a.doctor_url,a.patient_url,b.name,b.email,b.gender_id,b.dob,b.mobile,b.blood_group_id,b.profile_image,
      b.logitute,b.latitude,b.address,b.age
      from patient_booking  as a 
           left join patient_registration as b on b.id=a.patient_id
           where a.doctor_id=${doctor_id} and a.patient_id=${patient_id} and
         a.appointment_date='${appointment_date}'
          and a.appointment_from_time='${appoinment_time}' and a.hospitalcounsul_or_videoconsul=${hospitalcounsul_or_videoconsul}`);

      const responsePatientDetails = await query;

      var data1_modified = { patientDetails: responsePatientDetails };

      const query2 = knexPatient(PATIENT_RECORD.NAME)
        .where(PATIENT_RECORD.COLUMNS.PATIENT_ID, patient_id)
        .orderBy(PATIENT_RECORD.COLUMNS.FILE_FLAG, "asc");

      const responseEhrDetails = await query2;

      const fileFlagMapping = {
        1: "EHRS",
        2: "PRESCRPTION",
        3: "INVESTIGATION",
        4: "DIAGNOSIS",
        5: "LABREPORTS",
        6: "SCANREPORTS"
      };

      const groupedRecords = {
        EHRS: [],
        PRESCRPTION: [],
        INVESTIGATION: [],
        DIAGNOSIS: [],
        LABREPORTS: [],
        SCANREPORTS: []
      };

      responseEhrDetails.forEach(record => {
        const { file_flag } = record;
        const fileFlagKey = fileFlagMapping[file_flag];
        if (fileFlagKey && groupedRecords[fileFlagKey]) {
          const {
            active,
            created_at,
            updated_at,
            created_by,
            updated_by,
            ...filteredRecord
          } = record;
          groupedRecords[fileFlagKey].push(filteredRecord);
        }
      });

      for (const key in groupedRecords) {
        if (groupedRecords.hasOwnProperty(key)) {
          if (data1_modified.hasOwnProperty(key)) {
            data1_modified[key] = data1_modified[key].concat(
              groupedRecords[key]
            );
          } else {
            data1_modified[key] = groupedRecords[key];
          }
        }
      }

      return data1_modified;
    }
  }

  return {
    patientalldetailswithehr
  };
}

function getCancelAppointmentwithReasonRepo(fastify) {
  async function getNumberInfo({ patient_id, logTrace }) {
    const knexPatient = fastify.knexPatient;
    const query = knexPatient.raw(
      `select mobile from patient_registration where id = ${patient_id}`
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Patirnt Number details",
      logTrace
    });
    const response = await query;
    return response[0].mobile;
  }
  async function getCancelAppointmentwithReasonGetOne({ logTrace, body }) {
    const knexPatient = this;
    const doctor_id = body.doctor_id;
    const patient_id = body.patient_id;
    const appointment_date = body.appointment_date;
    const appointment_from_time = body.appointment_from_time;
    const query = knexPatient.raw(`select
    booking.reason,booking.hospitalcounsul_or_videoconsul,
booking.appointment_date,booking.appointment_from_time,booking.patient_id,booking.updated_at
    from patient_booking  as booking
         where booking.doctor_id=${doctor_id} and booking.patient_id=${patient_id} and
         booking.appointment_date='${appointment_date}'
        and booking.appointment_from_time='${appointment_from_time}' and booking.appointment_status = 4`);
    const responseCancelAppointmentReason = await query;
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Cancel Appointment Reason",
      logTrace
    });
    if (!responseCancelAppointmentReason.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Cancel Appointment Reason not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return responseCancelAppointmentReason;
  }
  return {
    getCancelAppointmentwithReasonGetOne,
    getNumberInfo
  };
}

function getpatientwithfilterOverallComplete(fastify) {
  async function patientfilterwithdatefilterOverallComplete({ logTrace, body }) {
    const knexPatient = fastify.knexPatient;
    const knex = this;
    var doctor_id = body.doctor_id;
    var appointment_date = body.appointment_date;
      const query =
        knexPatient.raw(`select b.name,a.patient_id,b.mobile,a.hospitalcounsul_or_videoconsul,
        b.profile_image
      from patient_booking as a
      left join patient_registration as b on b.id=a.patient_id
      where a.doctor_id=${doctor_id} and   a.appointment_status=3 and convert(DATE, a.appointment_date) = '${appointment_date}' order by convert(TIME, a.appointment_from_time) asc`);
      var responsePatientDetails = await query;
      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patients details",
        logTrace
      });
      if (!responsePatientDetails.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patients info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }
      return responsePatientDetails;
  }
  return {
    patientfilterwithdatefilterOverallComplete
  };
}
module.exports = {
  getpatientwithfilter,
  getPatientDetailsRepositoryPostImg,
  getPatientDetailsPost,
  getreschedulepostDetailsPost,
  getreschedulepostfinal,
  getcancelpostfinal,
  getPatientDetailsWithEhrPost,
  getCancelAppointmentwithReasonRepo,
  getreschedulepostv2DetailsPost,
  getpatientwithfilterOverallComplete
};
