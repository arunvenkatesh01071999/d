const LanguageInfo = require('../models/DoctorLanguageInfoModel');
const LanguageMasterModel = require('../../MastersApp/models/LanguagesModel');
const DoctorInfo = require('../models/DoctorBasicInfoModel');


const Get = async () => {
    await LanguageInfo.findAll({ include: [LanguageMasterModel] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (doctor_name_id) => {
    await LanguageInfo.findAll({
        where: { doctor_name_id: doctor_name_id },
        include: [LanguageMasterModel]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await LanguageInfo.findAll({ where: { doctor_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLanguageInfo = async (s_data) => {
    await LanguageInfo.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLanguageInfo = async (id, s_data) => {
    await LanguageInfo.update(s_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLanguageInfo = async (id) => {
    await LanguageInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLanguageInfodata = async (doctor_name_id) => {
    await LanguageInfo.destroy({ where: { doctor_name_id: doctor_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateLanguageInfo,
    UpdateLanguageInfo,
    DestroyLanguageInfo,
    DestroyLanguageInfodata
};