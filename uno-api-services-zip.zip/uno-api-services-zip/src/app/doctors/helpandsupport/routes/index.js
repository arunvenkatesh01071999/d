const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/question",
    preHandler: fastify.authenticate,
    handler: handlers.gethelpBasicInfo.getHelpInfoHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/company",
    preHandler: fastify.authenticate,
    handler: handlers.gethelpBasicInfo.getCompanyInfoHandler(fastify)
  });


  fastify.route({
    method: "POST",
    url: "/question",
    preHandler: fastify.authenticate,
    // schema: schemas.gethelpBasicInfo.createhelpBasicInfo,
    handler: handlers.gethelpBasicInfo.getHelpInfopostHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/company",
    preHandler: fastify.authenticate,
    schema: schemas.gethelpBasicInfo.createCompanyBasicInfo,
    handler: handlers.gethelpBasicInfo.getCompanyInfopostHandler(fastify)
  });


  fastify.route({
    method: "PUT",
    url: "/question/:id",
    preHandler: fastify.authenticate,
    schema: schemas.gethelpBasicInfo.updatehelpSchema,
    handler: handlers.gethelpBasicInfo.getHelpInfoputHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/company/:id",
    preHandler: fastify.authenticate,
    schema: schemas.gethelpBasicInfo.updatecompanySchema,
    handler: handlers.gethelpBasicInfo.getCompanyInfoputHandler(fastify)
  });

};
