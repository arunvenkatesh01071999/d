const express = require('express');
const router = express();
const AccredationController = require('../controller/AccredationController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, AccredationController.FetchAccredation);
router.get('/:id', verify_token, AccredationController.FetchAccredation);
router.post('/', verify_token, AccredationController.NewAccredation);
router.put('/:id', verify_token, AccredationController.UpdateAccredation);
router.delete('/:id', verify_token, AccredationController.DeleteAccredation);

module.exports = router;