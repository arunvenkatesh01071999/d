const { errorSchemas } = require("../../../../../app/commons/schemas/errorSchemas");


const createLabInvestigationReportSchema = {
  tags: ["POST Lab_Investigation_Report"],
  summary: "This API is to Post Lab_Investigation_Report ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "lab_test_category_name",
      "lab_link",
      "scan_test_name",
      "scan_center_link",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {

      lab_test_category_name: {
        type: "array",
        items:{
        type: "string" }
      },
      lab_link: {
        type: "array",
        items:{
        type: "string" }
        
        },
        scan_test_name: { 
        type: "array",
        items:{
        type: "string" }
      },
      scan_center_link: { 
        
        type: "array",
        items:{
        type: "string" }
      },

      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateLabInvestigationReportSchema = {
  tags: ["PUT Lab_Investigation_Report"],
  summary: "This API is to Update Lab_Investigation_Report ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      patient_id: { type: 'integer' },
    },
    required: ['patient_id'],
  },
  body: {
    type: "object",
    required: [
      "doctor_id",
        "patient_id",
      "lab_test_category_name",
      "lab_link",
      "scan_test_name",
      "scan_center_link",
      "active"
    ],
    additionalProperties: false,
    properties: {
      lab_test_category_name: {
        type: "array",
        items:{
        type: "string" }
      },
      lab_link: {
        type: "array",
        items:{
        type: "string" }
        
        },
        scan_test_name: { 
        type: "array",
        items:{
        type: "string" }
      },
      scan_center_link: {
        
        type: "array",
        items:{
        type: "string" }
      },
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getLabInvestigationReportSchema = {

  tags: ["GET Lab_Investigation_Report"],
  summary: "This API is to get Lab_Investigation_Report ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          lab_test_category_name: { type: "string" },
          lab_link: { type: "string" },
          scan_test_name: { type: "string" },
          scan_center_link: { type: "string" },
          doctor_id: { type: "integer" },
          patient_id: { type: "integer" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const deleteLabInvestigationReportSchema = {
  tags: ["DELETE Lab_Investigation_Report"],
  summary: "This API is to delete Lab_Investigation_Report ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createLabInvestigationReportSchema,
  updateLabInvestigationReportSchema,
  getLabInvestigationReportSchema,
  deleteLabInvestigationReportSchema
};
