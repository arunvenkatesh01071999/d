const getHospitalHandler = require("./getHospitalHandler");
const getHospitalInfoHandler = require("./getHospitalInfoHandler");
const getHospitalFilterHandler = require("./getHospitalFilterHandler");
const assignHospitalUserHandler = require("./assignHospitalUserHandler");
const getHospitalInfoByUserHandler = require("./getHospitalInfoByUserHandler");

module.exports = {
  getHospitalHandler,
  getHospitalInfoHandler,
  getHospitalFilterHandler,
  assignHospitalUserHandler,
  getHospitalInfoByUserHandler
};
