const ejs = require("ejs");
const path = require("path");
const pdf = require("html-pdf");
const PDFDocument = require("pdfkit");
// const jsPDF = require('jspdf');
// const fs = require('fs');
const { Readable } = require("stream");
const fs = require("fs").promises;
// const puppeteer = require('puppeteer');
const Stream = require("stream");
const { Storage } = require("@google-cloud/storage");
const { logQuery } = require("../../../../commons/helpers");
// const phantomjs = require("phantomjs");

const getTransformInfo = ({
  cheifInfo,
  pastHistory,
  clinicalexam,
  prescriptionList,
  examinatoryList,
  finalDiagnosisList,
  labInvestigationList,
  otherTreatmentList,
  provisionalDiagnosisList,
  surgicalTreatmentList
}) => {
  const generatePDF = async ({ details }) => {
    // Read the EJS template file
    const template = await fs.readFile("views/template.ejs", "utf8");

    // Render the template with details
    const html = ejs.render(template, { details });

    // Browser actions & buffer creator
    const browser = await puppeteer.launch({
      args: ["--no-sandbox", "--headless", "--disable-gpu"],
      headless: "new"
    });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: "networkidle0" });

    // Generate PDF
    const pdfBuffer = await page.pdf({
      format: "A4",
      printBackground: true
    });

    // Close the browser
    await browser.close();

    return pdfBuffer;
  };

  const uploadToCloudStorage = async (pdfBuffer, fileName) => {
    const storage = new Storage();
    const bucketName = process.env.GCP_BUCKET_NAME;
    const mediaPath = `images/${fileName}`;

    const bucket = storage.bucket(bucketName);
    const file = bucket.file(mediaPath);
    const writeStream = file.createWriteStream({
      metadata: {
        contentType: "application/pdf"
      }
    });

    return new Promise((resolve, reject) => {
      writeStream.on("error", err => {
        console.error("Error uploading PDF:", err);
        reject(err);
      });

      writeStream.on("finish", () => {
        console.log("PDF uploaded successfully");
        resolve(mediaPath);
      });

      const stream = new Readable();
      stream.push(pdfBuffer);
      stream.push(null);

      stream.pipe(writeStream);
    });
  };

  const main = async () => {
    const details = {
      cheifInfo: cheifInfo,
      pastHistory: pastHistory,
      clinicalExam: clinicalexam,
      prescription: prescriptionList,
      examinatory: examinatoryList,
      finalDiagnosis: finalDiagnosisList,
      labInvestigation: labInvestigationList,
      otherTreatment: otherTreatmentList,
      provisionalDiagnosis: provisionalDiagnosisList,
      surgicalTreatment: surgicalTreatmentList
    };

    const pdfBuffer = await generatePDF({ details });

    if (pdfBuffer) {
      const fileName = `output_${Date.now()}.pdf`;
      try {
        const mediaPath = await uploadToCloudStorage(pdfBuffer, fileName);
        const cloudStorageBaseUrl =
          process.env.GCS_URL + "/" + process.env.GCP_BUCKET_NAME;
        const fullUrl = `${cloudStorageBaseUrl}/${mediaPath}`;
        console.log("File uploaded successfully:", fullUrl);
        return {
          message: "File uploaded successfully",
          pdf_url: fullUrl
        };
      } catch (error) {
        console.error("Upload failed:", error);
        return {
          message: "Upload failed"
        };
      }
    }
  };

  main();

  // var error_details = [];
  // var path_location_pdf = [];

  // const storage = new Storage();
  // const bucketName = process.env.GCP_BUCKET_NAME;
  // const fileName = `output_${Date.now()}.pdf`;
  // const media_path = 'images/' + fileName;
  // path_location_pdf.push(media_path);

  // (
  //   async () => {
  //   const browser = await puppeteer.launch();
  //   const page = await browser.newPage();

  //   const details = {
  //     cheifInfo: cheifInfo,
  //     pastHistory: pastHistory,
  //     clinicalExam: clinicalexam,
  //     prescription: prescriptionList,
  //     examinatory: examinatoryList,
  //     finalDiagnosis: finalDiagnosisList,
  //     labInvestigation: labInvestigationList,
  //     otherTreatment: otherTreatmentList,
  //     provisionalDiagnosis: provisionalDiagnosisList,
  //     surgicalTreatment: surgicalTreatmentList
  //   };

  //   const templatePath = 'views/template.ejs'; // Update with your actual path
  //   const html = await renderEjs(templatePath, { details });

  //   const options = {
  //     format: "A4",
  //   };

  //   const pdfBuffer = await page.pdf({
  //     format: 'A4',
  //     printBackground: true,
  //     preferCSSPageSize: true,
  //     margin: { top: 0, right: 0, bottom: 0, left: 0 },
  //   });

  //   // Upload the PDF file to Google Cloud Storage
  //   const storage = new Storage();
  //   const bucketName = process.env.GCP_BUCKET_NAME;
  //   const bucket = storage.bucket(bucketName);
  //   const file = bucket.file(media_path);
  //   const writeStream = file.createWriteStream({
  //     metadata: {
  //       contentType: 'application/pdf',
  //     },
  //   });

  //   writeStream.on('error', (err) => {
  //     console.error('Error uploading PDF:', err);
  //     error_details.push(err);
  //   });

  //   writeStream.on('finish', () => {
  //     console.log('PDF uploaded successfully');
  //     if (error_details.length === 0) {
  //       const cloudStorageBaseUrl = process.env.GCS_URL + '/' + process.env.GCP_BUCKET_NAME;
  //       const fullUrl = `${cloudStorageBaseUrl}/${media_path}`;
  //       console.log({
  //         'message': 'File uploaded successfully',
  //         'image_url': fullUrl
  //       });
  //     } else {
  //       console.error('Upload Failed');
  //     }
  //     browser.close();
  //   });

  //   writeStream.end(pdfBuffer);
  // })();

  // async function renderEjs(templatePath, data) {
  //   const ejs = require('ejs');
  //   return new Promise((resolve, reject) => {
  //     ejs.renderFile(templatePath, data, (err, html) => {
  //       if (err) {
  //         reject(err);
  //       } else {
  //         resolve(html);
  //       }
  //     });
  //   });
  // }

  //     var error_detailes=[];
  //     var path_location_pdf=[];

  //     const storage = new Storage();
  //     const bucketName = process.env.GCP_BUCKET_NAME;
  //     const fileName = `output_${Date.now()}.pdf`;
  //     const media_path = 'images/' + fileName;
  //     path_location_pdf.push(media_path)

  //     const bucket = storage.bucket(bucketName);
  //     const file = bucket.file(media_path);

  //     const writeStream = file.createWriteStream({
  //       metadata: {
  //         contentType: 'application/pdf', //
  //       },
  //     });
  //     const details= {
  //         cheifInfo: cheifInfo,
  //         pastHistory: pastHistory,
  //         clinicalExam: clinicalexam,
  //         prescription: prescriptionList,
  //         examinatory: examinatoryList,
  //         finalDiagnosis: finalDiagnosisList,
  //         labInvestigation: labInvestigationList,
  //         otherTreatment: otherTreatmentList,
  //         provisionalDiagnosis: provisionalDiagnosisList,
  //         surgicalTreatment: surgicalTreatmentList

  //     }
  //     console.log('details',details);

  // ejs.renderFile('views/template.ejs',{details} , function (err, html) {
  //   if (err) {
  //     throw err;
  //   }

  //   var options = {
  //     format: "A4",
  //     // format: "Letter",
  //     phantomPath: phantomjs.path,
  //     timeout: 60000,
  //   }

  //   console.log('PhantomJS Path:', phantomjs.path);
  //   pdf.create(html, options).toStream(async(err, stream) => {
  //     if (err) {
  //       console.error(err);
  //       return;
  //     }

  //     writeStream.on('error', async(err) => {
  //         error_detailes.push(err);
  //       console.error('Error uploading PDF:', err);
  //       return {
  //         'message': 'Upload Failed',
  //     };
  //     });

  //     writeStream.on('finish', async() => {
  //       console.log('PDF uploaded successfully');
  //     });

  //     stream.pipe(writeStream);

  //   });

  // });
  // if(error_detailes.length===0){
  //   const data=path_location_pdf[0];
  //   const cloudStorageBaseUrl = process.env.GCS_URL+'/'+process.env.GCP_BUCKET_NAME;
  //   const fullUrl = `${cloudStorageBaseUrl}/${data}`;
  //   return {
  //       'message': 'File uploaded successfully',
  //       'image_url':fullUrl
  //   };

  // }
  // else{
  //   return {
  //       'message': 'Upload Failed',
  //   };
  // }
};

module.exports = { getTransformInfo };
