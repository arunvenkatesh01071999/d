const getFollowUpDetailInfo = require('./getFollowUpInfo')

module.exports = {
    getFollowUpDetailInfo
}