const express = require('express');
const app = express();

const HospitalBasicInfoRouter = require('./routes/hospital_basic_info');
const ContactInfoRouter = require('./routes/contact_info');
const SpecialityInfoRouter = require('./routes/speciality_info');
const InfraStructureRouter = require('./routes/infrastructure_info');
const AddressInfoRouter = require('./routes/address_info');
const ScanInfoRouter = require('./routes/scan_info');
const LabInfoRouter = require('./routes/lab_info');
const InsuranceInfoRouter = require('./routes/insurance_info');
const DepartmentInfoRouter = require('./routes/department_info');
const OfficeUseRouter = require('./routes/office_use');
const ServiceRouter = require('./routes/service_info');
const TermConditionRouter = require('./routes/term_condition');
const RoomInfoRouter = require('./routes/room_info');
const repositoryBasicInfoRouter = require('./routes/repository_basic_info');
const PaymentRouter = require('./routes/payment_info');

app.use('/hospital-basic-info', HospitalBasicInfoRouter);
app.use('/contact-info', ContactInfoRouter);
app.use('/speciality-info', SpecialityInfoRouter)
app.use('/infrastructure-info', InfraStructureRouter);
app.use('/address-info', AddressInfoRouter);
app.use('/scan-info', ScanInfoRouter);
app.use('/lab-info', LabInfoRouter);
app.use('/insurance-info', InsuranceInfoRouter);
app.use('/department-info', DepartmentInfoRouter);
app.use('/office-use', OfficeUseRouter);
app.use('/service-info', ServiceRouter);
app.use('/terms-condition', TermConditionRouter);
app.use('/room-info', RoomInfoRouter);
app.use('/h-payment', PaymentRouter);
app.use('/repository-basic-info', repositoryBasicInfoRouter);

module.exports = app;