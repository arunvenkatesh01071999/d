const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const LabType = require('../../MastersApp/models/LabTypeMasterModel');
const SectorType = require('../../MastersApp/models/LabSectorModel');
const Accredation = require('../../MastersApp/models/AccredationModel');
const LabImage = require('../models/LabImageInfoModel');


const LabBasicInfo = sequelize.define("l_lab_basic_infos", {
    lab_name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    lab_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    sector_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    accredation_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    lab_regNo: {
        type: DataTypes.STRING,
        allowNull: true
    },
    about: {
        type: DataTypes.STRING,
        allowNull: false
    },
    certicate_path: {
        type: DataTypes.STRING,
        allowNull: false
    },
    lab_image: {
        type: DataTypes.STRING,
        allowNull: true,
        // defaultValue: '',
    },
    isApproved: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default: 0
    },
    approve_date: {
        type: DataTypes.DATE,
        allowNull: true,
        default :null
    },
    approved_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    addCheck: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    reason: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    lab_or_scan: {
        type: DataTypes.INTEGER,
        allowNull: false,
        default: 0
    },
}, { freezeTableName: true });

LabBasicInfo.belongsTo(LabType, { foreignKey: 'lab_type_id' });
LabBasicInfo.belongsTo(SectorType, { foreignKey: 'sector_id' });
LabBasicInfo.belongsTo(Accredation, { foreignKey: 'accredation_id' });
LabBasicInfo.hasMany(LabImage, { foreignKey: 'lab_name_id', as: 'Image' });

LabBasicInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_lab_basic_infos',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabBasicInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_lab_basic_infos',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = LabBasicInfo;