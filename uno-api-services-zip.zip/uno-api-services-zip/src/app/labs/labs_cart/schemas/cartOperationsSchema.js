const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const cartOperationsSchema = {
  tags: ["CART"],
  summary:
    "This API is used to do cart operations. 'add' for adding, 'substract' for updating and 'zero' for removing",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "patient_id",
      "lab_id",
      "lab_test_id",
      "lab_package_id",
      "is_test_or_package",
      "mode"
    ],
    additionalProperties: false,
    properties: {
      patient_id: { type: "integer" },
      lab_id: { type: "integer" },
      lab_test_id: { type: "integer" },
      lab_package_id: { type: "integer" },
      is_test_or_package: { type: "integer" },
      mode: { type: "string", enum: ["add", "subtract", "zero"] }
    }
  },

  response: {
    200: {
      type: "object",
      properties: {
        tests_cart_items_total: { type: "number" },
        tests_cart_total_savings: { type: "number" },
        pack_cart_items_total: { type: "number" },
        packages_cart_total_savings: { type: "number" },
        cart_total: { type: "number" },
        cart_total_savings: { type: "number" },
        no_of_tests: { type: "number" },
        no_of_packages: { type: "number" },
        tests_cart_lines: {
          type: "array",
          items: {
            type: "object",
            properties: {
              patient_id: { type: "integer" },
              lab_id: { type: "integer" },
              lab_test_id: { type: "integer" },
              test_name: { type: "string" },
              cost: { type: "number" },
              discount: { type: "number" },
              tests_cart_items_total: { type: "number" },
              test_cart_items_total_savings: { type: "number" },
              is_test_or_package: { type: "boolean" },
              pretest_prepare: { type: "string" }
            }
          }
        },

        tests_packages_cart_lines: {
          type: "array",
          items: {
            type: "object",
            properties: {
              patient_id: { type: "integer" },
              lab_id: { type: "integer" },
              lab_package_id: { type: "integer" },
              lab_pack_name: { type: "string" },
              pack_cart_items_total: { type: "number" },
              pack_cart_items_total_savings: { type: "number" },
              cost: { type: "number" },
              offer_percent: { type: "number" },
              is_test_or_package: { type: "boolean" },
              lab_test_id: { type: "string" },
              lab_tests: {
                type: "array",
                items: { type: "string" } // Update lab_tests to be an array of strings
              }
            }
          }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = cartOperationsSchema;
