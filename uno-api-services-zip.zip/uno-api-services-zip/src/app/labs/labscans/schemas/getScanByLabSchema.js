const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getScanByLabSchema = {
  tags: ["LAB TESTS BY LAB ID"],
  summary: "This API is to get lab scans by lab",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      lab_id: { type: "integer" },
      lab_or_scan: { type: "integer" },
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              lab_id: { type: "integer" },
              scaninfo_id: { type: "integer" },
              lab_scan_id: { type: "integer" },
              cost: { type: "number" },
              discount: { type: "number" },
              sales_cost: { type: "number" },
              scan_name_id: { type: "integer" },
              lab_name: { type: "string" },
              lab_or_scan: { type: "boolean" },
              scan_test_name: { type: "string" },
              active: { type: "boolean" }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getScanByLabSchema;
