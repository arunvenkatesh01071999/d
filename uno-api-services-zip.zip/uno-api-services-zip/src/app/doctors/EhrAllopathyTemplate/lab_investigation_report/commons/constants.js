const LABINVESTIGATION = {
  NAME: "e_lab_investigation_report",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    LAB_TEST_CATEGORY_NAME: "lab_test_category_name",
    LAB_LINK: "lab_link",
    SCAN_TEST_NAME:"scan_test_name",
    SCAN_CENTER_LINK :"scan_center_link",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  LABINVESTIGATION
};
