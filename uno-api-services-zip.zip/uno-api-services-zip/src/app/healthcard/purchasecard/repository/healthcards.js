const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { CARD_MASTERS } = require("../commons/constants");
const { PATIENT_INFO } = require("../commons/constants");
const { PATIENT_RECORD } = require("../commons/constants");
const { HEALTH_CARDS } = require("../commons/constants");
function healthCardRepo(fastify) {
  async function purchaseHealthCard({
    logTrace,
    input: {
      patient_id,
      card_type_id,
      validityFrom,
      validityTo,
      card_value,
      validityMonths,
      consult_offer,
      lab_offer,
      scan_offer,
      card_number,
      pin,
      razor_payment_id
    }
  }) {
    const knex = this;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.CARD_TYPE, card_type_id)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id);

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Already you have Health Card. Please upgrade or down grade",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    const query_insert = await knex(`${HEALTH_CARDS.NAME}`).insert({
      [HEALTH_CARDS.COLUMNS.PATIENT_ID]: patient_id,
      [HEALTH_CARDS.COLUMNS.VALID_FROM]: validityFrom,
      [HEALTH_CARDS.COLUMNS.VALID_TO]: validityTo,
      [HEALTH_CARDS.COLUMNS.CARD_TYPE]: card_type_id,
      [HEALTH_CARDS.COLUMNS.CARD_NUMBER]: card_number,
      [HEALTH_CARDS.COLUMNS.CARD_PIN]: pin,
      [HEALTH_CARDS.COLUMNS.CARD_VALUE]: card_value,
      [HEALTH_CARDS.COLUMNS.VALIDITY_MONTHS]: validityMonths,
      [HEALTH_CARDS.COLUMNS.CONSULT_OFFER]: consult_offer,
      [HEALTH_CARDS.COLUMNS.LAB_OFFER]: lab_offer,
      [HEALTH_CARDS.COLUMNS.SCAN_OFFER]: scan_offer,
      [HEALTH_CARDS.COLUMNS.RAZOR_PAYMENT_ID]: razor_payment_id,
      [HEALTH_CARDS.COLUMNS.ACTIVE]: 1
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Card type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }
    const query2 = await knex(`${PATIENT_INFO.NAME}`)
      .where(`${PATIENT_INFO.COLUMNS.ID}`, patient_id)
      .update({
        [PATIENT_INFO.COLUMNS.CARD_BALANCE]: card_value
      });
    return { success: true };
  }
  async function getCardMasterInfo({ body, params, logTrace }) {
    const knex = this;
    const query = knex(CARD_MASTERS.NAME).where(
      CARD_MASTERS.COLUMNS.ID,
      params.card_type_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Card Masters info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  async function checkHealthCard({ logTrace, input: { patient_id } }) {
    const knex = this;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id)
      .where(HEALTH_CARDS.COLUMNS.ACTIVE, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      return [];
    } else {
      return response;
    }
  }
  async function checkDeactiveHealthCard({ logTrace, input: { patient_id } }) {
    const knex = this;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id)
      .where(HEALTH_CARDS.COLUMNS.ACTIVE, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      return [];
    } else {
      const query2 = await knex(`${HEALTH_CARDS.NAME}`)
        .where(`${HEALTH_CARDS.COLUMNS.PATIENT_ID}`, patient_id)
        .update({
          [HEALTH_CARDS.COLUMNS.ACTIVE]: 0
        });
    }
  }
  async function updateHealthCard({
    logTrace,
    input: {
      patient_id,
      card_type_id,
      validityFrom,
      validityTo,
      card_value,
      validityMonths,
      consult_offer,
      lab_offer,
      scan_offer,
      card_number,
      pin,
      razor_payment_id
    }
  }) {
    const knex = this;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.CARD_TYPE, card_type_id)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id)
      .where(HEALTH_CARDS.COLUMNS.ACTIVE, 1);

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Already you have Health Card. Please upgrade or down grade",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    const query_insert = await knex(`${HEALTH_CARDS.NAME}`).insert({
      [HEALTH_CARDS.COLUMNS.PATIENT_ID]: patient_id,
      [HEALTH_CARDS.COLUMNS.VALID_FROM]: validityFrom,
      [HEALTH_CARDS.COLUMNS.VALID_TO]: validityTo,
      [HEALTH_CARDS.COLUMNS.CARD_TYPE]: card_type_id,
      [HEALTH_CARDS.COLUMNS.CARD_NUMBER]: card_number,
      [HEALTH_CARDS.COLUMNS.CARD_PIN]: pin,
      [HEALTH_CARDS.COLUMNS.CARD_VALUE]: card_value,
      [HEALTH_CARDS.COLUMNS.VALIDITY_MONTHS]: validityMonths,
      [HEALTH_CARDS.COLUMNS.CONSULT_OFFER]: consult_offer,
      [HEALTH_CARDS.COLUMNS.LAB_OFFER]: lab_offer,
      [HEALTH_CARDS.COLUMNS.SCAN_OFFER]: scan_offer,
      [HEALTH_CARDS.COLUMNS.RAZOR_PAYMENT_ID]: razor_payment_id,
      [HEALTH_CARDS.COLUMNS.ACTIVE]: 1
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Card type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    const checkBalance = await knex(`${PATIENT_INFO.NAME}`).where(
      `${PATIENT_INFO.COLUMNS.ID}`,
      patient_id
    ); // Assuming it returns a single result
    if (checkBalance.length > 0) {
      const currentBalance = checkBalance[0].card_balance;
      const updateBalance = card_value + currentBalance;
      const query2 = await knex(`${PATIENT_INFO.NAME}`)
        .where(`${PATIENT_INFO.COLUMNS.ID}`, patient_id)
        .update({
          [PATIENT_INFO.COLUMNS.CARD_BALANCE]: updateBalance
        });
    } else {
      // Handle case where the patient ID doesn't exist or other error scenarios
      return { success: false, message: "Patient not found or other error" };
    }

    return { success: true };
  }
  async function checkSameHealthCard({
    logTrace,
    input: { patient_id, card_type_id }
  }) {
    const knex = this;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id)
      .where(HEALTH_CARDS.COLUMNS.ACTIVE, 1)
      .where(HEALTH_CARDS.COLUMNS.CARD_TYPE, card_type_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      return [];
    } else {
      return response;
    }
  }
  async function getHealthCard({ body, params, logTrace }) {
    const knex = this;
    // const query = knex(HEALTH_CARDS.NAME)
    //   .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, params.patient_id)
    //   .where(HEALTH_CARDS.COLUMNS.ACTIVE, 1);
    const query = knex(HEALTH_CARDS.NAME)
      .select([
        `${HEALTH_CARDS.NAME}.*`,
        `${CARD_MASTERS.NAME}.${CARD_MASTERS.COLUMNS.CARD_TYPE} as card_type_name`
      ])
      .leftJoin(
        `${CARD_MASTERS.NAME} as ${CARD_MASTERS.NAME}`,
        `${HEALTH_CARDS.NAME}.${HEALTH_CARDS.COLUMNS.CARD_TYPE}`,
        `${CARD_MASTERS.NAME}.${CARD_MASTERS.COLUMNS.ID}`
      )
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, params.patient_id)
      .where(`${HEALTH_CARDS.NAME}.${HEALTH_CARDS.COLUMNS.ACTIVE}`, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Card Masters info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  async function getOldCardDetails({
    logTrace,
    input: { patient_id, card_id }
  }) {
    const knex = this;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.ID, card_id)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Old Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Old Card Masters Info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  async function deactiveOldCard({ logTrace, input: { patient_id, card_id } }) {
    const knex = this;

    const query2 = await knex(`${HEALTH_CARDS.NAME}`)
      .where(`${HEALTH_CARDS.COLUMNS.ID}`, card_id)
      .where(`${HEALTH_CARDS.COLUMNS.PATIENT_ID}`, patient_id)
      .update({
        [HEALTH_CARDS.COLUMNS.ACTIVE]: 0
      });

    return true;
  }
  async function renewalHealthCard({
    logTrace,
    input: {
      patient_id,
      card_type_id,
      validityFrom,
      validityTo,
      card_value,
      validityMonths,
      consult_offer,
      lab_offer,
      scan_offer,
      card_number,
      pin,
      razor_payment_id
    }
  }) {
    const knex = this;

    const query_insert = await knex(`${HEALTH_CARDS.NAME}`).insert({
      [HEALTH_CARDS.COLUMNS.PATIENT_ID]: patient_id,
      [HEALTH_CARDS.COLUMNS.VALID_FROM]: validityFrom,
      [HEALTH_CARDS.COLUMNS.VALID_TO]: validityTo,
      [HEALTH_CARDS.COLUMNS.CARD_TYPE]: card_type_id,
      [HEALTH_CARDS.COLUMNS.CARD_NUMBER]: card_number,
      [HEALTH_CARDS.COLUMNS.CARD_PIN]: pin,
      [HEALTH_CARDS.COLUMNS.CARD_VALUE]: card_value,
      [HEALTH_CARDS.COLUMNS.VALIDITY_MONTHS]: validityMonths,
      [HEALTH_CARDS.COLUMNS.CONSULT_OFFER]: consult_offer,
      [HEALTH_CARDS.COLUMNS.LAB_OFFER]: lab_offer,
      [HEALTH_CARDS.COLUMNS.SCAN_OFFER]: scan_offer,
      [HEALTH_CARDS.COLUMNS.RAZOR_PAYMENT_ID]: razor_payment_id,
      [HEALTH_CARDS.COLUMNS.ACTIVE]: 1
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Card type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  return {
    purchaseHealthCard,
    getCardMasterInfo,
    checkHealthCard,
    checkDeactiveHealthCard,
    updateHealthCard,
    checkSameHealthCard,
    getHealthCard,
    getOldCardDetails,
    deactiveOldCard,
    renewalHealthCard
  };
}

module.exports = healthCardRepo;
