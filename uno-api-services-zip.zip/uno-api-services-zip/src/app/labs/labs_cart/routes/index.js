const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "POST",
    url: "/lab/cart",
    schema: schemas.cartOperationsSchema,
    handler: handlers.cartOperationsHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/lab/cart/:patient_id/:lab_id",
    schema: schemas.getCartSchema,
    handler: handlers.getCartHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/lab/cart/clear/:patient_id/:lab_id",
    schema: schemas.clearCartSchema,
    handler: handlers.clearCartHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/lab/placeorder",
    schema: schemas.placeOrderSchema,
    handler: handlers.placeOrderHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/lab/order/:page_size/:current_page/:patient_id",
    schema: schemas.getOrderSchema,
    handler: handlers.getOrderHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/lab/admin/order/:lab_id/:page_size/:current_page/:patient_id?",
    schema: schemas.getAdminOrderSchema,
    handler: handlers.getAdminOrderHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/lab/orders/status/count/:lab_id/:patient_id?",
    schema: schemas.orderStatusCountSchema,
    handler: handlers.orderStatusCountHandler(fastify)
  });
  fastify.route({
    method: "PUT",
    url: "/lab/orders/status",
    schema: schemas.orderStatusChangeSchema,
    handler: handlers.orderStatusChangeHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/lab/upload/report",
    schema: schemas.uploadLabReportSchema,
    handler: handlers.uploadLabReportHandler(fastify)
  });
  
  fastify.route({
    method: "POST",
    url: "/pastmedical/upload",
    schema: schemas.uploadLabReportSchema,
    handler: handlers.uploadPastMedicalHandler(fastify)
  });
};
