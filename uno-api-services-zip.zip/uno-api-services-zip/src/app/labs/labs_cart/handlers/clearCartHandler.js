const clearCartService = require("../services/clearCart");

function clearCartHandler(fastify) {
  const clearCart = clearCartService(fastify);

  return async (request, reply) => {
    const { query, logTrace, params } = request;
    const response = await clearCart({ query, logTrace, params });
    return reply.code(200).send(response);
  };
}

module.exports = clearCartHandler;
