const postDoctorReviewSchema = require("./postDoctorReviewSchema");
const getDoctorReviewSchema = require("./getDoctorReviewSchema");
const postDisableDoctorReviewSchema = require("./postDisableDoctorReviewSchema");
const getAdminDoctorReviewSchema = require("./getAdminDoctorReviewSchema");

module.exports = {
  postDoctorReviewSchema,
  getDoctorReviewSchema,
  postDisableDoctorReviewSchema,
  getAdminDoctorReviewSchema
};
