// const sequelize = require('../../config/db1');
// const { Sequelize, DataTypes } = require("sequelize");
// const logger = require('../../config/activity_logger');

// const MenuSetting = sequelize.define("m_menusetting", {
//     submenu_name: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "submenu_menu is required"
//             }
//         }
//     },
//     submenu_url: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "submenu_url is required"
//             }
//         }
//     },
//     submenu_icon: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "submenu_icon is required"
//             }
//         }
//     },
//     active: {
//         type: DataTypes.BOOLEAN,
//         allowNull: true,
//     },
//     menu_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     order_row: {
//         type: DataTypes.INTEGER,
//         allowNull: true,
//     },
//     created_at: {
//         type: DataTypes.DATE,
//         allowNull: true,
//     },
//     updated_at: {
//         type: DataTypes.STRING,
//         allowNull: true,
//     },
//     created_by: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     updated_by: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     }
// }, { freezeTableName: true });


// MenuSetting.addHook('afterUpdate', (data, options) => {
//     resp = JSON.stringify({
//         action: 'create',
//         table_name: 'm_menusetting',
//         record_id: data.id,
//         old_value: JSON.stringify(data._previousDataValues),
//         new_value: JSON.stringify(data)
//     });
//     logger.info(resp)
// });

// MenuSetting.addHook('afterDestroy', (data, options) => {
//     resp = JSON.stringify({
//         action: 'delete',
//         table_name: 'm_menusetting',
//         record_id: data.id,
//         old_value: JSON.stringify(data),
//         new_value: '',
//     });
//     logger.info(resp)
// });


// module.exports = MenuSetting;

const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');

const MenuSetting = sequelize.define("m_menusettings", {
    module_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "module_id is required"
            }
        }
    },
    role_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "role_id is required"
            }
        }
    },
    user_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "user_id is required"
            }
        }
    },
   
    menu_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    value: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    submenu_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },

    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });


MenuSetting.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'm_menusetting',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

MenuSetting.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'm_menusetting',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = MenuSetting;