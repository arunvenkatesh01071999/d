const EhrList = require('../models/EhrAyurvedicListModel');

const Get = async () => {
    await EhrList.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await EhrList.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateEhr = async (e_data) => {
    await EhrList.create(e_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateEhr = async (id, e_data) => {
    await EhrList.update(e_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryEhr = async (id) => {
    await EhrList.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateEhr,
    UpdateEhr,
    DestoryEhr
};