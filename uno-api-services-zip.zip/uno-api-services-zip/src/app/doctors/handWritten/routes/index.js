const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/hand-written",
    schema: schemas.getHandWrittenSchema.createHandWrittenSchema,
    handler: handlers.getHandWrittenHandler.createHandWrittenHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/hand-written/:id",
    schema: schemas.getHandWrittenSchema.updateHandWrittenSchema,
    handler: handlers.getHandWrittenHandler.updateHandWrittenHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/hand-written",
    schema: schemas.getHandWrittenSchema.getHandWrittenSchema,
    handler: handlers.getHandWrittenHandler.getHandWrittenHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/hand-written/:id",
   schema: schemas.getHandWrittenSchema.getHandWrittenSchema,
    handler: handlers.getHandWrittenHandler.getHandWrittenHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/hand-written/:id",
   schema: schemas.getHandWrittenSchema.deleteHandWrittenSchema,
    handler: handlers.getHandWrittenHandler.deleteHandWrittenHandler(fastify)
  });

};
