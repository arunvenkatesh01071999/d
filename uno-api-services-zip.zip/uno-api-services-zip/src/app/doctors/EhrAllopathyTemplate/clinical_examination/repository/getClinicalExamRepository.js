const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { CLINICALEXAM } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postClinicalExamRepositoryBasic(fastify) {
  async function ClinicalExamAdd({ logTrace, body }) {
    const knex = this;
    const query = await knex(`${CLINICALEXAM.NAME}`).insert({
      [CLINICALEXAM.COLUMNS.TEMPERATURE]: body.temperature,
      [CLINICALEXAM.COLUMNS.PULSE]: body.pulse,
      [CLINICALEXAM.COLUMNS.RESPIRATORY_RATE]: body.respiratory_rate,
      [CLINICALEXAM.COLUMNS.SP]: body.sp,
      [CLINICALEXAM.COLUMNS.HEART_RATE]: body.heart_rate,
      [CLINICALEXAM.COLUMNS.BLOOD_SYSTOLIC]: body.blood_systolic,
      [CLINICALEXAM.COLUMNS.BLOOD_DIASTOLIC]: body.blood_diastolic,
      [CLINICALEXAM.COLUMNS.HEIGHT]: body.height,
      [CLINICALEXAM.COLUMNS.WEIGHT]: body.weight,
      [CLINICALEXAM.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [CLINICALEXAM.COLUMNS.PATIENT_ID]: body.patient_id,
      [CLINICALEXAM.COLUMNS.CLINICAL_EXAMINATION]: body.clinical_examination,

      [CLINICALEXAM.COLUMNS.ACTIVE]: body.active,
      [CLINICALEXAM.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    ClinicalExamAdd

  };
}

function updateClinicalExamRepository(fastify) {
  async function ClinicalExamUpdate({ logTrace, body, params }) {
    const knex = this;
    const  patient_id = params.patient_id;
    const doctor_id = body.doctor_id

    const clinicalExaminationGetID = await knex.raw(`select top 1 id from e_clinical_examination where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)
    const id=clinicalExaminationGetID[0].id

    const query = await knex(`${CLINICALEXAM.NAME}`)
      .where(`${CLINICALEXAM.COLUMNS.ID}`, id)
      .update({
        [CLINICALEXAM.COLUMNS.TEMPERATURE]: body.temperature,
        [CLINICALEXAM.COLUMNS.PULSE]: body.pulse,
        [CLINICALEXAM.COLUMNS.RESPIRATORY_RATE]: body.respiratory_rate,
        [CLINICALEXAM.COLUMNS.SP]: body.sp,
        [CLINICALEXAM.COLUMNS.HEART_RATE]: body.heart_rate,
        [CLINICALEXAM.COLUMNS.BLOOD_SYSTOLIC]: body.blood_systolic,
        [CLINICALEXAM.COLUMNS.BLOOD_DIASTOLIC]: body.blood_diastolic,
        [CLINICALEXAM.COLUMNS.HEIGHT]: body.height,
        [CLINICALEXAM.COLUMNS.WEIGHT]: body.weight,
        [CLINICALEXAM.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [CLINICALEXAM.COLUMNS.PATIENT_ID]: body.patient_id,
        [CLINICALEXAM.COLUMNS.ACTIVE]: body.active,
        [CLINICALEXAM.COLUMNS.CLINICAL_EXAMINATION]: body.clinical_examination,
        [CLINICALEXAM.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    ClinicalExamUpdate,
  };
}

function getClinicalExamRepository(fastify) {
  
  async function ClinicalExamGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${CLINICALEXAM.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get ClinicalExam details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "ClinicalExam info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    ClinicalExamGetAlls
  };

}


function getClinicalExamRepositoryId(fastify) {
  
  async function ClinicalExamGetOne({ logTrace, params }) {
    
    const knex = this;
    const patient_id = params.patient_id;
    const doctor_id = params.doctor_id;

    // const query = knex.select('*').from(`${CLINICALEXAM.NAME}`).where(`${CLINICALEXAM.COLUMNS.PATIENT_ID}`, patient_id);
    const query = knex.raw(`select top 1 * from e_clinical_examination  where patient_id =${patient_id}  and doctor_id=${doctor_id} and end_consultation =0 order BY id desc`)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get ClinicalExam details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "ClinicalExam info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    ClinicalExamGetOne
  };

}

function deleteClinicalExamRepositoryId(fastify) {
  async function ClinicalExamDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const  patient_id  = params.patient_id;
    const doctor_id  = params.doctor_id;

    const clinicalExaminationGetID = await knex.raw(`select top 1 id from e_clinical_examination where patient_id = ${patient_id} and doctor_id = ${doctor_id}  and end_consultation =0 order By id desc`)
    const id=clinicalExaminationGetID[0].id

    const query = await knex(`${CLINICALEXAM.NAME}`).where(`${CLINICALEXAM.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    ClinicalExamDelete
  };
}


module.exports = {
  postClinicalExamRepositoryBasic,
  updateClinicalExamRepository,
  getClinicalExamRepository,
  getClinicalExamRepositoryId,
  deleteClinicalExamRepositoryId

};
