const getPrescriptionMedicineRepository = require("../repository/getPrescriptionMedicineRepository");

function ehruniquegetServiceBasic(fastify) {
  const { ehruniqueAdd } = getPrescriptionMedicineRepository.uniquegetServiceRepositoryBasic(fastify);

  return async ({ body, logTrace, convertedData}) => {
    const knex = fastify.knexMaster;
    const promise1 = ehruniqueAdd.call(knex, {
      logTrace,
      body,
      convertedData
    });

    const [ehruniqueAddData] = await Promise.all([promise1]);

    return ehruniqueAddData;
  };
}

function createPrescriptionMedicineServiceBasic(fastify) {
  const { PrescriptionMedicineAdd } = getPrescriptionMedicineRepository.postPrescriptionMedicineRepositoryBasic(fastify);

  return async ({ body, logTrace, convertedData}) => {
    const knex = fastify.knexMaster;
    const promise1 = PrescriptionMedicineAdd.call(knex, {
      logTrace,
      body,
      convertedData
    });

    const [PrescriptionMedicineAddData] = await Promise.all([promise1]);

    return PrescriptionMedicineAddData;
  };
}

function updatePrescriptionMedicineServiceBasic(fastify) {
  const { PrescriptionMedicineUpdate } = getPrescriptionMedicineRepository.updatePrescriptionMedicineRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = PrescriptionMedicineUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedPrescriptionMedicineData] = await Promise.all([promise1]);

    return updatedPrescriptionMedicineData;
  };
}

function getPrescriptionMedicineInfoService(fastify) {
  
  const { PrescriptionMedicineGetAlls } = getPrescriptionMedicineRepository.getPrescriptionMedicineRepository(fastify);
  
  return async ({ logTrace,params }) => {
    const knex = fastify.knexMaster;
    const promise1 = PrescriptionMedicineGetAlls.call(knex, {
      logTrace,
      params
    });
    const [getPrescriptionMedicineAlldata] = await Promise.all([promise1]);
    return getPrescriptionMedicineAlldata;
  }
}

function getPrescriptionMedicineInfoServiceId(fastify) {
  
  const { PrescriptionMedicineGetOne } = getPrescriptionMedicineRepository.getPrescriptionMedicineRepositoryId(fastify);
  
  return async ({ params,logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = PrescriptionMedicineGetOne.call(knex, {
      logTrace,
      params
    });
    const [getPrescriptionMedicineOnedata] = await Promise.all([promise1]);
    return getPrescriptionMedicineOnedata;
  }
}

function deletePrescriptionMedicineServiceId(fastify) {
 
  const { PrescriptionMedicineDelete } = getPrescriptionMedicineRepository.deletePrescriptionMedicineRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = PrescriptionMedicineDelete.call(knex, {
      logTrace,
      params
    });

    const [deletePrescriptionMedicinedata] = await Promise.all([promise1]);

    return deletePrescriptionMedicinedata;
  };
}

function deleteAllPrescriptionMedicineServiceId(fastify) {
 
  const { PrescriptionMedicineDelete } = getPrescriptionMedicineRepository.deleteAllPrescriptionMedicineRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = PrescriptionMedicineDelete.call(knex, {
      logTrace,
      params
    });

    const [deletePrescriptionMedicinedata] = await Promise.all([promise1]);

    return deletePrescriptionMedicinedata;
  };
}

module.exports = {

 createPrescriptionMedicineServiceBasic,
 updatePrescriptionMedicineServiceBasic,
 getPrescriptionMedicineInfoService,
 getPrescriptionMedicineInfoServiceId,
 deletePrescriptionMedicineServiceId,
 deleteAllPrescriptionMedicineServiceId,
 ehruniquegetServiceBasic
};
