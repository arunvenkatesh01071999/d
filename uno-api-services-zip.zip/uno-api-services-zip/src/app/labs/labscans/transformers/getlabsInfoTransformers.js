const getlabsInfoTransformers = ({
  labInfo,
  labAddressInfo,
  labContactInfo,
  labServiceInfo
}) => {
  return {
    id: labInfo.id,
    lab_name: labInfo.lab_name,
    lab_type_id: labInfo.lab_type_id,
    lab_type_name: labInfo.lab_type_name,
    sector_id: labInfo.sector_id,
    lab_sector_name: labInfo.lab_sector_name,
    accredation_id: labInfo.hospital_sector_name,
    accredation_name: labInfo.accredation_name,
    lab_regNo: labInfo.speciality_id,
    about: labInfo.about,
    certicate_path: labInfo.certicate_path,
    addCheck: labInfo.addCheck,
    approve_date: labInfo.approve_date,
    reason: labInfo.reason,
    lab_image: labInfo.lab_image,
    approved_by: labInfo.approved_by,
    isApproved: labInfo.isApproved,
    lab_or_scan: labInfo.lab_or_scan,
    active: labInfo.active,
    created_at: labInfo.created_at,
    updated_at: labInfo.updated_at,
    created_by: labInfo.created_by,
    updated_by: labInfo.updated_by,
    address_lines: labAddressInfo,
    contact_lines: labContactInfo,
    services_lines: labServiceInfo
  };
};

module.exports = { getlabsInfoTransformers };
