const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getSlotBasicInfoSchema = {
  tags: ["GET Slot INFO"],
  summary: "This API is to get Slot basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: 'integer' },
          check_walking: { type: 'integer' },
          doctor_name_id: { type: 'integer' },
          duration: { type: 'string' },
          instant_consulation: { type: 'integer' },
          video: { type: 'integer' },
          walkin: { type: 'integer' },
          day: { type: 'string' },
          slot_active: { type: 'integer' },
          slot_1: { type: 'string' },
          slot_2: { type: 'string' },
          slot_3: { type: 'string' }
        }
      }
    },
    ...errorSchemas
  }
};

// const getSlotpostBasicInfoSchema = {
//   tags: ["POST Slot INFO"],
//   summary: "This API is to Post Slot basic info ",
//   headers: { $ref: "request-headers#" },
//   body: {
//     type: "object",
//     required: [
//     "check_walking",
//     "doctor_name_id",
//     "duration",
//     "instant_consulation",
//     "video",
//     "walkin"
//     ]
//     // additionalProperties: false,
//     // properties: {
//     //   name: { type: "string" },
//     //   email: { type: "string" },
//     //   gender_id: { type: "integer" },
//     //   dob: { type: "string" },
//     //   blood_group_id: { type: "string" },
//     //   profile_image: { type: "string" },
//     //   completion_percentage: { type: "integer" },
//     //   martial_status_id: { type: "integer" },
//     //   logitute: { type: "string" },
//     //   latitdue: { type: "string" },
//     //   active: { type: "integer" },
//     //   created_by: { type: "integer" }

//     // }
//   },
//   response: {
//     200: {
//       type: "object",
//       properties: {
//         success: { type: "boolean" },
//         message: { type: "string" }
//       }
//     },
//     ...errorSchemas
//   }
// };


const daySchema = {
  type: 'object',
  properties: {
    slot_active: { type: 'integer' },
    slot_1: { type: 'array', items: { type: 'string' } },
    slot_2: { type: 'array', items: { type: 'string' } },
    slot_3: { type: 'array', items: { type: 'string' } }
  }
};



const getSlotpostBasicInfoSchema = {
  tags: ["POST Slot INFO"],
  summary: "This API is to Post Slot basic info ",
  headers: { $ref: "request-headers#" },
  body: {
      type: 'object',
      properties: {
        check_walking: { type: 'integer' },
        duration: { type: 'string' },
        doctor_name_id: { type: 'integer' },
        instant_consulation: { type: 'integer' },
        video: { type: 'integer' },
        walkin: { type: 'integer' },
        created_by: { type: 'integer' },
        day: {
          type: 'object',
          properties: {
            Monday: daySchema,
            Tuesday: daySchema,
            Wednesday: daySchema,
            Thursday: daySchema,
            Friday: daySchema,
            Saturday: daySchema,
            Sunday: daySchema
          }
        }
      },
      required: [
        'check_walking',
        'duration',
        'doctor_name_id',
        'instant_consulation',
        'video',
        'walkin',
        'created_by',
        'day'
      ]
  },
  
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
  
};




const getSlotputBasicInfoSchema = {
  tags: ["PUT Slot INFO"],
  summary: "This API is to Put Slot basic info ",
  headers: { $ref: "request-headers#" },
  body: {
    type: 'object',
    properties: {
      check_walking: { type: 'integer' },
      duration: { type: 'string' },
      doctor_name_id: { type: 'integer' },
      instant_consulation: { type: 'integer' },
      video: { type: 'integer' },
      walkin: { type: 'integer' },
      created_by: { type: 'integer' },
      day: {
        type: 'object',
        properties: {
          Monday: daySchema,
          Tuesday: daySchema,
          Wednesday: daySchema,
          Thursday: daySchema,
          Friday: daySchema,
          Saturday: daySchema,
          Sunday: daySchema
        }
      }
    },
    required: [
      'check_walking',
      'duration',
      'doctor_name_id',
      'instant_consulation',
      'video',
      'walkin',
      'created_by',
      'day'
    ]
},

response: {
  200: {
    type: "object",
    properties: {
      success: { type: "boolean" },
      message: { type: "string" }
    }
  },
  ...errorSchemas
}
};

const getSlotdeleteBasicInfoSchema = {
  tags: ["DELETE Slot INFO"],
  summary: "This API is to delete Slot basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {
  getSlotBasicInfoSchema,
  getSlotpostBasicInfoSchema,
  getSlotputBasicInfoSchema,
  getSlotdeleteBasicInfoSchema
};
