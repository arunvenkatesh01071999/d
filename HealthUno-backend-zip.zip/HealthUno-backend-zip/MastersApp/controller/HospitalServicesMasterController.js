const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const hospital_services_master_service = require('../services/hospital_services_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();


const FetchHospitalServices = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospital_services_master_service.GetbyRelationsId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_hospital_services_master'); 
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await hospital_services_master_service.GetbyRelations()
            .then(data => {
                cache.SET(req.user.id + '_hospital_services_master', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        // }
    }
}

//         logo_image
// image_path = req.files ? req.files.image_path : null;
const NewHospitalService = async (req, res, next) => {
    console.log(req.files,"qwghj")
    try {
        const service_name = req.body.service_name;
        const logo_image = req.files ? req.files.logo_image : null;
        const active = req.body.active;
        const created_by = req.user.id;
        const updated_by = req.user.id;

        if (!service_name) {
            throw new Error("service_name is required");
        }

        const hs_data = {
            service_name: service_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };

        if (logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = logo_image.name;
            const buffer = logo_image.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Upload the image to GCS
            await file.save(buffer);

            hs_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
        } else {
            hs_data.logo_image = null; // Set logo_image to null if not provided
        }

        console.log(hs_data, "service_name");

        // Check if insurance name already exists
        const s_data = await hospital_services_master_service.GetbyName(service_name);
        if (s_data.length > 0) {
            const msg = "Services Name already exists";
            return res.status(200).json(failure_func(msg));
        }

        // Insert portion
        const data = await hospital_services_master_service.CreateHospitalService(hs_data);

        if (data.errors) {
            const msg = data.errors[0].message;
            res.status(400).json(failure_func(msg));
        } else {
            const msg = "Created Successfully";
            cache.DEL(req.user.id + '_hospital_services_master_service');
            res.status(200).json(success_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};

const UpdateHospitalService = async (req, res, next) => {
    try {
        const id = req.params.id;

        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }

        const service_name = req.body.service_name;
        let logo_image_data;

        if (req.body.logo_image && req.body.logo_image !== 'undefined') {
            logo_image_data = req.body.logo_image;
        } else {
            const logo_image = req.files.logo_image;

            if (logo_image) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = logo_image.name;
                const buffer = logo_image.data;
                const path = `images/${fileName}`;

                const file = storage.bucket(bucketName).file(path);

                // Upload the image to GCS
                await file.save(buffer);

                logo_image_data = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
        }

        const active = req.body.active;
        const updated_by = req.user.id;
        const updated_at = date();

        if (!service_name) {
            const msg = "service_name and active are required";
            return res.status(400).json(failure_func(msg));
        }

        const i_data = {
            service_name: service_name,
            logo_image: logo_image_data,
            active: active,
            updated_by: updated_by,
            updated_at: updated_at
        };

        const data = await hospital_services_master_service.UpdateHospitalService(id, i_data);

        if (data === 1) {
            const msg = "Updated successfully";
            cache.DEL(req.user.id + '_hospital_services_master_service');
            res.status(200).json(success_func(msg));
        } else {
            const msg = "ID doesn't exist";
            res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};

const DeleteHospitalService = async (req, res, next) => {
    try {
        const id = req.params.id;

        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }

        // Fetch insurance data by ID
        const serviceData = await hospital_services_master_service.GetbyId(id);

        if (!serviceData) {
            const msg = "ID doesn't exist";
            return res.status(400).json(failure_func(msg));
        }

        // Delete the image from GCS
        if (serviceData.logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = serviceData.logo_image.split('/').pop(); // Extract file name from URL
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Delete the image from GCS
            await file.delete();
        }

        // Delete insurance entry
        const deletedRows = await hospital_services_master_service.DestroyHospitalService(id);

        if (deletedRows === 1) {
            const msg = "Deleted successfully";
            cache.DEL(req.user.id + '_hospital_services_master_service');
            res.status(200).json(success_func(msg));
        } else {
            const msg = "Failed to delete. ID may not exist";
            res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};

module.exports = {
    NewHospitalService,
    FetchHospitalServices,
    UpdateHospitalService,
    DeleteHospitalService
}