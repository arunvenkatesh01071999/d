const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "POST",
    url: "/doctor/review",
    schema: schemas.postDoctorReviewSchema,
    handler: handlers.postDoctorReviewHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/doctor/review/:doctor_id",
    schema: schemas.getDoctorReviewSchema,
    handler: handlers.getDoctorReviewHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/doctor/admin/review/:doctor_id",
    schema: schemas.getAdminDoctorReviewSchema,
    handler: handlers.getAdminDoctorReviewHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/doctor/review/disable",
    schema: schemas.postDisableDoctorReviewSchema,
    handler: handlers.postDisableDoctorReviewHandler(fastify)
  });
};
