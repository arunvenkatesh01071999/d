const express = require('express');
const router = express();
const LabScanTestController = require('../../LabApp/controller/LabScanPackController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabScanTestController.FetchScanTestInfo);
router.get('/:lab_name_id', verify_token, LabScanTestController.FetchScanTestInfo);
router.post('/', verify_token, LabScanTestController.NewScanTestInfo);
router.put('/:lab_name_id', verify_token, LabScanTestController.UpdateScanTestInfo);
router.delete('/:id/:lab_name_id', verify_token, LabScanTestController.DeleteScanTestInfo);


module.exports = router; 