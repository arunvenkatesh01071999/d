const otpGenerator = require('otp-generator')

const generate_otp = () => {
    OTP = otpGenerator.generate(6, { lowerCaseAlphabets: false, upperCaseAlphabets: false, specialChars: false });
    return OTP;
}

module.exports = generate_otp;