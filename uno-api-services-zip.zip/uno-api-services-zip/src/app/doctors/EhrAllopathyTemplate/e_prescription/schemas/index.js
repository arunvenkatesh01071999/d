const getPrescriptionSchema = require("./getPrescription");

module.exports = {
  getPrescriptionSchema
};
