const express = require('express');
const router = express();
const ConsultationSlotsController = require('../controller/ConsultationSlotsController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ConsultationSlotsController.FetchConsultationSlotsDurations);
router.get('/:id', verify_token, ConsultationSlotsController.FetchConsultationSlotsDurations);
router.post('/', verify_token, ConsultationSlotsController.NewConsultationSlotsDuration);
router.put('/:id', verify_token, ConsultationSlotsController.UpdateConsultationSlotsDuration);
router.delete('/:id', verify_token, ConsultationSlotsController.DeleteConsultationSlotsDuration);

module.exports = router;