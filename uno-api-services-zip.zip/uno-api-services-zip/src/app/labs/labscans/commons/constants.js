const LAB_TEST = {
  NAME: "lab_test",
  COLUMNS: {
    ID: "id",
    TEST_NAME: "test_name",
    ALTER_NAME: "alter_name",
    LONG_DESCRIPTION: "long_descrip",
    SHORT_DESCRIPTION: "short_descrip",
    RECOMMEND: "recommend",
    SAMPLE_COLLECTED: "sample_collected",
    PRETEST_PREPARE: "pretest_prepare",
    CATEGORY_ID: "category_id",
    IACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_BASIC_INFO = {
  NAME: "l_lab_basic_infos",
  COLUMNS: {
    ID: "id",
    LAB_NAME: "lab_name",
    LAB_TYPE_ID: "lab_type_id",
    SECTOR_ID: "sector_id",
    ACCREDATION_ID: "accredation_id",
    LAB_REGNO: "lab_regNo",
    ABOUT: "about",
    CERTIFICATE_PATH: "certicate_path",
    ADDCHECK: "addCheck",
    APPROVEDATE: "approve_date",
    ISAPPROVED: "isApproved",
    LAB_OR_SCAN: "lab_or_scan",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const ACCREDATION = {
  NAME: "accredation",
  COLUMNS: {
    ID: "id",
    ACCREDATION_NAME: "accredation_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SECTOR = {
  NAME: "lab_sector",
  COLUMNS: {
    ID: "id",
    LAB_SECTOR_NAME: "lab_sector_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_TYPE_MASTER = {
  NAME: "lab_type_master",
  COLUMNS: {
    ID: "id",
    LAB_TYPE_NAME: "lab_type_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_TEST_PACK = {
  NAME: "l_lab_test_pack",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    LAB_PACK_NAME: "lab_pack_name",
    COST: "cost",
    OFFER_PERCENT: "offer_percent",
    VALID_FROM: "vaild_from",
    VALID_TO: "vaild_to",
    APPLY_PROMO: "apply_promo",
    LAB_TEST_ID: "lab_test_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const L_LAB_INFO = {
  NAME: "l_lab_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    COST: "cost",
    DISCOUNT: "discount",
    PACK_NAME: "pack_name",
    LAB_TEST_ID: "lab_test_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const CITIES = {
  NAME: "cities",
  COLUMNS: {
    ID: "id",
    CITYNAME: "city_name",
    STATEID: "state_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const STATES = {
  NAME: "states",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    COUNTRYID: "country_id"
  }
};
const COUNTRIES = {
  NAME: "countries",
  COLUMNS: {
    ID: "id",
    SHORTNAME: "shortname",
    NAME: "name",
    PHONECODE: "phonecode",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const LAB_ADDRESS_INFO = {
  NAME: "l_address_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    ADDRESS1: "address1",
    ADDRESS2: "address2",
    CITY_ID: "city_id",
    STATE_ID: "state_id",
    COUNTRY_ID: "country_id",
    PINCODE: "pincode",
    LOCATION: "location",
    LONGITUDE: "longitude",
    LATITUDE: "latitude",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_CONTACT_INFO = {
  NAME: "l_contact_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    TELEPHONE: "telephone",
    MOBILE_NO: "mobile_no",
    EMERGENY_NO: "emergency_no",
    TOLL_FREE_NO: "toll_free_no",
    HELPLINE_NO: "helpline_no",
    FAX_NO: "fax_no",
    WEBSITE_URL: "webiste_URL",
    EMAIL_ADDRESS_1: "email_address_1",
    EMAIL_ADDRESS_2: "email_address_2",
    ESTABLISHED_IN: "established_in",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SERVICE = {
  NAME: "lab_service",
  COLUMNS: {
    ID: "id",
    SERVICE_NAME: "service_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SERVICE_INFO = {
  NAME: "l_lab_service_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    SERVICE_NAME_ID: "service_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SLOT = {
  NAME: "l_lab_slot ",
  COLUMNS: {
    ID: "id",
    LAB_ID: "lab_id",
    DAYS: "days",
    OPENS_FROM: "opens_from",
    CLOSED_AT: "closed_at",
    INTERVAL: "interval",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const LAB_SCAN_INFO = {
  NAME: "l_lab_scan_info ",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    SCAN_NAME_ID: "scan_name_id",
    COST: "cost",
    DISCOUNT: "discount",
    PACK_NAME: "pack_name",
    SCAN_ID: "scan_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const SCAN_TEST_MASTER = {
  NAME: "scan_test_master ",
  COLUMNS: {
    ID: "id",
    SCAN_TEST_NAME: "scan_test_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const SCAN_TEST_PACK = {
  NAME: "l_scan_test_pack ",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    SCAN_PACK_NAME: "scan_pack_name",
    COST: "cost",
    OFFER_PERCENT: "offer_percent",
    VALID_FROM: "vaild_from",
    VALID_TO: "vaild_to",
    SCAN_NAME_ID: "scan_name_id",
    APPLY_PROMO: "apply_promo",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  LAB_TEST,
  LAB_BASIC_INFO,
  ACCREDATION,
  LAB_SECTOR,
  LAB_TYPE_MASTER,
  LAB_TEST_PACK,
  L_LAB_INFO,
  CITIES,
  STATES,
  COUNTRIES,
  LAB_ADDRESS_INFO,
  LAB_CONTACT_INFO,
  LAB_SERVICE,
  LAB_SERVICE_INFO,
  LAB_SLOT,
  LAB_SCAN_INFO,
  SCAN_TEST_MASTER,
  SCAN_TEST_PACK
};
