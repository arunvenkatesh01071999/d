const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const country_services = require('../services/country_service');
// const cache = require('../../services/redis_cache_service');


const FetchCountry = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await country_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_city_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await country_services.Get()
            .then(data => {
                // cache.SET(req.user.id + '_country_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

module.exports = {
    FetchCountry
}