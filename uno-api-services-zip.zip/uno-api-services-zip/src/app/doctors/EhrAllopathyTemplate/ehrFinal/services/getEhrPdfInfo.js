const getEhrPdfRepo = require('../repository/getPdfInfo');
const { getTransformInfo } = require('../transformer/getPdfInfo')
function getEhrPdfInfoService(fastify) {
  const { cheifComplaint,
    pastMedicalhistory,
    clinicalexamination,
    prescription,
    examinatory,
    finalDiagnosis,
    labInvestigation,
    otherTreatment,
    provisionalDiagnosis,
    surgicalTreatment
  } = getEhrPdfRepo.getEhrPdfInfo(fastify);
  return async ({ logTrace, params }) => {
    const knex = fastify.knexMaster;
    const promise1 = cheifComplaint.call(knex, {
      logTrace, params
    });
    const promise2 = pastMedicalhistory.call(knex, {
      logTrace, params
    });
    const promise3 = clinicalexamination.call(knex, {
      logTrace, params
    });
    const promise4 = prescription.call(knex, {
      logTrace, params
    });
    const promise5 = examinatory.call(knex, {
      logTrace, params
    });
    const promise6 = finalDiagnosis.call(knex, {
      logTrace, params
    });
    const promise7 = labInvestigation.call(knex, {
      logTrace, params
    });
    const promise8 = otherTreatment.call(knex, {
      logTrace, params
    });
    const promise9 = provisionalDiagnosis.call(knex, {
      logTrace, params
    });
    const promise10 = surgicalTreatment.call(knex, {
      logTrace, params
    });
    const
      [cheifInfo,
        pastHistory,
        clinicalexam,
        prescriptionList,
        examinatoryList,
        finalDiagnosisList,
        labInvestigationList,
        otherTreatmentList
        , provisionalDiagnosisList,
        surgicalTreatmentList
      ]
        =
        await Promise.all([promise1,
          promise2,
          promise3,
          promise4,
          promise5,
          promise6,
          promise7,
          promise8,
          promise9,
          promise10
        ]);
    //  return dataAll
    return getTransformInfo({
      cheifInfo,
      pastHistory,
      clinicalexam,
      prescriptionList,
      examinatoryList,
      finalDiagnosisList,
      labInvestigationList,
      otherTreatmentList,
      provisionalDiagnosisList,
      surgicalTreatmentList
    })
  }
}
module.exports = {
  getEhrPdfInfoService
}