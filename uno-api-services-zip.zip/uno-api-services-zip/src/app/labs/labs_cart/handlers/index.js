const cartOperationsHandler = require("./cartOperationsHandler");
const getCartHandler = require("./getCartHandler");
const clearCartHandler = require("./clearCartHandler");
const placeOrderHandler = require("./placeOrderHandler");
const getOrderHandler = require("./getOrderHandler");
const orderStatusChangeHandler = require("./orderStatusChangeHandler");
const orderStatusCountHandler = require("./orderStatusCountHandler");
const getAdminOrderHandler = require("./getAdminOrderHandler");
const uploadLabReportHandler = require("./uploadLabReportHandler");
const uploadPastMedicalHandler = require("./uploadPastMedicalHandler");

module.exports = {
  cartOperationsHandler,
  getCartHandler,
  clearCartHandler,
  placeOrderHandler,
  getOrderHandler,
  orderStatusChangeHandler,
  orderStatusCountHandler,
  getAdminOrderHandler,
  uploadLabReportHandler,
  uploadPastMedicalHandler
};
