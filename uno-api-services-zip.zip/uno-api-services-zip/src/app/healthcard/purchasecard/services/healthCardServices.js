const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const healthCardRepo = require("../repository/healthcards");
function getCardMasterInfoService(fastify) {
  const { getCardMasterInfo } = healthCardRepo(fastify);

  return async ({ params, body, logTrace, card_type_id }) => {
    const knex = fastify.knexPatient;
    const response = await getCardMasterInfo.call(knex, {
      params: {
        card_type_id: card_type_id
      },
      body,
      logTrace
    });
    return response;
  };
}
function generateCardNumber() {
  let cardNumber = "";

  // Generate 15 random digits for the card number
  for (let i = 0; i < 15; i++) {
    cardNumber += Math.floor(Math.random() * 10);
  }

  // Applying Luhn algorithm to generate the last digit (checksum)
  const digits = cardNumber.split("").map(Number);
  let sum = 0;
  let shouldDouble = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  const checkDigit = (sum * 9) % 10;
  cardNumber += checkDigit;

  return cardNumber;
}
function generateValidityDates(validityMonths) {
  const today = new Date();
  const validityFrom = today.toISOString(); // Set validity_from to the current date

  const validityTo = new Date(
    today.setMonth(today.getMonth() + validityMonths)
  ).toISOString();

  return { validityFrom, validityTo };
}

function generatePIN() {
  return Math.floor(1000 + Math.random() * 9000); // Generates a 4-digit PIN
}

function purchaseHealthCardService(fastify) {
  const { purchaseHealthCard, checkHealthCard } = healthCardRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const card_type_id = body.card_type_id;
    const patient_id = body.patient_id;
    const razor_payment_id = body.razor_payment_id;

    const check_exsisting = await checkHealthCard.call(knex, {
      logTrace,
      input: {
        patient_id
      }
    });

    if (check_exsisting.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Already you have Health Card. Please upgrade or down grade",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const getCard = getCardMasterInfoService(fastify);
    const cardItems = await getCard({
      logTrace,
      card_type_id
    });

    const card_value = cardItems.card_value;
    const validityMonths = cardItems.validity_months;
    const consult_offer = cardItems.consult_offer;
    const lab_offer = cardItems.lab_offer;
    const scan_offer = cardItems.scan_offer;

    const card_number = generateCardNumber();
    const { validityFrom, validityTo } = generateValidityDates(validityMonths);
    const pin = generatePIN();

    const response = await purchaseHealthCard.call(knex, {
      logTrace,
      input: {
        patient_id,
        card_type_id,
        validityFrom,
        validityTo,
        card_value,
        validityMonths,
        consult_offer,
        lab_offer,
        scan_offer,
        card_number,
        pin,
        razor_payment_id
      }
    });
    return response;
  };
}

function upgradHealthCardService(fastify) {
  const { updateHealthCard, checkDeactiveHealthCard, checkSameHealthCard } =
    healthCardRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const card_type_id = body.card_type_id;
    const patient_id = body.patient_id;
    const razor_payment_id = body.razor_payment_id;

    const check_same_card_exsisting = await checkSameHealthCard.call(knex, {
      logTrace,
      input: {
        patient_id,
        card_type_id
      }
    });

    if (check_same_card_exsisting.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message:
          "Same Health Card already exsists. Please upgrade or down grade",
        property: "",
        code: "NOT_FOUND"
      });
    }

    const check_exsisting = await checkDeactiveHealthCard.call(knex, {
      logTrace,
      input: {
        patient_id
      }
    });

    const getCard = getCardMasterInfoService(fastify);
    const cardItems = await getCard({
      logTrace,
      card_type_id
    });

    const card_value = cardItems.card_value;
    const validityMonths = cardItems.validity_months;
    const consult_offer = cardItems.consult_offer;
    const lab_offer = cardItems.lab_offer;
    const scan_offer = cardItems.scan_offer;

    const card_number = generateCardNumber();
    const { validityFrom, validityTo } = generateValidityDates(validityMonths);
    const pin = generatePIN();

    const response = await updateHealthCard.call(knex, {
      logTrace,
      input: {
        patient_id,
        card_type_id,
        validityFrom,
        validityTo,
        card_value,
        validityMonths,
        consult_offer,
        lab_offer,
        scan_offer,
        card_number,
        pin,
        razor_payment_id
      }
    });
    return response;
  };
}
function getHealthCardService(fastify) {
  const { getHealthCard } = healthCardRepo(fastify);

  return async ({ params, body, logTrace, card_type_id }) => {
    const knex = fastify.knexPatient;
    const response = await getHealthCard.call(knex, {
      params,
      body,
      logTrace
    });
    const transformedResponse = isValidCard(response);
    return transformedResponse;
  };
}

function isValidCard(cardData) {
  const currentDate = new Date();
  const validFrom = new Date(cardData.valid_from);
  const validTo = new Date(cardData.valid_to);

  const isDateValid = currentDate >= validFrom && currentDate <= validTo;

  let isValidMessage = "";
  if (isDateValid) {
    isValidMessage = "Card is valid.";
  } else {
    isValidMessage = "Card is not valid.";
  }

  return {
    ...cardData,
    is_valid: isDateValid,
    is_valid_message: isValidMessage
  };
}
function renewelHealthCardService(fastify) {
  const { renewalHealthCard, getOldCardDetails, deactiveOldCard } =
    healthCardRepo(fastify);
  return async ({ params, body, logTrace }) => {
    const knex = fastify.knexPatient;
    const card_type_id = body.card_type_id;
    const patient_id = body.patient_id;
    const razor_payment_id = body.razor_payment_id;
    const card_id = body.card_id;

    const oldCardResponse = await getOldCardDetails.call(knex, {
      logTrace,
      input: {
        patient_id,
        card_id
      }
    });
    const deactiveOldCardRsponse = await deactiveOldCard.call(knex, {
      logTrace,
      input: {
        patient_id,
        card_id
      }
    });

    const getCard = getCardMasterInfoService(fastify);
    const cardItems = await getCard({
      logTrace,
      card_type_id
    });

    const card_value = cardItems.card_value;
    const validityMonths = cardItems.validity_months;
    const consult_offer = cardItems.consult_offer;
    const lab_offer = cardItems.lab_offer;
    const scan_offer = cardItems.scan_offer;

    const card_number = oldCardResponse.card_number;
    const { validityFrom, validityTo } = generateValidityDates(validityMonths);
    const pin = oldCardResponse.card_pin;

    const response = await renewalHealthCard.call(knex, {
      logTrace,
      input: {
        patient_id,
        card_type_id,
        validityFrom,
        validityTo,
        card_value,
        validityMonths,
        consult_offer,
        lab_offer,
        scan_offer,
        card_number,
        pin,
        razor_payment_id
      }
    });
    return response;
  };
}
module.exports = {
  purchaseHealthCardService,
  getCardMasterInfoService,
  upgradHealthCardService,
  getHealthCardService,
  renewelHealthCardService
};
