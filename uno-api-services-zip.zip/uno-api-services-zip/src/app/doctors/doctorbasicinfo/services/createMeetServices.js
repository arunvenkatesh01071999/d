const { CustomError } = require("../../../errorHandler");
const { StatusCodes } = require("http-status-codes");
const meet = require("../../../videomeet/repository/generatemeet");
function createMeetServices(fastify) {
  return async ({ params, body, logTrace }) => {
    const { createMeet } = meet(fastify);

    const meet_name = body.meet_name;
    const meet_id = body.meet_id; //appointment id
    const hostuser = body.hostuser; // docter name or huno name
    const starts_at = body.starts_at;
    const ends_at = body.ends_at;
    const participant_id = body.participant_id;

    const starts_at_unix = new Date(starts_at).getTime(); // Get timestamp in milliseconds
    const ends_at_unix = new Date(ends_at).getTime(); // Get timestamp in milliseconds

    const hostuid = Buffer.from(hostuser).toString("base64");
    const participantuid = Buffer.from(participant_id).toString("base64");
    const displayName = Buffer.from(process.env.VIDEO_SESSION_NAME).toString(
      "base64"
    );

    const result = await createMeet(
      meet_name,
      meet_id,
      hostuser,
      starts_at_unix,
      ends_at_unix
    );

    const doctor_url =
      "https://healthuno.invc.vc/" +
      result.sessionId +
      "?displayName=" +
      displayName +
      "&projectId=" +
      process.env.VIDEO_PROJECT_ID +
      "&uid=" +
      hostuid;
    const patient_url =
      "https://healthuno.invc.vc/" +
      result.sessionId +
      "?projectId=" +
      process.env.VIDEO_PROJECT_ID +
      "&uid=" +
      participantuid;

    return {
      doctor_url: doctor_url,
      patient_url: patient_url
    };
  };
}
module.exports = createMeetServices;
