const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getHealthPackageByLabSchema = {
  tags: ["LAB TESTS PACKAGES BY LABS"],
  summary: "This API is to get lab tests packages by labs",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      lab_id: { type: "integer" },
      lab_or_scan: { type: "integer" },
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              lab_scan_package_id: { type: "integer" },
              lab_name_id: { type: "integer" },
              scan_name_id: { type: "string" },
              scan_pack_name: { type: "string" },
              cost: { type: "number" },
              offer_percent: { type: "number" },
              sales_cost: { type: "number" },
              vaild_from: { type: "string", format: "date-time" },
              vaild_to: { type: "string", format: "date-time" },
              apply_promo: { type: "string" },
              lab_tests: { type: "string" },
              lab_name: { type: "string" },
              lab_or_scan: { type: "boolean" },
              is_lab_or_scan: { type: "string" },
              lab_id: { type: "integer" },
              active: { type: "boolean" },
              scan_tests: {
                type: "array",
                items: { type: "string" } // Update lab_tests to be an array of strings
              }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getHealthPackageByLabSchema;
