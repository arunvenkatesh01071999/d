## Hospital Search

Case 1: By symptoms Ex. chest pain, head ache

Case 2: By Illness (Disease) Ex. Dengu , Malria

Case 3: By Specality

Case 4: By Hospital Name

## Logic:

1. List all hospital based on search case, and order by Location ASC (shortest should show first)

## API :

1. GET HOSPITAL INFO API

## Masters to be added.

1. Hospital IDs to be added in Doctor Registartion
2. Menu Register Hospital Doctors.
