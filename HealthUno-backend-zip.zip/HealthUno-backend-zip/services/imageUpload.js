// const storage = new Storage();
// const bucket = storage.bucket(process.env.GCP_BUCKET_NAME);

// const storageOptions = {
//   destination: (req, file, callback) => {
//     const filename = Date.now() + '-' + file.originalname;
//     callback(null, filename);
//   },
// };

const imageUpload = async (res, req) => {
    const file = req.file;

    console.log('Received file:', file.originalname);
  
    const media_path = 'images/' + file.originalname;
    const fileBuffer = file.buffer;
  
    const bucket = storage.bucket(process.env.GCP_BUCKET_NAME);
    const fileOptions = {
      metadata: {
        contentType: file.mimetype,
      },
    };
  
    const fileUploadPromise = bucket.file(media_path).save(fileBuffer, fileOptions);
  
    try {
      await fileUploadPromise;
      const cloudStorageBaseUrl = process.env.GCS_URL+'/'+process.env.GCP_BUCKET_NAME;
      const fullUrl = `${cloudStorageBaseUrl}/${media_path}`;
      return {
          'message': 'File uploaded successfully',
          'image_url':fullUrl
      };
    } catch (err) {
      console.error('Error uploading file:', err);
      res.status(500).json({
        message: 'File upload failed',
        error: err.message,
      });
    }
}

module.exports = {
    imageUpload
}   