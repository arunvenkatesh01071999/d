const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const labInchargeInfo_services = require('../services/lab_incharge_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const AddCheck = require('../../services/lab_addCheck_service');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchLabInchargeInfo = async (req, res, next) => {
    id = req.params.lab_name_id;
    if (id) {
        await labInchargeInfo_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_labInchargeInfo_services');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await labInchargeInfo_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_labInchargeInfo_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
};


const NewLabInchargeInfo = async (req, res, next) => {

    doctor_name = req.body.doctor_name;
    lab_name_id = req.body.lab_name_id;
    gender_id = req.body.gender_id;
    email = req.body.email;
    phone_no = req.body.phone_no;
    about = req.body.about;
    dob = req.body.dob;
    age = req.body.age;
    speciality_id = req.body.speciality_id;
    doctor_type_id = req.body.doctor_type_id;
    active = 1;
    created_by = req.user.id;
    updated_by = req.user.id;
    var addCheck = 8;
    const query = await AddCheck(lab_name_id);
    image_path = req.files ? req.files.image_path : null;
    signature_path = req.body ? req.body.signature_path : null;

    if (doctor_name) {
        d_data = {
            lab_name_id: parseInt(lab_name_id),
            doctor_name: doctor_name,
            gender_id: parseInt(gender_id),
            email: email,
            phone_no: phone_no,
            dob: dob,
            signature_path: signature_path,
            image_path: image_path,
            about: about,
            addCheck: addCheck,
            age: parseInt(age),
            speciality_id: parseInt(speciality_id),
            active: parseInt(active),
            created_by: created_by,
            updated_by: updated_by
        }

        if (signature_path != null) {
            signature_path = req.body.signature_path;
            d_data.signature_path = signature_path;
        }
        else {
            d_data.signature_path = null;
        }

        if (image_path != null) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = image_path.name;
            const buffer = image_path.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            await file.save(buffer);

            d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            d_data.image_path = null;
        }

        await labInchargeInfo_services.CreateLabInChargeInfo(d_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    labInchargeInfo_services.GetbyName(doctor_name)
                        .then(datas => {
                            data.msg = "Created Successfully";
                            // cache.DEL(req.user.id + '_labInchargeInfo_services')
                            res.status(200).json(success_func(data))
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
    else {
        msg = "doctor_name is required";
        res.status(400).json(failure_func(msg))
    }


}

const UpdateLabinChargeInfo = async (req, res, next) => {
    id = req.params.id;

    if (id) {
        doctor_name = req.body.doctor_name;
        gender_id = req.body.gender_id;
        lab_name_id = req.body.lab_name_id;
        email = req.body.email;
        phone_no = req.body.phone_no;
        about = req.body.about;
        image_path = req.files ? req.files.image_path : null;
        signature_path = req.body ? req.body.signature_path : null;
        dob = req.body.dob;
        age = req.body.age;
        about = req.body.about;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();

        if (doctor_name) {
            d_data = {
                doctor_name: doctor_name,
                gender_id: gender_id,
                email: email,
                lab_name_id: lab_name_id,
                phone_no: phone_no,
                about: about,
                dob: dob,
                about: about,
                age: age,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            if (image_path != null) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = image_path.name;
                const buffer = image_path.data;
                const path = `images/${fileName}`;
                const file = storage.bucket(bucketName).file(path);
                await file.save(buffer);
                d_data.image_path = `https://storage.googleapis.com/${bucketName}/${path}`;
            }

            if (signature_path != null) {
                signature_path = req.body.signature_path;
                d_data.signature_path = signature_path;
            }
            else {
                d_data.signature_path = null;
            }

            await labInchargeInfo_services.UpdateLabInchargeInfo(id, d_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        // cache.DEL(req.user.id + '_labInchargeInfo_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        else {
            msg = "doctor_name is required";
            res.status(400).json(failure_func(msg))
        }

    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteLabInChargeInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await labInchargeInfo_services.DestroyLanInChargeInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_labInchargeInfo_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    FetchLabInchargeInfo,
    NewLabInchargeInfo,
    UpdateLabinChargeInfo,
    DeleteLabInChargeInfo
}