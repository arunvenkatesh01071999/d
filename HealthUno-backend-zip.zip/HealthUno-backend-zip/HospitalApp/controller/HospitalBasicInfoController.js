const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const hospitalBasicInfo_services = require('../services/hospital_basic_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const hospital_img_services = require('../services/hospital_basic_img_service');
const db1 = require('../../config/db1');
const { Storage } = require('@google-cloud/storage');
const multer = require('multer');

const storage = new Storage({
  keyFilename: 'uno-api-services-staging.json',
});

const upload = multer({ storage: multer.memoryStorage() });

const FetchHospitalBasicInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await hospitalBasicInfo_services.GetbyId(id)
      .then(data => {
        res.status(200).json(success_func(data))
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    // data = await cache.GET(req.user.id + '_hospitalBasicInfo_services');
    // if (data) {
    //     res.status(200).json(success_func(JSON.parse(data)))
    // } else {
    await hospitalBasicInfo_services.Get()
      .then(data => {
        // console.log('data',data);
        // cache.SET(req.user.id + '_hospitalBasicInfo_services', data)
        res.status(200).json(success_func(data))
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  }
}
// };

const fetchhosnameid = async (req, res, next) => {
  user_id = req.params.user_id;

  await hospitalBasicInfo_services.GetuserId(user_id)
    .then(data => {
      res.status(200).json(success_func(data))
    })
    .catch(err => {
      res.status(400).json(failure_func(err))
    })
};

// const NewHospitalBasicInfo = async (req, res, next) => {
//   // console.log(req.files, "req.files");
//   hospital_name = req.body.hospital_name;
//   hospital_type_id = req.body.hospital_type_id;
//   sector_id = req.body.sector_id;
//   accredation_id = req.body.accredation_id;
//   regNo = req.body.regNo;
//   about = req.body.about;
//   active = req.body.active;
//   created_by = req.user.id;
//   updated_by = req.user.id;
//   isApproved = 0;
//   approve_date = null;
//   addCheck = 8;
//   try {
//     hospital_image = req.files.hospital_image;
//   } catch {
//     hospital_image = null
//   }
//   certicate_path = req.files ? req.files.certicate_path : null;
//   if (hospital_name) {
//     i_data = {
//       hospital_name: hospital_name,
//       hospital_type_id: parseInt(hospital_type_id),
//       sector_id: parseInt(sector_id),
//       accredation_id: parseInt(accredation_id),
//       certicate_path: certicate_path,
//       regNo: regNo,
//       about: about,
//       isApproved: isApproved,
//       approve_date: approve_date,
//       active: parseInt(active),
//       addCheck: addCheck,
//       created_by: created_by,
//       updated_by: updated_by
//     }
//     if (certicate_path) {
//       const bucketName = process.env.GCP_BUCKET_NAME;
//       const fileName = certicate_path.name;
//       const buffer = certicate_path.data;
//       const path = `images/${fileName}`;
//       const file = storage.bucket(bucketName).file(path);
//       // Upload the image to GCS
//       await file.save(buffer);
//       i_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//     }
//     else {
//       // If no image is provided, you may want to handle null or default values
//       i_data.certicate_path = null; // or set a default image URL
//     }

//     await hospitalBasicInfo_services.GetbyName(regNo)
//       .then(basic_data => {
//         if (basic_data.length > 0) {
//           msg = "Invalid Registration Number";
//           return res.status(200).json(failure_func(msg))
//         } else {

//           // console.log('else');
//           hospitalBasicInfo_services.CreateHospitalBasicInfo(i_data)
//             .then(data => {
//               // console.log("asdaf");
//               if (data.errors) {
//                 msg = data.errors[0].message;
//                 res.status(400).json(failure_func(msg))
//               } else {
//                 // console.log('kkkkkk', data);
//                 if (data.dataValues.id) {
//                   if (hospital_image.length) {
//                     const bucketName = process.env.GCP_BUCKET_NAME;

//                     const uploadImagePromises = hospital_image.map(async (element) => {
//                       const fileName = element.name;
//                       const buffer = element.data;

//                       // Upload image to GCS
//                       const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                       await file.save(buffer);

//                       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//                       // Create image data for your database
//                       const i_data_img = {
//                         hospital_name_id: data.dataValues.id,
//                         hospital_image: imageUrl,
//                         active: active,
//                         created_by: created_by,
//                         updated_by: updated_by,
//                       };

//                       // Save image data to your database
//                       await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
//                     });

//                     // Wait for all image uploads and database inserts to complete
//                     Promise.all(uploadImagePromises);
//                   }
//                 }
//                 hospitalBasicInfo_services.GetbyName(regNo)
//                   .then(datas => {
//                     datas.msg = "Created Successfully";
//                     //cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                     res.status(200).json(success_func(datas))
//                   })
//                   .catch(err => {
//                     res.status(400).json(failure_func(err))
//                   })
//               }
//             })
//             .catch(err => {
//               msg = "Failed"
//               res.status(400).json(failure_func(msg))
//             })
//         }
//       })
//   }
//   else {
//     msg = "hospital_name is required";
//     res.status(400).json(failure_func(msg))
//   }
// }

const NewHospitalBasicInfo = async (req, res, next) => {
  const hospital_name = req.body.hospital_name;
  hospital_type_id = req.body.hospital_type_id;
  sector_id = req.body.sector_id;
  accredation_id = req.body.accredation_id;
  regNo = req.body.regNo;
  about = req.body.about;
  active = req.body.active;
  created_by = 2;
  updated_by = 2;
  isApproved = 0;
  approve_date = null;
  addCheck = 8;
  certicate_path = req.files ? req.files.certicate_path : null;
  var hospital_image = req.files ? req.files.hospital_image : null;
  if (hospital_name) {
    i_data = {
      hospital_name: hospital_name,
      hospital_type_id: parseInt(hospital_type_id),
      sector_id: parseInt(sector_id),
      accredation_id: parseInt(accredation_id),
      certicate_path: certicate_path,
      regNo: regNo,
      about: about,
      isApproved: isApproved,
      approve_date: approve_date,
      active: parseInt(active),
      addCheck: addCheck,
      created_by: created_by,
      updated_by: updated_by
    }

    // var currentDate = new Date();

    // const createdAtString = currentDate.toISOString().split('T')[0]  // date only

    var currentDate = new Date();

    var year = currentDate.getFullYear();
    var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
    var day = currentDate.getDate().toString().padStart(2, '0');
    var hours = currentDate.getHours().toString().padStart(2, '0');
    var minutes = currentDate.getMinutes().toString().padStart(2, '0');
    var seconds = currentDate.getSeconds().toString().padStart(2, '0');


    var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

    if (certicate_path) {
      const bucketName = process.env.GCP_BUCKET_NAME;
      const fileName = `${formattedDateTime}_${certicate_path.name}`
      const buffer = certicate_path.data;
      const path = `images/${fileName}`;
      const file = storage.bucket(bucketName).file(path);
      await file.save(buffer);
      i_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
    }
    else {
      i_data.certicate_path = null;
    }
    await hospitalBasicInfo_services.GetbyName(regNo)
      .then(basic_data => {
        if (basic_data.length > 0) {
          msg = "Invalid Registration Number";
          return res.status(200).json(failure_func(msg))
        } else {
          hospitalBasicInfo_services.CreateHospitalBasicInfo(i_data)
            .then(data => {
              if (data.errors) {
                msg = data.errors[0].message;
                res.status(400).json(failure_func(msg))
              }
              else {
                if (data.dataValues.id) {
                  const bucketName = process.env.GCP_BUCKET_NAME;
                  if (hospital_image.name) {
                    const value = [];
                    value.push(hospital_image);
                    const uploadImagePromises = value.map(async (element) => {
                      const fileName = `${formattedDateTime}_${element.name}`

                      const buffer = element.data;
                      const file = storage.bucket(bucketName).file(`images/${fileName}`);
                      await file.save(buffer);
                      const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
                      const i_data_img = {
                        hospital_name_id: data.dataValues.id,
                        hospital_image: imageUrl,
                        active: 1,
                        created_by: created_by,
                        updated_by: updated_by,
                      };
                      await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
                    });
                    Promise.all(uploadImagePromises);
                  }
                  else {
                    console.log("hi,else");
                    const uploadImagePromises = hospital_image.map(async (element) => {
                      // const fileName = element.name;
                      const fileName = `${formattedDateTime}_${element.name}`
                      const buffer = element.data;
                      // Upload image to GCS
                      const file = storage.bucket(bucketName).file(`images/${fileName}`);
                      await file.save(buffer);
                      const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
                      // Create image data for your database
                      const i_data_img = {
                        hospital_name_id: data.dataValues.id,
                        hospital_image: imageUrl,
                        active: 1,
                        created_by: created_by,
                        updated_by: updated_by,
                      };
                      // Save hospital image data to your database
                      await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
                    });
                    // Wait for all image uploads and database inserts to complete
                    Promise.all(uploadImagePromises);
                    // console.log("asddDff");
                  }
                }
                hospitalBasicInfo_services.GetbyName(regNo)
                  .then(datas => {
                    datas.msg = "Created Successfully"
                    res.status(200).json(success_func(datas))
                  })
                  .catch(err => {
                    res.status(400).json(failure_func(err))
                  })
              }
            })
            .catch(err => {
              msg = "Failed"
              res.status(400).json(failure_func(msg))
            })
        }
      })
  }
  else {
    msg = "hospital_name is required";
    res.status(400).json(failure_func(msg))
  }
}



// const UpdateHospitalBasicInfo = async (req, res, next) => {
//   const id = req.params.id;

//   if (!id) {
//     const msg = "ID is required";
//     return res.status(400).json(failure_func(msg));
//   }

//   const hospital_name = req.body.hospital_name;
//   const hospital_type_id = req.body.hospital_type_id;
//   const sector_id = req.body.sector_id;
//   const accredation_id = req.body.accredation_id;
//   const regNo = req.body.regNo;
//   const about = req.body.about;

//   if (!regNo || !hospital_name) {
//     const msg = "hospital_name and regNo are required";
//     return res.status(400).json(failure_func(msg));
//   }

//   let certicate_path;
//   if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//     certicate_path = req.files.certicate_path;
//   } else {
//     certicate_path = req.body.certicate_path;
//   }

//   if (req.files && req.files.hospital_image && req.files.hospital_image.name) {
//     hospital_image = req.files.hospital_image;
//   } else {
//     hospital_image = req.body.hospital_image;
//   }

//   const active = req.body.active;
//   const updated_by = req.user.id;
//   const updated_at = date();

//   const i_data = {
//     hospital_name: hospital_name,
//     hospital_type_id: parseInt(hospital_type_id),
//     sector_id: parseInt(sector_id),
//     accredation_id: parseInt(accredation_id),
//     regNo: regNo,
//     about: about,
//     active: active,
//     updated_by: updated_by,
//     updated_at: updated_at
//   };

// var currentDate = new Date();
// var year = currentDate.getFullYear();
// var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
// var day = currentDate.getDate().toString().padStart(2, '0');
// var hours = currentDate.getHours().toString().padStart(2, '0');
// var minutes = currentDate.getMinutes().toString().padStart(2, '0');
// var seconds = currentDate.getSeconds().toString().padStart(2, '0');

// var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

//   if (typeof certicate_path === "string") {
//     i_data.certicate_path = certicate_path;
//   } else {
//     const bucketName = process.env.GCP_BUCKET_NAME;
//     // const fileName = certicate_path.name;
//     const fileName =`${formattedDateTime}_${certicate_path.name}`

//     const buffer = certicate_path.data;
//     const path = `images/${fileName}`;
//     const file = storage.bucket(bucketName).file(path);
//     await file.save(buffer);
//     i_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//   }
//   await hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data)
//     .then(data => {
//       if (data == 1) {
//         const hosp_id = req.params.id;

//         hospital_img_services.CreateHospitalmgBasicInfo(hosp_id)
//           .then(result => {
//             var image_body = req.body.hospital_image
//             // console.log("qwesdfghjkrty", image_body);
//             if (image_body) {
//               const hospital_image_body = req.body.hospital_image.toString()
//               var req_array = hospital_image_body.split(',');
//               console.log("req_arrayreq_array", req_array);
//               var exist_array = [];
//               if (Array.isArray(result)) {
//                 result.forEach((element) => {
//                   exist_array.push(element.hospital_image);
//                 });
//               }
//               var uncommonElements = [];

//               // Create sets for faster lookup
//               const set1 = new Set(req_array);
//               console.log("req_arrayreq_array", set1);
//               const set2 = new Set(exist_array);
//               console.log("req_arrayreq_array", set2);
//               for (const item of set1) {
//                 if (!set2.has(item)) {
//                   uncommonElements.push(item);
//                 }
//               }
//               // Check for uncommon elements in arr2
//               for (const item of set2) {
//                 if (!set1.has(item)) {
//                   uncommonElements.push(item);
//                 }
//               }
//               // console.log('uncommonElements', uncommonElements);
//               if (Array.isArray(result)) {
//                 if (uncommonElements.length > 0) {
//                   const filteredData = result.filter((item) => uncommonElements.includes(item.hospital_image));
//                   filteredData.forEach((element) => {
//                     hospital_img_services.DestoryHospitalmgBasicInfo({ where: { hospital_image: element.hospital_image } })
//                       .then(data => {
//                         res = data;
//                       })
//                       .catch(err => {
//                         res = err;
//                       });
//                   });
//                 }
//               }

//             }
//             else {
//               // if (req.files) {
//                 var file_image = req.files;
//                 console.log("file_imagefile_image", req.files);
//                 var as = []
//                 as.push(file_image)
//                 console.log("zxcvbnm,", as);
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 // if (Array.isArray(file_image)) {
//                 const uploadImagePromises = as.map(async (element) => {
//                   console.log("elementelement", element);
//                   try {
//                     const imgKey = Object.keys(element)[0];
//                     const imgData = element[imgKey];
//                     // const fileName = imgData.name;
//                     const fileName =`${formattedDateTime}_${imgData.name}`
//                     const buffer = element.data;
//                     const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                     // Use createWriteStream to upload the file
//                     const stream = file.createWriteStream();
//                     // Write the buffer to the stream
//                     stream.end(buffer);
//                     // Wait for the upload to complete
//                     await new Promise((resolve, reject) => {
//                       stream.on('finish', resolve);
//                       stream.on('error', reject);
//                     });

//                     const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//                     const i_data_img = {
//                       hospital_name_id: parseInt(hosp_id),
//                       hospital_image: imageUrl,
//                       active: 1,
//                       created_by: req.user.id,
//                       updated_by: req.user.id,
//                     };

//                     console.log("i_data_imgi_data_img", i_data_img);

//                     await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
//                   } catch (error) {
//                     console.error("Error uploading image:", error);
//                   }
//                 });

//                 // Wait for all promises to complete
//                 Promise.all(uploadImagePromises);
//               // }
//               // else {
//               //   const hospital_image = req.files.hospital_image;
//               //   console.log("file_imagesfile_imagesfile_images", req.files);

//               //   // Ensure that req.files is an array before proceeding
//               //   if (Array.isArray(hospital_image)) {
//               //     const bucketName = process.env.GCP_BUCKET_NAME;

//               //     // Use Promise.all to handle multiple asynchronous uploads
//               //     const uploadImagePromises = hospital_image.map(async (element) => {
//               //       try {
//               //         const imgKey = Object.keys(element)[0];
//               //         const imgData = element[imgKey];
//               //         const fileName = imgData.name;
//               //         const buffer = imgData.data;

//               //         const file = storage.bucket(bucketName).file(`images/${fileName}`);

//               //         // Use createWriteStream to upload the file
//               //         const stream = file.createWriteStream();

//               //         // Write the buffer to the stream
//               //         stream.end(buffer);

//               //         // Wait for the upload to complete
//               //         await new Promise((resolve, reject) => {
//               //           stream.on('finish', resolve);
//               //           stream.on('error', reject);
//               //         });

//               //         const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//               //         const i_data_img = {
//               //           hospital_name_id: parseInt(hosp_id),
//               //           hospital_image: imageUrl,
//               //           active: 1,
//               //           created_by: req.user.id,
//               //           updated_by: req.user.id,
//               //         };

//               //         console.log("i_data_img i_data_img", i_data_img);

//               //         await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
//               //       } catch (error) {
//               //         console.error("Error uploading image:", error);
//               //       }
//               //     });

//               //     // Wait for all promises to complete
//               //     Promise.all(uploadImagePromises);
//               //   } else {
//               //     console.error("req.files is not an array.");
//               //   }
//               // }
//             }

//           })
//         // if (hosp_id) {
//         //   const bucketName = process.env.GCP_BUCKET_NAME;
//         //   if (hospital_image.name) {
//         //     const value = [];
//         //     value.push(hospital_image);
//         //     const uploadImagePromises = value.map(async (element) => {
//         //       const fileName = element.name;
//         //       const buffer = element.data;
//         //       const file = storage.bucket(bucketName).file(`images/${fileName}`);
//         //       await file.save(buffer);
//         //       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
//         //       const i_data_img = {
//         //         hospital_name_id: hosp_id,
//         //         hospital_image: imageUrl,
//         //         active: active,
//         //         created_by: req.user.id,
//         //         updated_by: req.user.id,
//         //       };
//         //       await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
//         //     });
//         //     Promise.all(uploadImagePromises);
//         //   }
//         //   else {
//         //     const uploadImagePromises = hospital_image.map(async (element) => {
//         //       const fileName = element.name;
//         //       const buffer = element.data;
//         //       const file = storage.bucket(bucketName).file(`images/${fileName}`);
//         //       await file.save(buffer);
//         //       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//         //       const i_data_img = {
//         //         hospital_name_id: hosp_id,
//         //         hospital_image: imageUrl,
//         //         active: active,
//         //         created_by: req.user.id,
//         //         updated_by: req.user.id,
//         //       };

//         //       await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
//         //     });

//         //     Promise.all(uploadImagePromises);
//         //   }
//         msg = "Updated successfully"
//         cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//         res.status(200).json(success_func(msg))
//         // }
//       }
//     })

//   //   try {
//   //     const data = await hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data);

//   //     if (data == 1) {
//   //       const hosp_id = req.params.id;
//   //       hospital_img_services.DestoryHospitalmgBasicInfo(hosp_id);

//   //       if (hosp_id) {
//   //         const bucketName = process.env.GCP_BUCKET_NAME;
//   //         const uploadImagePromises = [];

//   //         if (hospital_image.name) {
//   //           uploadImagePromises.push(uploadSingleImage(hospital_image, hosp_id, bucketName));
//   //         } else {
//   //           hospital_image.forEach((element) => {
//   //             uploadImagePromises.push(uploadSingleImage(element, hosp_id, bucketName));
//   //           });
//   //         }

//   //         await Promise.all(uploadImagePromises);

//   //         msg = "Updated successfully";
//   //         cache.DEL(req.user.id + '_hospitalBasicInfo_services');
//   //         res.status(200).json(success_func(msg));
//   //       }
//   //     } 
//   //     else {
//   //       msg = "ID doesn't exist";
//   //       res.status(400).json(failure_func(msg));
//   //     }
//   //   } catch (err) {
//   //     res.status(400).json(failure_func(err.message || "An error occurred"));
//   //   }
//   // };

//   // async function uploadSingleImage(element, hosp_id, bucketName) {
//   //   const fileName = element.name;
//   //   const buffer = element.data;
//   //   const file = storage.bucket(bucketName).file(`images/${fileName}`);
//   //   await file.save(buffer);
//   //   const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//   //   const i_data_img = {
//   //     hospital_name_id: hosp_id,
//   //     hospital_image: imageUrl,
//   //     active: req.body.active,
//   //     created_by: req.user.id,
//   //     updated_by: req.user.id,
//   //   };

//   //   await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
// }

const UpdateHospitalBasicInfo = async (req, res, next) => {
  const id = req.params.id;

  if (!id) {
    const msg = "ID is required";
    return res.status(400).json(failure_func(msg));
  }

  const hospital_name = req.body.hospital_name;
  const hospital_type_id = req.body.hospital_type_id;
  const sector_id = req.body.sector_id;
  const accredation_id = req.body.accredation_id;
  const regNo = req.body.regNo;
  const about = req.body.about;

  if (!regNo || !hospital_name) {
    const msg = "hospital_name and regNo are required";
    return res.status(400).json(failure_func(msg));
  }

  certicate_path = req.files ? req.files.certicate_path : null;

  var hospital_image = req.files ? req.files.hospital_image : null;

  console.log(hospital_image,"hospital_image");

  var hospital_image_string_Array;

  var hospital_image_string = req.body ? req.body.hospital_image : null;

console.log(hospital_image_string,"hospital_image_string");

  if (hospital_image_string != null && !Array.isArray(hospital_image_string)) {
    hospital_image_string_Array = hospital_image_string.split(',')
  }


  const active = req.body.active;
  const updated_by = 1;
  const updated_at = date();

  const i_data = {
    hospital_name: hospital_name,
    hospital_type_id: parseInt(hospital_type_id),
    sector_id: parseInt(sector_id),
    accredation_id: parseInt(accredation_id),
    regNo: regNo,
    about: about,
    active: active,
    updated_by: updated_by,
    updated_at: updated_at
  };

  var currentDate = new Date();
  var year = currentDate.getFullYear();
  var month = (currentDate.getMonth() + 1).toString().padStart(2, '0');
  var day = currentDate.getDate().toString().padStart(2, '0');
  var hours = currentDate.getHours().toString().padStart(2, '0');
  var minutes = currentDate.getMinutes().toString().padStart(2, '0');
  var seconds = currentDate.getSeconds().toString().padStart(2, '0');

  var formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;

  if (certicate_path != null) {
    const bucketName = process.env.GCP_BUCKET_NAME;
    const fileName = `${formattedDateTime}_${certicate_path.name}`
    const buffer = certicate_path.data;
    const path = `images/${fileName}`;
    const file = storage.bucket(bucketName).file(path);
    await file.save(buffer);
    i_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
  }

  await hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data)
    .then(async (data) => {
      if (data == 1) {

        var hosp_id = req.params.id;

        if (hospital_image != null) {

          if (hospital_image.name) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const value = [];
            value.push(hospital_image);
            const uploadImagePromises = value.map(async (element) => {
              const fileName = `${formattedDateTime}_${element.name}`
              const buffer = element.data;
              const file = storage.bucket(bucketName).file(`images/${fileName}`);
              await file.save(buffer);
              const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
              const i_data_img = {
                hospital_name_id: hosp_id,
                hospital_image: imageUrl,
                active: active,
                created_by: 2,
                updated_by: 2,
              };
              await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
            });
            Promise.all(uploadImagePromises);

          }
          else {
            const bucketName = process.env.GCP_BUCKET_NAME;

            const uploadImagePromises = hospital_image.map(async (element) => {
              const fileName = `${formattedDateTime}_${element.name}`
              const buffer = element.data;
              const file = storage.bucket(bucketName).file(`images/${fileName}`);
              await file.save(buffer);
              const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

              const i_data_img = {
                hospital_name_id: hosp_id,
                hospital_image: imageUrl,
                active: active,
                created_by: 2,
                updated_by: 2,
              };
              await hospital_img_services.CreateHospitalmgBasicInfo(i_data_img);
            });
            Promise.all(uploadImagePromises);
          }
        }

        if (hospital_image_string != null) {

          await hospital_img_services.GetbyHospitalImages(hosp_id)

            .then(async (data) => {

              if (hospital_image_string_Array) {

                var thirdArrayIs = data.filter(function (item) {
                  return !hospital_image_string_Array.includes(item.hospital_image);
                }).map(function (item) {
                  return item.hospital_image;
                });

                for (const image of thirdArrayIs) {

                  await hospital_img_services.DestroyHospitalImages(image);
                }
              }

              if (hospital_image_string) {
                var fourthArrayIs = data.filter(function (item) {
                  return !hospital_image_string.includes(item.hospital_image);
                }).map(function (item) {
                  return item.hospital_image;
                });

                for (const image of fourthArrayIs) {

                  await hospital_img_services.DestroyHospitalImages(image);
                }
              }

            })

        }

        if (hospital_image_string == undefined) {

          await hospital_img_services.DestroyHospitalImagesALL(hosp_id)

        }

      }
    })
    .catch(err => {
      console.error("Error updating hospital basic info:", err);
    });
  msg = "Updated successfully"
  res.status(200).json(success_func(msg))

}


const DeleteHospitalBasicInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await hospitalBasicInfo_services.DestroyHospitalBasicInfo(id)
      .then(data => {
        if (data == 1) {
          msg = "Deleted successfully"
          cache.DEL(req.user.id + '_hospitalBasicInfo_services')
          res.status(200).json(success_func(msg))
        } else {
          msg = "ID doesn't exist"
          res.status(200).json(success_func(msg))
        }
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
}

const HospitalApprove = async (req, res, next) => {
  const id = req.params.id
  // console.log(req.body, "idhhjhjk");
  if (id) {
    const { isApproved, approve_date, approved_by, reason, id } = req.body;
    // if (isApproved) {
    if (isApproved === 1) {
      const a_data = {
        id: parseInt(id),
        isApproved: isApproved,
        approve_date: approve_date,
        approved_by: approved_by,
        reason: reason
      }
      // console.log(a_data, "a_datajwueqje");
      hospitalBasicInfo_services.CreateApprove(id, a_data)
        .then(data => {
          if (data.errors) {
            msg = data.errors[0].message;
            res.status(400).json(failure_func(msg))
          } else {
            msg = "Approved Successfully"
            cache.DEL(req.user.id + '_hospitalBasicInfo_services')
            res.status(200).json(success_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
    else {
      const a_data = {
        id: parseInt(id),
        isApproved: isApproved,
        approve_date: approve_date,
        approved_by: approved_by,
        reason: reason
      }
      console.log(a_data, "12223");
      hospitalBasicInfo_services.CreateApprove(id, a_data)
        .then(data => {
          if (data.errors) {
            msg = data.errors[0].message;
            res.status(400).json(failure_func(msg))
          } else {
            msg = "Rejected Successfully"
            cache.DEL(req.user.id + '_hospitalBasicInfo_services')
            res.status(200).json(success_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })

    }
    // }
  }
}

const UpdateforApprove = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await hospitalBasicInfo_services.UpdateIsApprove(id)
      .then(data => {
        res.json('created success')
      }).catch(err => {
        res.json('not created')
      })
  }
}

module.exports = {
  FetchHospitalBasicInfo,
  NewHospitalBasicInfo,
  UpdateHospitalBasicInfo,
  DeleteHospitalBasicInfo,
  HospitalApprove,
  UpdateforApprove,
  fetchhosnameid
}

// const UpdateHospitalBasicInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         // hospitalBasicInfo_services.DestroyHospitalBasicInfo(id);
//         hospital_name = req.body.hospital_name;
//         hospital_type_id = req.body.hospital_type_id;
//         sector_id = req.body.sector_id;
//         // user_id = req.body.user_id;
//         accredation_id = req.body.accredation_id;
//         regNo = req.body.regNo;
//         about = req.body.about;


//         if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//             // File is uploaded
//             certicate_path = req.files.certicate_path;
//             // Process the uploaded file
//         } else {
//             // Text input
//             certicate_path = req.body.certicate_path; // Assuming the input field name is 'hospital_image'
//             // Process the text input
//         }
//         try {
//             hospital_image = req.files.hospital_image;
//         } catch {
//             hospital_image_body = req.body.hospital_image;
//         }
//         isApproved = req.body.isApproved;
//         approve_date = req.body.approve_date;
//         approved_by = req.body.approved_by;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (hospital_name) {
//             const i_data = {
//                 hospital_name: hospital_name,
//                 hospital_type_id: parseInt(hospital_type_id),
//                 sector_id: parseInt(sector_id),
//                 accredation_id: parseInt(accredation_id),
//                 regNo: regNo,
//                 // user_id : user_id,
//                 about: about,
//                 certicate_path: certicate_path,
//                 // hospital_image: hospital_image,
//                 isApproved: isApproved,
//                 approved_by: approved_by,
//                 approve_date: approve_date,
//                 active: parseInt(active),
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }

//             if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//                 // File is uploaded
//                 i_data.certicate_path = certicate_path.name;
//                 buffer = certicate_path.data
//                 path = './media/' + certicate_path.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//                 // Process the uploaded file
//             }
//             else {
//                 // Text input
//                 certicate_path = req.body.certicate_path; // Assuming the input field name is 'hospital_image'
//                 i_data.certicate_path = certicate_path;
//                 // Process the text input
//             }
//             // console.log(i_data)

//             await hospitalBasicInfo_services.GetbyName(regNo)
//                 .then(basic_data => {
//                     if (basic_data.length > 0) {
//                         msg = "Invalid Register Number";
//                         return res.status(200).json(failure_func(msg))
//                     } else {
//                         hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data)
//                             .then(data => {
//                                 if (data == 1) {
//                                     const hosp_id = req.params.id;
//                                     hospital_img_services.CheckHospitalmgBasicInfo(hosp_id)
//                                         .then(result => {
//                                             if (req.files == null) {
//                                                 const hospital_image_body_data = req.body.hospital_image.toString();
//                                                 var req_array = hospital_image_body_data.split(',');
//                                                 var exist_array = [];

//                                                 result.forEach((element) => {
//                                                     exist_array.push(element.hospital_image)
//                                                 });
//                                                 var uncommonElements = [];

//                                                 // Create sets for faster lookup
//                                                 const set1 = new Set(req_array);
//                                                 const set2 = new Set(exist_array);
//                                                 for (const item of set1) {
//                                                     if (!set2.has(item)) {
//                                                         uncommonElements.push(item);
//                                                     }
//                                                 }
//                                                 // Check for uncommon elements in arr2
//                                                 for (const item of set2) {
//                                                     if (!set1.has(item)) {
//                                                         uncommonElements.push(item);
//                                                     }
//                                                 }
//                                                 if (uncommonElements.length > 0) {
//                                                     const filteredData = result.filter((item) => uncommonElements.includes(item.hospital_image));
//                                                     filteredData.forEach((element) => {
//                                                         HospitalImgInfo.destroy({ where: { hospital_image: element.hospital_image } })
//                                                             .then(data => {
//                                                                 res = data
//                                                             }).catch(err => {
//                                                                 res = err
//                                                             })
//                                                     });
//                                                 }
//                                             }
//                                             else {
//                                                 console.log('else');
//                                                 const hospital_image = req.files.hospital_image;
//                                                 const check_file = hospital_image.length;
//                                                 if (check_file == undefined) {
//                                                     const dummy = [];
//                                                     dummy.push(hospital_image);
//                                                     dummy.forEach((element) => {
//                                                         const hospital_image = element.name;
//                                                         const record = element.name;
//                                                         buffer = element.data
//                                                         path = './media/' + element.name;
//                                                         fs.writeFile(path.toString(), buffer, function (err) {
//                                                             if (err) {
//                                                                 return console.log(err);
//                                                             }
//                                                         });
//                                                         i_data_img = {
//                                                             hospital_name_id: req.params.id,
//                                                             hospital_image: record,
//                                                             active: active,
//                                                             created_by: updated_by,
//                                                             updated_by: updated_by
//                                                         }
//                                                         console.log('i_data_img', i_data_img);
//                                                         hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                                     });

//                                                 }
//                                                 else {
//                                                     hospital_image.forEach((element) => {
//                                                         const hospital_image = element.name;
//                                                         const record = element.name;
//                                                         buffer = element.data
//                                                         path = './media/' + element.name;
//                                                         fs.writeFile(path.toString(), buffer, function (err) {
//                                                             if (err) {
//                                                                 return console.log(err);
//                                                             }
//                                                         });
//                                                         i_data_img = {
//                                                             hospital_name_id: req.params.id,
//                                                             hospital_image: record,
//                                                             active: active,
//                                                             created_by: updated_by,
//                                                             updated_by: updated_by
//                                                         }
//                                                         console.log('i_data_img', i_data_img);
//                                                         hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                                     });
//                                                 }


//                                             }
//                                         })
//                                     msg = "Updated successfully"
//                                     cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                                     res.status(200).json(success_func(msg))
//                                 } else {
//                                     msg = "ID doesn't exist"
//                                     res.status(400).json(failure_func(msg))
//                                 }
//                             })
//                             .catch(err => {
//                                 res.status(400).json(failure_func(err))
//                             })

//                     }
//                 })
//         } else {
//             msg = "hospital_name is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const NewHospitalBasicInfo = async (req, res, next) => {
//     // console.log(req.files, "req.files");
//     hospital_name = req.body.hospital_name;
//     hospital_type_id = req.body.hospital_type_id;
//     sector_id = req.body.sector_id;
//     accredation_id = req.body.accredation_id;
//     regNo = req.body.regNo;
//     about = req.body.about;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     isApproved = 0;
//     // approve_date = null;
//     approved_by = '';
//     const addCheck = 8;
//     try {
//         hospital_image = req.files.hospital_image;
//     } catch {
//         hospital_image = null
//     }
//     try {
//         certicate_path = req.files.certicate_path
//     } catch {
//         certicate_path = null
//     }
//     if (hospital_name) {
//         i_data = {
//             hospital_name: hospital_name,
//             hospital_type_id: parseInt(hospital_type_id),
//             sector_id: parseInt(sector_id),
//             accredation_id: parseInt(accredation_id),
//             certicate_path: certicate_path,
//             regNo: regNo,
//             about: about,
//             isApproved: isApproved,
//             approve_date: null,
//             active: parseInt(active),
//             addCheck: addCheck,
//             created_by: created_by,
//             updated_by: updated_by
//         }

//         if (certicate_path) {
//             i_data.certicate_path = certicate_path.name;
//             buffer = certicate_path.data
//             path = './media/' + certicate_path.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         console.log(i_data);

//         await hospitalBasicInfo_services.GetbyName(regNo)
//             .then(basic_data => {
//                 if (basic_data.length > 0) {
//                     msg = "Invalid Register Number";
//                     return res.status(200).json(failure_func(msg))
//                 } else {

//                     // console.log('else');
//                     hospitalBasicInfo_services.CreateHospitalBasicInfo(i_data)
//                         .then(data => {
//                             // console.log("asdaf");
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 // console.log('kkkkkk', data);
//                                 var as = [];

//                                 as.push(hospital_image)
//                                 // console.log('hhhh', data.dataValues.id);
//                                 if (data.dataValues.id) {

//                                     if (hospital_image.length) {

//                                         hospital_image.forEach((element) => {
//                                             hospital_image = element.name;
//                                             record = element.name;
//                                             buffer = element.data
//                                             path = './media/' + element.name;
//                                             fs.writeFile(path.toString(), buffer, function (err) {
//                                                 if (err) {
//                                                     return console.log(err);
//                                                 }
//                                             });
//                                             i_data_img = {
//                                                 hospital_name_id: data.dataValues.id,
//                                                 hospital_image: record,
//                                                 active: active,
//                                                 created_by: created_by,
//                                                 updated_by: updated_by
//                                             }
//                                             // console.log('i_data_img', i_data_img);
//                                             hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                         });
//                                     }
//                                     else {
//                                         as.forEach((element) => {
//                                             hospital_image = element.name;
//                                             record = element.name;
//                                             buffer = element.data
//                                             path = './media/' + element.name;
//                                             fs.writeFile(path.toString(), buffer, function (err) {
//                                                 if (err) {
//                                                     return console.log(err);
//                                                 }
//                                             });
//                                             i_data_img = {
//                                                 hospital_name_id: data.dataValues.id,
//                                                 hospital_image: record,
//                                                 active: active,
//                                                 created_by: created_by,
//                                                 updated_by: updated_by
//                                             }
//                                             // console.log('i_data_img', i_data_img);
//                                             hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                         });
//                                     }


//                                 }

//                                 hospitalBasicInfo_services.GetbyName(hospital_name)
//                                     .then(datas => {
//                                         datas.msg = "Created Successfully";
//                                         //cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                                         res.status(200).json(success_func(datas))
//                                     })
//                                     .catch(err => {
//                                         res.status(400).json(failure_func(err))
//                                     })
//                             }
//                         })
//                         .catch(err => {
//                             msg = "failed"
//                             res.status(400).json(failure_func(msg))
//                         })
//                 }
//             })
//     }
//     else {
//         msg = "hospital_name is required";
//         res.status(400).json(failure_func(msg))
//     }
// }