const sequelize = require('../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const Role = require('./RoleModel');
const logger = require('../config/activity_logger');
const NotificationMaster = require('../MastersApp/models/NotificationMasterModel');
const NotificationMapping = require('../MastersApp/models/NotificationMappingModel');


const User = sequelize.define("User", {
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Email is required"
            },
            isEmail: {
                msg: "Enter a valid email address"
            }
        }
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Username is required"
            }
        }
    },
    password: {
        type: DataTypes.STRING,
        allowNull: true,
        validate: {
            notEmpty: {
                msg: "Password is required"
            },
        }
    },
    mobile: {
        type: DataTypes.NUMBER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Mobile Nummber is required"
            },
            len: {
                args: [10, 15],
                msg: "Please enter 10 digit Mobile Number"
            }
        }
    },
    active: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: 1,
    },
    is_verified: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: false,
    },
    profile_image: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: '',
    },
    roles_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
        validate: {
            notEmpty: {
                msg: "Role is required"
            },
        }
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    OTP: {
        type: DataTypes.STRING,
        allowNull: false,
    }
});
User.hasMany(NotificationMapping, {
    foreignKey: 'user_id',
    as: 'notificationMappings' // Alias to be used for the association
});
User.belongsTo(Role, { foreignKey: 'roles_id' });
// User.belongsTo(NotificationMapping, {foreignKey:'user_id'});

User.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'users',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

User.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'users',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = User;

