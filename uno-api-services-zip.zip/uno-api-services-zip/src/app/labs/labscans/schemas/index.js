const getScanByLabSchema = require("./getScanByLabSchema");
const getHealthPackageByScanSchema = require("./getHealthPackageByScanSchema");

module.exports = {
  getScanByLabSchema,
  getHealthPackageByScanSchema
};
