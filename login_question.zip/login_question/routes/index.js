const schemas = require("../schemas");
const handlers = require("../handlers");
const fastify = require("fastify");

module.exports = async fastify => {
    fastify.route({
        method: "GET",
        url: "/login/questions/:patient_id?",
        // schema: schemas.getloginquestionSchema.loginquestionSchema,
        handler: handlers.LoginquestionHandler.getLoginquestionHandler(fastify)
    });

    fastify.route({
        method: "GET",
        url: "/getallcat/question",
        // schema: schemas.getloginquestionSchema.allcatloginquestionSchema,
        handler: handlers.LoginquestionHandler.getallcatquestionHandler(fastify)
    });

    fastify.route({
        method: "POST",
        url: "/login/questions_post",
        // schema: schemas.getloginquestionSchema.allcatloginquestionSchema,
        handler: handlers.LoginquestionHandler.anspostHandler(fastify)
    });

    fastify.route({
        method: "POST",
        url: "/login/cat_questions_post",
        schema: schemas.getloginquestionSchema.postLoginCategorySchema,
        handler: handlers.LoginquestionHandler.loginQuestionCatPostHandler(fastify)
    });

    fastify.route({
        method: "PUT",
        url: "/login/cat_questions_post/:id",
        schema: schemas.getloginquestionSchema.putLoginCategorySchema,
        handler: handlers.LoginquestionHandler.loginQuestionCatUpdateHandler(fastify)
    });

    fastify.route({
        method: "Delete",
        url: "/login/cat_questions_post/:id",
        schema: schemas.getloginquestionSchema.deleteLoginCategorySchema,
        handler: handlers.LoginquestionHandler.loginQuestionCatDeleteHandler(fastify)
    });

    // fastify.route({
    //     method: "POST",
    //     url: "/patient/login_verify",
    //     schema: schemas.PatientLoginSchema,
    //     handler: handlers.PatientLoginHandler.patientcheckLoginHandler(fastify)
    // });

    // fastify.route({
    //     method: "POST",
    //     url: "/patient/resendotp",
    //     handler: handlers.PatientLoginHandler.resendotp(fastify)
    // });

};
