const TestInfo = require('../models/LabTestPackageModel');
// const labInfo = require('../models/LabBasicInfoModel');
// const LabCategoryMaster = require('../../MastersApp/models/LabTestCategoryModel');
const LabTestMaster = require('../../MastersApp/models/LabTestModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');



const Get = async () => {
    await TestInfo.findAll({ include :[LabTestMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
// ({ where: { lab_name_id: lab_name_id }, include: [LabInfo] })

const GetbyId = async (lab_name_id) => {

    await TestInfo.findAll({ where: { lab_name_id: lab_name_id }
     })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await TestInfo.findAll({ where: { lab_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreatTestPack = async (lt_data) => {
    await TestInfo.create(lt_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyTestPack = async (id) => {
    await TestInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabTestPackService = async (lab_name_id, tc_data) => {
    await TestInfo.update(tc_data, { where: { lab_name_id: lab_name_id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreatTestPack,
    DestroyTestPack,
    UpdateLabTestPackService
};
