const ScanTestModel = require('../models/ScanTestModel');
const ScanTestCategory = require('../../MastersApp/models/ScanTestMasterModel')
const ScanTestModelId = require('../models/ScantestIdModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');


const Get = async (id) => {
    let res;
    await ScanTestModel.findAll({

        include: [{
            model: ScanTestModelId,
            include: ScanTestCategory
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}
const GetbyId = async (id) => {
    let res;
    await ScanTestModel.findAll({
        where: {
            id: id
        },
        include: [{
            model: ScanTestModelId,
            include: ScanTestCategory
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}


const CreateScanTest = async (c_data) => {
    await ScanTestModel.create(c_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateScanType = async (id, c_data) => {
    await ScanTestModel.update(c_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyScanType = async (id) => {
    await ScanTestModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (test_name) => {
    await ScanTestModel.findAll({ where: { test_name: test_name } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateScanTest,
    GetbyName,
    UpdateScanType,
    DestroyScanType,
    Get,
    GetbyId,
};