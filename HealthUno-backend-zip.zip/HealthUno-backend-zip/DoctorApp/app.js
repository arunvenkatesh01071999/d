const express = require('express');
const app = express();

const DoctorBasicInfoRouter = require('./routes/doctor_basic_info');
const DoctorAddressInfoRouter = require('./routes/address_info');
const DoctorLanguageInfoRouter = require('./routes/language_info');
const EducationInfoRouter = require('./routes/education_info');
const CouncilInfoRouter = require('./routes/council_info');
const ExperienceRouter = require('./routes/experience_info');
const AvailabilityRouter = require('./routes/availability_info');
const SecondOpinionRouter = require('./routes/second_opinion');
const SlotBookingRouter = require('./routes/slot_booking');
const PaymentRouter = require('./routes/payment_info');
const DoctorRepositoryRouter = require('./routes/repository_info');

app.use('/doctor-basic-info', DoctorBasicInfoRouter);
app.use('/d-address-info', DoctorAddressInfoRouter);
app.use('/d-language-info', DoctorLanguageInfoRouter);
app.use('/d-education-info', EducationInfoRouter);
app.use('/d-council-info', CouncilInfoRouter);
app.use('/d-experience-info', ExperienceRouter);
app.use('/d-availablity-info', AvailabilityRouter);
app.use('/d-second-opinion', SecondOpinionRouter);
app.use('/d-slot-booking', SlotBookingRouter);
app.use('/d-payment', PaymentRouter);
app.use('/d-repository-basic-info', DoctorRepositoryRouter);

module.exports = app;