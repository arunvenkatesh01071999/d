const express = require('express');
const router = express();
const PaymentController = require('../../DoctorApp/controller/PaymentController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, PaymentController.FetchPayment);
router.get('/:doctor_name_id', verify_token, PaymentController.FetchPayment);
router.post('/', verify_token, PaymentController.NewPayment);

module.exports = router;