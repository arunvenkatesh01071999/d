const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { HOSPITAL_BASIC_INFO } = require("../commons/constants");
const { HOSPITAL_SECTOR } = require("../commons/constants");
const { ACCREDATION } = require("../commons/constants");
const { HOSPITAL_ADDRESS_INFO } = require("../commons/constants");
const { CITIES } = require("../commons/constants");
const { STATES } = require("../commons/constants");
const { COUNTRIES } = require("../commons/constants");
const { HOSPITAL_CONTACT_INFO } = require("../commons/constants");
const { HOSPITAL_INFRASTRUCTURE } = require("../commons/constants");
const { ROOM_TYPE } = require("../commons/constants");
const { HOSPITAL_ROOM_INFO } = require("../commons/constants");
const { DEPARTMENT_MASTER } = require("../commons/constants");
const { HOSPITAL_DEPARTMENT } = require("../commons/constants");
const { HOSPITAL_SPECIALITY_INFO } = require("../commons/constants");
const { SPECIALITIES } = require("../commons/constants");
const { HOSPITAL_SERVICE_INFO } = require("../commons/constants");
const { HOSPITAL_SERVICES_MASTER } = require("../commons/constants");
const { HOSPITAL_LAB_INFO } = require("../commons/constants");
const { LAB_SERVICE } = require("../commons/constants");
const { HOSPITAL_SCAN_INFO } = require("../commons/constants");
const { SCAN_TEST_MASTER } = require("../commons/constants");
const { HOSPITAL_INSURANCE_INFO } = require("../commons/constants");
const { INSURANCE } = require("../commons/constants");
const { HOSPITAL_OFFICE_USE } = require("../commons/constants");
const { HOSPITAL_TERMS_CONDITION } = require("../commons/constants");
const { HOSPITAL_PAYMENT_INFO } = require("../commons/constants");
const { FEES_TYPE_MASTER } = require("../commons/constants");
const { DOCTORBASICINFO } = require("../commons/constants");
const { GENDER } = require("../commons/constants");
const { DOCTORAVAILABILITY } = require("../commons/constants");
const { DOCTOR_EXPERIENCE } = require("../commons/constants");
const { DOCTOR_FEES } = require("../commons/constants");
const { HOSPITAl_IMAGES } = require("../commons/constants");
const { DOCTORLANGUAGEINFO } = require("../commons/constants");
const { LANGUAGES } = require("../commons/constants");

function hospitalRepo(fastify) {
  async function getHospital({ params, logTrace }) {
    const knex = this;
    const query = knex(HOSPITAL_BASIC_INFO.NAME).where(
      HOSPITAL_BASIC_INFO.COLUMNS.ACTIVE,
      1
    );
    // Check if search term is provided and longer than or equal to 3 characters
    if (params.search && params.search.length >= 3) {
      query.where(
        HOSPITAL_BASIC_INFO.COLUMNS.HOSPITAL_NAME,
        "like",
        `%${params.search}%`
      );
    }
    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospitals",
      logTrace
    });
    const response = await query
      .orderBy(HOSPITAL_BASIC_INFO.COLUMNS.ID, "DESC")
      .paginate({
        pageSize: params.page_size,
        currentPage: params.current_page
      });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospitals not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    return response;
  }
  async function getHospitalInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_BASIC_INFO.NAME}.*`,
        `${HOSPITAL_SECTOR.NAME}.${HOSPITAL_SECTOR.COLUMNS.HOSPITAL_SECTOR_NAME}`,
        `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ACCREDATION_NAME}`
      ])
      .from(`${HOSPITAL_BASIC_INFO.NAME} as ${HOSPITAL_BASIC_INFO.NAME}`)
      .leftJoin(
        `${HOSPITAL_SECTOR.NAME} as ${HOSPITAL_SECTOR.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.SECTOR_ID}`,
        `${HOSPITAL_SECTOR.NAME}.${HOSPITAL_SECTOR.COLUMNS.ID}`
      )
      .leftJoin(
        `${ACCREDATION.NAME} as ${ACCREDATION.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ACCREDATION_ID}`,
        `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ACTIVE}`,
        1
      )
      .where(
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function getHospitalAddressInfo({ params, logTrace, lat, long }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_ADDRESS_INFO.NAME}.*`,
        `${CITIES.NAME}.${CITIES.COLUMNS.CITYNAME}`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as ${STATES.NAME}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.SHORTNAME}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.PHONECODE}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as ${COUNTRIES.NAME}`,
        knex.raw(`
      ROUND(
        geography::Point(${lat}, ${long}, 4326)
        .STDistance(
          geography::Point(${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.LATITUDE}, ${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.LONGITUDE}, 4326)
        ) / 1000, -- Convert to kilometers
        2 -- Two fractional digits
      ) AS distance
    `)
      ])
      .from(`${HOSPITAL_ADDRESS_INFO.NAME} as ${HOSPITAL_ADDRESS_INFO.NAME}`)
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.CITY_ID}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.STATE_ID}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.COUNTRY_ID}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )

      .where(
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.ACTIVE}`,
        1
      )
      .where(
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.HOSPITAL_NAME_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalContactInfo({ params, logTrace }) {
    const knex = this;
    const query = knex(HOSPITAL_CONTACT_INFO.NAME).where(
      HOSPITAL_CONTACT_INFO.COLUMNS.HOSPITAL_ID,
      params.hospital_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospitals contacts",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's contact not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalInfraInfo({ params, logTrace }) {
    const knex = this;
    const query = knex(HOSPITAL_INFRASTRUCTURE.NAME).where(
      HOSPITAL_INFRASTRUCTURE.COLUMNS.HOSPITAL_ID,
      params.hospital_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's infrastructure",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's infrastructure not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalRoomInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_ROOM_INFO.NAME}.*`,
        `${ROOM_TYPE.NAME}.${ROOM_TYPE.COLUMNS.ROOM_TYPE}`
      ])
      .from(`${HOSPITAL_ROOM_INFO.NAME} as ${HOSPITAL_ROOM_INFO.NAME}`)
      .leftJoin(
        `${ROOM_TYPE.NAME} as ${ROOM_TYPE.NAME}`,
        `${HOSPITAL_ROOM_INFO.NAME}.${HOSPITAL_ROOM_INFO.COLUMNS.ROOM_TYPE_ID}`,
        `${ROOM_TYPE.NAME}.${ROOM_TYPE.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_ROOM_INFO.NAME}.${HOSPITAL_ROOM_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's room information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      return [];
      // throw CustomError.create({
      //   httpCode: StatusCodes.NOT_FOUND,
      //   message: "Hospital's rooms not found",
      //   property: "",
      //   code: "NOT_FOUND"
      // });
    }
    return response;
  }
  async function getHospitalDepartmentInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_DEPARTMENT.NAME}.*`,
        `${DEPARTMENT_MASTER.NAME}.${DEPARTMENT_MASTER.COLUMNS.DEAPARTMENT_NAME}`
      ])
      .from(`${HOSPITAL_DEPARTMENT.NAME} as ${HOSPITAL_DEPARTMENT.NAME}`)
      .leftJoin(
        `${DEPARTMENT_MASTER.NAME} as ${DEPARTMENT_MASTER.NAME}`,
        `${HOSPITAL_DEPARTMENT.NAME}.${HOSPITAL_DEPARTMENT.COLUMNS.DEAPARTMENT_NAME_ID}`,
        `${DEPARTMENT_MASTER.NAME}.${DEPARTMENT_MASTER.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_DEPARTMENT.NAME}.${HOSPITAL_DEPARTMENT.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's department information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      return [];
    }
    return response;
  }
  async function getHospitalSpecialityInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_SPECIALITY_INFO.NAME}.*`,
        `${SPECIALITIES.NAME}.${SPECIALITIES.COLUMNS.SPECIALITIY_NAME}`,
        `${SPECIALITIES.NAME}.${SPECIALITIES.COLUMNS.LOGO_IMAGE}`
      ])
      .from(
        `${HOSPITAL_SPECIALITY_INFO.NAME} as ${HOSPITAL_SPECIALITY_INFO.NAME}`
      )
      .leftJoin(
        `${SPECIALITIES.NAME} as ${SPECIALITIES.NAME}`,
        `${HOSPITAL_SPECIALITY_INFO.NAME}.${HOSPITAL_SPECIALITY_INFO.COLUMNS.SPECIALITIY_NAME_ID}`,
        `${SPECIALITIES.NAME}.${SPECIALITIES.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_SPECIALITY_INFO.NAME}.${HOSPITAL_SPECIALITY_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's speciality information",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      return [];
      // throw CustomError.create({
      //   httpCode: StatusCodes.NOT_FOUND,
      //   message: "Hospital's speciality not found",
      //   property: "",
      //   code: "NOT_FOUND"
      // });
    }
    return response;
  }
  async function getHospitalServiceInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_SERVICE_INFO.NAME}.*`,
        `${HOSPITAL_SERVICES_MASTER.NAME}.${HOSPITAL_SERVICES_MASTER.COLUMNS.SERVICE_NAME}`,
        `${HOSPITAL_SERVICES_MASTER.NAME}.${HOSPITAL_SERVICES_MASTER.COLUMNS.LOGO_IMAGE}`
      ])
      .from(`${HOSPITAL_SERVICE_INFO.NAME} as ${HOSPITAL_SERVICE_INFO.NAME}`)
      .leftJoin(
        `${HOSPITAL_SERVICES_MASTER.NAME} as ${HOSPITAL_SERVICES_MASTER.NAME}`,
        `${HOSPITAL_SERVICE_INFO.NAME}.${HOSPITAL_SERVICE_INFO.COLUMNS.SERVICE_NAME_ID}`,
        `${HOSPITAL_SERVICES_MASTER.NAME}.${HOSPITAL_SERVICES_MASTER.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_SERVICE_INFO.NAME}.${HOSPITAL_SERVICE_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's service information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      return [];
      // throw CustomError.create({
      //   httpCode: StatusCodes.NOT_FOUND,
      //   message: "Hospital's service not found",
      //   property: "",
      //   code: "NOT_FOUND"
      // });
    }
    return response;
  }
  async function getHospitalLabInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_LAB_INFO.NAME}.*`,
        `${LAB_SERVICE.NAME}.${LAB_SERVICE.COLUMNS.SERVICE_NAME}`
      ])
      .from(`${HOSPITAL_LAB_INFO.NAME} as ${HOSPITAL_LAB_INFO.NAME}`)
      .leftJoin(
        `${LAB_SERVICE.NAME} as ${LAB_SERVICE.NAME}`,
        `${HOSPITAL_LAB_INFO.NAME}.${HOSPITAL_LAB_INFO.COLUMNS.LAB_NAME_ID}`,
        `${LAB_SERVICE.NAME}.${LAB_SERVICE.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_LAB_INFO.NAME}.${HOSPITAL_LAB_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's service information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      return [];
      // throw CustomError.create({
      //   httpCode: StatusCodes.NOT_FOUND,
      //   message: "Hospital's service not found",
      //   property: "",
      //   code: "NOT_FOUND"
      // });
    }
    return response;
  }
  async function getHospitalScanInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_SCAN_INFO.NAME}.*`,
        `${SCAN_TEST_MASTER.NAME}.${SCAN_TEST_MASTER.COLUMNS.SCAN_TEST_NAME}`
      ])
      .from(`${HOSPITAL_SCAN_INFO.NAME} as ${HOSPITAL_SCAN_INFO.NAME}`)
      .leftJoin(
        `${SCAN_TEST_MASTER.NAME} as ${SCAN_TEST_MASTER.NAME}`,
        `${HOSPITAL_SCAN_INFO.NAME}.${HOSPITAL_SCAN_INFO.COLUMNS.SCAN_NAME_ID}`,
        `${SCAN_TEST_MASTER.NAME}.${SCAN_TEST_MASTER.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_SCAN_INFO.NAME}.${HOSPITAL_SCAN_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's service information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's service not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalInsuranceInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_INSURANCE_INFO.NAME}.*`,
        `${INSURANCE.NAME}.${INSURANCE.COLUMNS.INSURANCE_NAME}`
      ])
      .from(
        `${HOSPITAL_INSURANCE_INFO.NAME} as ${HOSPITAL_INSURANCE_INFO.NAME}`
      )
      .leftJoin(
        `${INSURANCE.NAME} as ${INSURANCE.NAME}`,
        `${HOSPITAL_INSURANCE_INFO.NAME}.${HOSPITAL_INSURANCE_INFO.COLUMNS.INSURANCE_NAME_ID}`,
        `${INSURANCE.NAME}.${INSURANCE.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_INSURANCE_INFO.NAME}.${HOSPITAL_INSURANCE_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's service information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's service not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalOfficialInfo({ params, logTrace }) {
    const knex = this;

    const query = knex(HOSPITAL_OFFICE_USE.NAME).where(
      HOSPITAL_OFFICE_USE.COLUMNS.HOSPITAL_ID,
      params.hospital_id
    );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's Official information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's Official not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalTermsInfo({ params, logTrace }) {
    const knex = this;

    const query = knex(HOSPITAL_TERMS_CONDITION.NAME).where(
      HOSPITAL_TERMS_CONDITION.COLUMNS.HOSPITAL_ID,
      params.hospital_id
    );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's terms information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's terms not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getHospitalPaymentInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_PAYMENT_INFO.NAME}.*`,
        `${FEES_TYPE_MASTER.NAME}.${FEES_TYPE_MASTER.COLUMNS.FEES_TYPE_NAME}`
      ])
      .from(`${HOSPITAL_PAYMENT_INFO.NAME} as ${HOSPITAL_PAYMENT_INFO.NAME}`)
      .leftJoin(
        `${FEES_TYPE_MASTER.NAME} as ${FEES_TYPE_MASTER.NAME}`,
        `${HOSPITAL_PAYMENT_INFO.NAME}.${HOSPITAL_PAYMENT_INFO.COLUMNS.FEES_TYPE_ID}`,
        `${FEES_TYPE_MASTER.NAME}.${FEES_TYPE_MASTER.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_PAYMENT_INFO.NAME}.${HOSPITAL_PAYMENT_INFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's payment information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's payment not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  async function getHospitalDoctorInfo({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${DOCTORBASICINFO.NAME}.*`,
        `${GENDER.NAME}.${GENDER.COLUMNS.GENDER_NAME}`,
        `${SPECIALITIES.NAME}.${SPECIALITIES.COLUMNS.SPECIALITIY_NAME}`,
        `${DOCTORAVAILABILITY.NAME}.${DOCTORAVAILABILITY.COLUMNS.AVAIL_CHAT}`,
        `${DOCTORAVAILABILITY.NAME}.${DOCTORAVAILABILITY.COLUMNS.AVAIL_CONSULT}`,
        `${DOCTORAVAILABILITY.NAME}.${DOCTORAVAILABILITY.COLUMNS.INST_CONSULT}`,
        `${DOCTORAVAILABILITY.NAME}.${DOCTORAVAILABILITY.COLUMNS.INST_TIME}`
      ])
      .from(`${DOCTORBASICINFO.NAME} as ${DOCTORBASICINFO.NAME}`)
      .leftJoin(
        `${GENDER.NAME} as ${GENDER.NAME}`,
        `${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.GENDER_ID}`,
        `${GENDER.NAME}.${GENDER.COLUMNS.ID}`
      )
      .leftJoin(
        `${SPECIALITIES.NAME} as ${SPECIALITIES.NAME}`,
        `${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.SPECIALITY_ID}`,
        `${SPECIALITIES.NAME}.${SPECIALITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${DOCTORAVAILABILITY.NAME} as ${DOCTORAVAILABILITY.NAME}`,
        `${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.ID}`,
        `${DOCTORAVAILABILITY.NAME}.${DOCTORAVAILABILITY.COLUMNS.DOCTOR_NAME_ID}`
      )
      .where(`${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.ACTIVE}`, 1)
      .where(`${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.ISAPPROVED}`, 1)
      .where(
        `${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.HOSPITAL_ID}`,
        params.hospital_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's doctors information",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      return [];
    }

    // Fetch multiple experience and fees rows for each doctor separately

    const doctorsWithFeesAndExperience = await Promise.all(
      response.map(async doctor => {
        const fees = await knex(DOCTOR_FEES.NAME)
          .select()
          .where(DOCTOR_FEES.COLUMNS.DOCTOR_ID, doctor.id);

        const experiences = await knex(DOCTOR_EXPERIENCE.NAME)
          .select()
          .where(DOCTOR_EXPERIENCE.COLUMNS.DOCTOR_NAME_ID, doctor.id);

        const languages = await knex
          .select([`${LANGUAGES.NAME}.*`])
          .from(`${DOCTORLANGUAGEINFO.NAME} as ${DOCTORLANGUAGEINFO.NAME}`)
          .leftJoin(
            `${LANGUAGES.NAME} as ${LANGUAGES.NAME}`,
            `${DOCTORLANGUAGEINFO.NAME}.${DOCTORLANGUAGEINFO.COLUMNS.LANGUAGE_NAME_ID}`,
            `${LANGUAGES.NAME}.${LANGUAGES.COLUMNS.ID}`
          )
          .where(
            `${DOCTORLANGUAGEINFO.NAME}.${DOCTORLANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID}`,
            doctor.id
          );

        return { ...doctor, fees, experiences, languages };
      })
    );
    // Now doctorsWithExperience and doctorsWithFees hold doctors data with their respective experiences and fees
    return doctorsWithFeesAndExperience;
  }

  async function getHospitalFilter({ params, logTrace, lat, long }) {
    const knex = this;
    const query = knex
      .select([
        `${HOSPITAL_BASIC_INFO.NAME}.*`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.LATITUDE}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.LONGITUDE}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.ADDRESS1}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.ADDRESS2}`,
        `${HOSPITAL_SECTOR.NAME}.${HOSPITAL_SECTOR.COLUMNS.HOSPITAL_SECTOR_NAME}`,
        `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ACCREDATION_NAME}`,
        knex.raw(`
        ROUND(
          geography::Point(
            ${lat}, 
            ${long}, 
            4326
          ).STDistance(
            geography::Point(
              ISNULL(${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.LATITUDE}, 0), 
              ISNULL(${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.LONGITUDE}, 0), 
              4326
            )
          ) / 1000,
          2
        ) AS distance
      `)
      ])
      .from(`${HOSPITAL_BASIC_INFO.NAME} as ${HOSPITAL_BASIC_INFO.NAME}`)
      .leftJoin(
        `${HOSPITAL_ADDRESS_INFO.NAME} as ${HOSPITAL_ADDRESS_INFO.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ID}`,
        `${HOSPITAL_ADDRESS_INFO.NAME}.${HOSPITAL_ADDRESS_INFO.COLUMNS.HOSPITAL_NAME_ID}`
      )
      .leftJoin(
        `${HOSPITAL_SECTOR.NAME} as ${HOSPITAL_SECTOR.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.SECTOR_ID}`,
        `${HOSPITAL_SECTOR.NAME}.${HOSPITAL_SECTOR.COLUMNS.ID}`
      )
      .leftJoin(
        `${ACCREDATION.NAME} as ${ACCREDATION.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ACCREDATION_ID}`,
        `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ACTIVE}`,
        1
      )
      .where(
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ISAPPROVED}`,
        1
      );
    // Check if search term is provided and longer than or equal to 3 characters
    if (params.search && params.search.length >= 3) {
      query.where(
        HOSPITAL_BASIC_INFO.COLUMNS.HOSPITAL_NAME,
        "like",
        `%${params.search}%`
      );
    }
    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospitals",
      logTrace
    });
    // console.log("params.sortbyreview : " + params.sortbyreview);

    const responseQuery = query;

    if (params.sortbyreview !== "NA") {
      responseQuery.orderBy(
        `${HOSPITAL_BASIC_INFO.COLUMNS.RATING}`,
        params.sortbyreview
      );
    }

    if (params.sortbyname !== "NA") {
      responseQuery.orderBy(
        `${HOSPITAL_BASIC_INFO.COLUMNS.HOSPITAL_NAME}`,
        params.sortbyname
      );
    }

    if (params.sortbydistance !== "NA") {
      responseQuery.orderByRaw("distance " + params.sortbydistance);
    }

    // If all sorting params are 'NA', order by hospital name ASC
    if (
      params.sortbyreview === "NA" &&
      params.sortbyname === "NA" &&
      params.sortbydistance === "NA"
    ) {
      responseQuery.orderBy(
        `${HOSPITAL_BASIC_INFO.COLUMNS.HOSPITAL_NAME}`,
        "asc"
      );
    }

    const response = await responseQuery.paginate({
      pageSize: params.page_size,
      currentPage: params.current_page
    });

    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospitals not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const hospitalWithImages = await Promise.all(
      response.data.map(async hospital => {
        const images = await knex(HOSPITAl_IMAGES.NAME)
          .select()
          .where(HOSPITAl_IMAGES.COLUMNS.HOSPITAL_NAME_ID, hospital.id);

        return { ...hospital, images };
      })
    );
    return {
      data: hospitalWithImages,
      meta: response.meta
    };
  }
  async function assignHospitalUser({ logTrace, body, params }) {
    const knex = this;
    const query = knex(`${HOSPITAL_BASIC_INFO.NAME}`)
      .where(`${HOSPITAL_BASIC_INFO.COLUMNS.ID}`, body.hospital_id)
      .update({
        [HOSPITAL_BASIC_INFO.COLUMNS.HOSPITAL_USER]: body.user_id
      });
    const response = await query;

    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "user assign failed",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true, message: "user assigned successfully" };
  }
  async function getHospitalInfoByUser({ params, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${HOSPITAL_BASIC_INFO.NAME}.*`,
        `${HOSPITAL_SECTOR.NAME}.${HOSPITAL_SECTOR.COLUMNS.HOSPITAL_SECTOR_NAME}`,
        `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ACCREDATION_NAME}`
      ])
      .from(`${HOSPITAL_BASIC_INFO.NAME} as ${HOSPITAL_BASIC_INFO.NAME}`)
      .leftJoin(
        `${HOSPITAL_SECTOR.NAME} as ${HOSPITAL_SECTOR.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.SECTOR_ID}`,
        `${HOSPITAL_SECTOR.NAME}.${HOSPITAL_SECTOR.COLUMNS.ID}`
      )
      .leftJoin(
        `${ACCREDATION.NAME} as ${ACCREDATION.NAME}`,
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ACCREDATION_ID}`,
        `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ID}`
      )
      .where(
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.ACTIVE}`,
        1
      )
      .where(
        `${HOSPITAL_BASIC_INFO.NAME}.${HOSPITAL_BASIC_INFO.COLUMNS.HOSPITAL_USER}`,
        params.user_id
      );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital's information",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hospital's not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  return {
    getHospital,
    getHospitalInfo,
    getHospitalAddressInfo,
    getHospitalContactInfo,
    getHospitalInfraInfo,
    getHospitalRoomInfo,
    getHospitalDepartmentInfo,
    getHospitalSpecialityInfo,
    getHospitalServiceInfo,
    getHospitalLabInfo,
    getHospitalScanInfo,
    getHospitalInsuranceInfo,
    getHospitalOfficialInfo,
    getHospitalTermsInfo,
    getHospitalPaymentInfo,
    getHospitalDoctorInfo,
    getHospitalFilter,
    assignHospitalUser,
    getHospitalInfoByUser
  };
}

module.exports = hospitalRepo;
