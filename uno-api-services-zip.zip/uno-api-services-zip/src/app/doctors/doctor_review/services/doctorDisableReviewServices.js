const doctorReviewRepo = require("../repository/doctorReview");
function doctorDisableReviewServices(fastify) {
  const { postDisableReview } = doctorReviewRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const { doctor_id, patient_id, active } = body;

    const response = await postDisableReview.call(knex, {
      logTrace,
      input: {
        doctor_id,
        patient_id,
        active
      }
    });

    return response;
  };
}
module.exports = doctorDisableReviewServices;
