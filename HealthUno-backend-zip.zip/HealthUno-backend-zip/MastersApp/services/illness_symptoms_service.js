const IllnessSymptomsMaster = require('../models/IllnessSymptomsMasterModel');
const IllnessSymptoms = require('../models/IllnessSymptomsModel');
const IllnessTypes = require('../models/IllnessTypesModel');

const Get = async () => {
    await IllnessSymptoms.findAll({ include: [IllnessTypes, IllnessSymptomsMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await IllnessSymptoms.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateIllnessSymptom = async (i_data) => {

    await IllnessSymptoms.create(i_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateIllnessSymptom = async (id, i_data) => {
    await IllnessSymptoms.update(i_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
            console.log(err);
        })
    return res
}

const DestroyIllnessSymptom = async (id) => {
    await IllnessSymptoms.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const DestroyIllnessSymptombymap = async (id) => {
    await IllnessSymptoms.destroy({ where: { illness_symptom_id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateIllnessSymptom,
    UpdateIllnessSymptom,
    DestroyIllnessSymptom,
    DestroyIllnessSymptombymap
};
