const ServiceInfo = require('../models/LabServiceInfoModel');
const LabServiceModel = require('../../MastersApp/models/LabServiceMasterModel');
const LabInfo = require('../models/LabBasicInfoModel');

const Get = async () => {
    await ServiceInfo.findAll({ include :[LabInfo,LabServiceModel] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (lab_name_id) => {
    await ServiceInfo.findAll({where: { lab_name_id: lab_name_id }, include :[LabInfo,LabServiceModel] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const CreateLabService = async (l_data) => {
    await ServiceInfo.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateLabService = async (id, l_data) => {
    await ServiceInfo.update(l_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyLabService = async (lab_name_id) => {
    await ServiceInfo.destroy({ where: { lab_name_id: lab_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    CreateLabService,
    UpdateLabService,
    DestroyLabService
};