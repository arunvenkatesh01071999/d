## Doctors Search

Case 1: By symptoms Ex. chest pain, head ache

Case 2: By Illness (Disease) Ex. Dengu , Malria

Case 3: By Specality

Case 4: By Doctor Name

## Logic:

1. List all doctors based on search case, and order by Location ASC (shortest should show first)

## API :

1. GET DOCTOR INFO API

## Masters:

1. Doctor registration ayurvedic or allopathy
