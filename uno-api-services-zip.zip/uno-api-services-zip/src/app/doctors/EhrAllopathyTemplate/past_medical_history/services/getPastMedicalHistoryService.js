const getPastMedicalHistoryRepository = require("../repository/getPastMedicalHistoryRepository");

function createPastMedicalHistoryServiceBasic(fastify) {
  const { PastMedicalHistoryAdd } = getPastMedicalHistoryRepository.postPastMedicalHistoryRepositoryBasic(fastify);

  return async ({ body, logTrace}) => {
    const knex = fastify.knexMaster;
    const promise1 = PastMedicalHistoryAdd.call(knex, {
      logTrace,
      body
    });

    const [PastMedicalHistoryAddData] = await Promise.all([promise1]);

    return PastMedicalHistoryAddData;
  };
}

function updatePastMedicalHistoryServiceBasic(fastify) {
  const { PastMedicalHistoryUpdate } = getPastMedicalHistoryRepository.updatePastMedicalHistoryRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = PastMedicalHistoryUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedPastMedicalHistoryData] = await Promise.all([promise1]);

    return updatedPastMedicalHistoryData;
  };
}

function getPastMedicalHistoryInfoService(fastify) {
  
  const { PastMedicalHistoryGetAlls } = getPastMedicalHistoryRepository.getPastMedicalHistoryRepository(fastify);
  
  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = PastMedicalHistoryGetAlls.call(knex, {
      logTrace
    });
    const [getPastMedicalHistoryAlldata] = await Promise.all([promise1]);
    return getPastMedicalHistoryAlldata;
  }
}

function getPastMedicalHistoryInfoServiceId(fastify) {
  
  const { PastMedicalHistoryGetOne } = getPastMedicalHistoryRepository.getPastMedicalHistoryRepositoryId(fastify);
  
  return async ({ params,logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = PastMedicalHistoryGetOne.call(knex, {
      logTrace,
      params
    });
    const [getPastMedicalHistoryOnedata] = await Promise.all([promise1]);
    return getPastMedicalHistoryOnedata;
  }
}

function deletePastMedicalHistoryServiceId(fastify) {
 
  const { PastMedicalHistoryDelete } = getPastMedicalHistoryRepository.deletePastMedicalHistoryRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = PastMedicalHistoryDelete.call(knex, {
      logTrace,
      params
    });

    const [deletePastMedicalHistorydata] = await Promise.all([promise1]);

    return deletePastMedicalHistorydata;
  };
}



module.exports = {

 createPastMedicalHistoryServiceBasic,
 updatePastMedicalHistoryServiceBasic,
 getPastMedicalHistoryInfoService,
 getPastMedicalHistoryInfoServiceId,
 deletePastMedicalHistoryServiceId
};
