const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const room_type_master = require('../services/room_type_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');

const FetchRoomTypeMaster = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await room_type_master.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_room_type_master');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await room_type_master.Get()
                .then(data => {
                    cache.SET(req.user.id + '_room_type_master', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewRoomTypeMaster = async (req, res, next) => {
    room_type_name = req.body.room_type_name;
    cost = req.body.cost;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;

    if (room_type_name) {
        r_data = {
            room_type_name: room_type_name,
            cost: cost,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await room_type_master.GetbyName(room_type_name)
            .then(roomType_data => {
                if (roomType_data.length > 0) {
                    msg = "Room Type Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    room_type_master.CreateRoomType(r_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_room_type_master')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "room_type_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateRoomTypeMaster = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        room_type_name = req.body.room_type_name;
        cost = req.body.cost;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (room_type_name) {
            r_data = {
                room_type_name: room_type_name,
                cost: cost,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // await room_type_master.GetbyName(room_type_name)
            //     .then(roomType_data => {
            //         if (roomType_data.length > 0) {
            //             msg = "Room Type Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            room_type_master.UpdateRoomType(id, r_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_room_type_master')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
            //     }
            // })
        } else {
            msg = "room_type_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteRoomTypeMaster = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await room_type_master.DestroyRoomType(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_room_type_master')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewRoomTypeMaster,
    FetchRoomTypeMaster,
    UpdateRoomTypeMaster,
    DeleteRoomTypeMaster
}