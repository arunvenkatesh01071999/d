const { errorSchemas } = require("../../../../commons/schemas/errorSchemas");


const createClinicalExamSchema = {
  tags: ["POST ClinicalExam"],
  summary: "This API is to Post ClinicalExam ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "doctor_id",
      "patient_id",
      "temperature",
      "pulse",
      "respiratory_rate",
      "sp",
      "heart_rate",
      "blood_systolic",
      "blood_diastolic",
      "height",
      "weight",
      "clinical_examination",
      "active"
    ],
    additionalProperties: false,
    properties: {
      doctor_id: { type: ["integer"] },
      patient_id: { type: ["integer"] },
      temperature:{ type: ["string","null"] },
      pulse: { type: ["string","null"] },
      respiratory_rate: { type: ["string","null"] },
      sp: { type: ["string","null"] },
      heart_rate: { type: ["string","null"] },
      blood_systolic: { type: ["string","null"] },
      blood_diastolic: { type: ["string","null"] },
      height: { type: ["string","null"] },
      weight: { type: ["string","null"] },
      clinical_examination: { type: ["string","null"] },
      active: { type: ["integer"] }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateClinicalExamSchema = {
  tags: ["PUT ClinicalExam"],
  summary: "This API is to Update ClinicalExam ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      patient_id: { type: 'integer' },
    },
    required: ['patient_id'],
  },
  body: {
    type: "object",
    required: [
      "doctor_id",
      "patient_id",
      "temperature",
      "pulse",
      "respiratory_rate",
      "sp",
      "heart_rate",
      "blood_systolic",
      "blood_diastolic",
      "height",
      "weight",
      "clinical_examination",
      "active"
    ],
    additionalProperties: false,
    properties: {
      doctor_id: { type: ["integer"] },
      patient_id: { type: ["integer"] },
      temperature:{ type: ["string","null"] },
      pulse: { type: ["string","null"] },
      respiratory_rate: { type: ["string","null"] },
      sp: { type: ["string","null"] },
      heart_rate: { type: ["string","null"] },
      blood_systolic: { type: ["string","null"] },
      blood_diastolic: { type: ["string","null"] },
      height: { type: ["string","null"] },
      weight: { type: ["string","null"] },
      clinical_examination: { type: ["string","null"] },
      active: { type: ["integer"] }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getClinicalExamSchema = {

  tags: ["GET ClinicalExam"],
  summary: "This API is to get ClinicalExam ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          doctor_id: { type: ["integer"] },
          patient_id: { type: ["integer"] },
          temperature:{ type: ["string","null"] },
          pulse: { type: ["string","null"] },
          respiratory_rate: { type: ["string","null"] },
          sp: { type: ["string","null"] },
          heart_rate: { type: ["string","null"] },
          blood_systolic: { type: ["string","null"] },
          blood_diastolic: { type: ["string","null"] },
          height: { type: ["string","null"] },
          weight: { type: ["string","null"] },
          clinical_examination: { type: ["string","null"] },
          active: { type: ["integer"] }
        }
      }
    },
    ...errorSchemas
  }
};

const deleteClinicalExamSchema = {
  tags: ["DELETE ClinicalExam"],
  summary: "This API is to delete ClinicalExam ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createClinicalExamSchema,
  updateClinicalExamSchema,
  getClinicalExamSchema,
  deleteClinicalExamSchema
};
