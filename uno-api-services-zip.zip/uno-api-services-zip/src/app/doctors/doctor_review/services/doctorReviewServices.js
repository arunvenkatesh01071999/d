const doctorReviewRepo = require("../repository/doctorReview");
const getDoctorReviewServices = require("../services/getDoctorReviewServices");
function doctorReviewServices(fastify) {
  const { postReview } = doctorReviewRepo(fastify);
  const calculateReview = getDoctorReviewServices(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const { doctor_id, patient_id, comments, rating } = body;

    const response = await postReview.call(knex, {
      logTrace,
      input: {
        doctor_id,
        patient_id,
        comments,
        rating
      }
    });

    calculateReview({
      logTrace,
      params: {
        doctor_id
      }
    });
    return response;
  };
}
module.exports = doctorReviewServices;
