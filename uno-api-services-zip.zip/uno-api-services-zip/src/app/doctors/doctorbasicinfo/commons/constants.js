const DOCTORBASICINFO = {
  NAME: "d_doctor_basic_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME: "doctor_name",
    GENDER_ID: "gender_id",
    SPECIALITY_ID: "speciality_id",
    EMAIL: "email",
    PHONE_NO: "phone_no",
    DOB: "dob",
    AGE: "age",
    ABOUT: "about",
    IMAGE_PATH: "image_path",
    SIGNATURE_PATH: "signature_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTOREDUCATIONINFO = {
  NAME: "d_education_info",
  COLUMNS: {
    ID: "id",
    QUALIFICATION_NAME_ID: "qualification_name_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    CERTIFICATE_PATH: "certificate_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    YOP: "yop"
  }
};
const DOCTORADDRESSINFO = {
  NAME: "d_address_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ADDRESS1: "address1",
    ADDRESS2: "address2",
    CITYID: "city_id",
    STATEID: "state_id",
    COUNTRYID: "country_id",
    PINCODE: "pincode",
    LOCATION: "location",
    LOGITUDE: "longitude",
    LATITUDE: "latitude",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTORLANGUAGEINFO = {
  NAME: "d_language_info",
  COLUMNS: {
    ID: "id",
    LANGUAGE_NAME_ID: "language_name_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  DOCTORBASICINFO,
  DOCTOREDUCATIONINFO,
  DOCTORADDRESSINFO,
  DOCTORLANGUAGEINFO
};