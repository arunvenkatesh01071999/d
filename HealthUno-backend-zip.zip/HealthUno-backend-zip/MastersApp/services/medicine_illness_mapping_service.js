const MedicineIllnessMapping = require('../models/MedicineIllnessMappingModel');

const Get = async () => {
    let res;
    await MedicineIllnessMapping.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    let res;
    await MedicineIllnessMapping.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateMedicine = async (m_data) => {
    let res;
    await MedicineIllnessMapping.create(m_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const CreateMedicineMap = async (m_data) => {
    let res;
    await MedicineIllnessMapping.create(m_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateMedicine = async (id, m_data) => {
    let res;
    await MedicineIllnessMapping.update(m_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyMedicine = async (id) => {
    let res;
    await MedicineIllnessMapping.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const DestroyMedicineMap = async (id) => {
    let res;
    await MedicineIllnessMapping.destroy({ where: { medicine_master_id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateMedicineMap,
    DestroyMedicineMap
};
