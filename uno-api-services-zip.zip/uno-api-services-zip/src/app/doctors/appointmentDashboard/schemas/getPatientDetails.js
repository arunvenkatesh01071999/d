const { errorSchemas } = require("../../../commons/schemas/errorSchemas");




const getPatientDetailsSchema = {

  tags: ["GET PatientDetails"],
  summary: "This API is to get PatientDetails ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
      
        required: ['name', 'dob', 'gender_name', 'patient_id', 'mobile', 'appointment_from_time', 'appointment_to_time']
      }
    },
    ...errorSchemas
  }
};



module.exports = {

 
  getPatientDetailsSchema
};
