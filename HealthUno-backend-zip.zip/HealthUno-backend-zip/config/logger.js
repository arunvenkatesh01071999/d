const { createLogger, transports, format } = require('winston');
require('winston-mongodb');
require('dotenv').config();

const logger = createLogger({
    transports: [
        // new transports.File({
        //     filename:"log.txt",
        //     format:format.combine(format.timestamp(),format.json())
        // }),
        new transports.MongoDB({
            level: "info",
            db: process.env.LOGDB,
            collection: "log",
            options: { useUnifiedTopology: true },
            format: format.combine(format.timestamp(), format.json()),
        }),
        new transports.MongoDB({
            level: "error",
            db: process.env.LOGDB,
            collection: "log",
            options: { useUnifiedTopology: true },
            format: format.combine(format.timestamp(), format.json()),
        }),
        new transports.MongoDB({
            level: "warning",
            db: process.env.LOGDB,
            collection: "log",
            options: { useUnifiedTopology: true },
            format: format.combine(format.timestamp(), format.json()),
        })
    ]
})


module.exports = logger;

