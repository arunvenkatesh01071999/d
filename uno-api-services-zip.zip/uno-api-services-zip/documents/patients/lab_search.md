## Lab Search

Case 1: By symptoms Ex. chest pain, head ache

Case 2: By Illness (Disease) Ex. Dengu , Malria

Case 3: By Specality

Case 4: By Lab Name

## Logic:

1. List all Lab based on search case, and order by Location ASC (shortest should show first)
