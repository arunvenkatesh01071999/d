const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { LAB_TEST } = require("../commons/constants");
const { LAB_BASIC_INFO } = require("../commons/constants");
const { ACCREDATION } = require("../commons/constants");
const { LAB_SECTOR } = require("../commons/constants");
const { LAB_TYPE_MASTER } = require("../commons/constants");
const { LAB_TEST_PACK } = require("../commons/constants");
const { L_LAB_INFO } = require("../commons/constants");
const { CITIES } = require("../commons/constants");
const { STATES } = require("../commons/constants");
const { COUNTRIES } = require("../commons/constants");
const { LAB_ADDRESS_INFO } = require("../commons/constants");
const { LAB_CONTACT_INFO } = require("../commons/constants");
const { LAB_SERVICE } = require("../commons/constants");
const { LAB_SERVICE_INFO } = require("../commons/constants");
const { LAB_CART } = require("../commons/constants");
const { LAB_ORDER_MASTER } = require("../commons/constants");
const { LAB_ORDER_DETAILS } = require("../commons/constants");
const { PATIENT_INFO } = require("../commons/constants");
const { PATIENT_RECORD } = require("../commons/constants");
const { HEALTH_CARDS } = require("../commons/constants");

function ordersRepo(fastify) {
  async function placeOrder({
    logTrace,
    input: {
      patient_id,
      lab_id,
      payment_refno,
      appointment_time,
      appointment_date,
      order_mode,
      order_type,
      is_lab_or_home,
      home_address,
      lab_order_total,
      lab_order_total_savings,
      tests_cart_items_total,
      tests_cart_total_savings,
      pack_cart_items_total,
      packages_cart_total_savings,
      no_of_tests,
      no_of_packages,
      report_status,
      tests_cart_lines,
      tests_packages_cart_lines
    }
  }) {
    const knex = this;
    const query_insert = await knex(`${LAB_ORDER_MASTER.NAME}`)
      .returning("id")
      .insert({
        [LAB_ORDER_MASTER.COLUMNS.PATIENT_ID]: patient_id,
        [LAB_ORDER_MASTER.COLUMNS.LAB_ID]: lab_id,
        [LAB_ORDER_MASTER.COLUMNS.PAYMENT_REFNO]: payment_refno,
        [LAB_ORDER_MASTER.COLUMNS.APPOINTMENT_TIME]: appointment_time,
        [LAB_ORDER_MASTER.COLUMNS.APPOINTMENT_DATE]: appointment_date,
        [LAB_ORDER_MASTER.COLUMNS.ORDER_MODE]: order_mode,
        [LAB_ORDER_MASTER.COLUMNS.ORDER_TYPE]: order_type,
        [LAB_ORDER_MASTER.COLUMNS.LAB_ORDER_TOTAL]: lab_order_total,
        [LAB_ORDER_MASTER.COLUMNS.LAB_ORDER_TOTAL_SAVINGS]:
          lab_order_total_savings,
        [LAB_ORDER_MASTER.COLUMNS.TESTS_CART_ITEMS_TOTAL]:
          tests_cart_items_total,
        [LAB_ORDER_MASTER.COLUMNS.TESTS_CART_TOTAL_SAVINGS]:
          tests_cart_total_savings,
        [LAB_ORDER_MASTER.COLUMNS.PACK_CART_ITEMS_TOTAL]: pack_cart_items_total,
        [LAB_ORDER_MASTER.COLUMNS.PACKAGES_CART_TOTAL_SAVINGS]:
          packages_cart_total_savings,
        [LAB_ORDER_MASTER.COLUMNS.NO_OF_TESTS]: no_of_tests,
        [LAB_ORDER_MASTER.COLUMNS.NO_OF_PACKAGES]: no_of_packages,
        [LAB_ORDER_MASTER.COLUMNS.REPORT_STATUS]: report_status,
        [LAB_ORDER_MASTER.COLUMNS.IS_LAB_OR_HOME]: is_lab_or_home,
        [LAB_ORDER_MASTER.COLUMNS.HOME_ADDRESS]: home_address
      });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while placing the orders",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }
    const orders_id = response[0].id; // productId is auto-generated

    let insertedTests_cart_lines = false;
    let insertedPests_packages_cart_lines = false;

    console.log("tests_cart_lines : " + tests_cart_lines.length);
    console.log(
      "tests_packages_cart_lines :" + tests_packages_cart_lines.length
    );
    if (tests_cart_lines.length > 0) {
      const _tests_cart_lines = tests_cart_lines.map(testsorderline => ({
        [LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID]: orders_id,
        [LAB_ORDER_DETAILS.COLUMNS.PATIENT_ID]: patient_id,
        [LAB_ORDER_DETAILS.COLUMNS.LAB_ID]: lab_id,
        [LAB_ORDER_DETAILS.COLUMNS.LAB_TEST_ID]: testsorderline.lab_test_id,
        [LAB_ORDER_DETAILS.COLUMNS.LAB_PACKAGE_ID]: 0,
        [LAB_ORDER_DETAILS.COLUMNS.IS_TEST_OR_PACKAGE]: 0,
        [LAB_ORDER_DETAILS.COLUMNS.TESTS_COST]: testsorderline.cost,
        [LAB_ORDER_DETAILS.COLUMNS.TESTS_DISCOUNT]: testsorderline.discount,
        [LAB_ORDER_DETAILS.COLUMNS.TESTS_CART_ITEMS_TOTAL]:
          testsorderline.tests_cart_items_total,
        [LAB_ORDER_DETAILS.COLUMNS.TESTS_CART_TOTAL_SAVINGS]:
          testsorderline.test_cart_items_total_savings,
        [LAB_ORDER_DETAILS.COLUMNS.PACK_COST]: 0,
        [LAB_ORDER_DETAILS.COLUMNS.PACK_OFFER_PERCENT]: 0,
        [LAB_ORDER_DETAILS.COLUMNS.PACK_CART_ITEMS_TOTAL]: 0,
        [LAB_ORDER_DETAILS.COLUMNS.PACKAGES_CART_TOTAL_SAVINGS]: 0
      }));
      insertedTests_cart_lines = await knex(`${LAB_ORDER_DETAILS.NAME}`).insert(
        _tests_cart_lines
      );
    } else {
      insertedTests_cart_lines = true;
    }
    if (tests_packages_cart_lines.length > 0) {
      const _tests_packages_cart_lines = tests_packages_cart_lines.map(
        packageorderline => ({
          [LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID]: orders_id,
          [LAB_ORDER_DETAILS.COLUMNS.PATIENT_ID]: patient_id,
          [LAB_ORDER_DETAILS.COLUMNS.LAB_ID]: lab_id,
          [LAB_ORDER_DETAILS.COLUMNS.LAB_TEST_ID]: 0,
          [LAB_ORDER_DETAILS.COLUMNS.LAB_PACKAGE_ID]:
            packageorderline.lab_package_id,
          [LAB_ORDER_DETAILS.COLUMNS.IS_TEST_OR_PACKAGE]: 1,
          [LAB_ORDER_DETAILS.COLUMNS.TESTS_COST]: 0,
          [LAB_ORDER_DETAILS.COLUMNS.TESTS_DISCOUNT]: 0,
          [LAB_ORDER_DETAILS.COLUMNS.TESTS_CART_ITEMS_TOTAL]: 0,
          [LAB_ORDER_DETAILS.COLUMNS.TESTS_CART_TOTAL_SAVINGS]: 0,
          [LAB_ORDER_DETAILS.COLUMNS.PACK_COST]: packageorderline.cost,
          [LAB_ORDER_DETAILS.COLUMNS.PACK_OFFER_PERCENT]:
            packageorderline.offer_percent,
          [LAB_ORDER_DETAILS.COLUMNS.PACK_CART_ITEMS_TOTAL]:
            packageorderline.pack_cart_items_total,
          [LAB_ORDER_DETAILS.COLUMNS.PACKAGES_CART_TOTAL_SAVINGS]:
            packageorderline.pack_cart_items_total_savings
        })
      );
      insertedPests_packages_cart_lines = await knex(
        `${LAB_ORDER_DETAILS.NAME}`
      ).insert(_tests_packages_cart_lines);
    } else {
      insertedPests_packages_cart_lines = true;
    }

    if (!insertedTests_cart_lines && !insertedPests_packages_cart_lines) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Order Details",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }
    if (insertedTests_cart_lines && insertedPests_packages_cart_lines) {
      const query_delete = knex(LAB_CART.NAME)
        .delete()
        .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
        .where(LAB_CART.COLUMNS.LAB_ID, lab_id);

      await query_delete;
    }
    if (order_mode == 2) {
      const knex = fastify.knexPatient;
      const checkBalance = await knex(`${PATIENT_INFO.NAME}`).where(
        `${PATIENT_INFO.COLUMNS.ID}`,
        patient_id
      ); // Assuming it returns a single result
      if (checkBalance.length > 0) {
        const currentBalance = checkBalance[0].wallet_amt;
        const updateBalance =
          currentBalance - (lab_order_total - lab_order_total_savings);
        const query2 = await knex(`${PATIENT_INFO.NAME}`)
          .where(`${PATIENT_INFO.COLUMNS.ID}`, patient_id)
          .update({
            [PATIENT_INFO.COLUMNS.WALLET_AMT]: updateBalance
          });
      }
    }
    if (order_mode == 3) {
      const knex = fastify.knexPatient;
      const checkBalance = await knex(`${PATIENT_INFO.NAME}`).where(
        `${PATIENT_INFO.COLUMNS.ID}`,
        patient_id
      ); // Assuming it returns a single result
      if (checkBalance.length > 0) {
        const currentBalance = checkBalance[0].card_balance;
        const updateBalance =
          currentBalance - (lab_order_total - lab_order_total_savings);
        const query2 = await knex(`${PATIENT_INFO.NAME}`)
          .where(`${PATIENT_INFO.COLUMNS.ID}`, patient_id)
          .update({
            [PATIENT_INFO.COLUMNS.CARD_BALANCE]: updateBalance
          });
      }
    }
    return {
      success: true,
      message: "Your order has been placed successfully",
      order_number: orders_id
    };
  }
  async function getOrder({ body, logTrace, params }) {
    let page_size = params.page_size;
    let current_page = params.current_page;
    let patient_id = params.patient_id;
    // let lab_id = params.lab_id;

    const knex = this;
    const response = await knex.transaction(async trx => {
      // Fetch products
      const query = knex
        .select([
          `${LAB_ORDER_MASTER.NAME}.*`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_NAME}`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_IMAGE}`,
          `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ACCREDATION_NAME}`
        ])
        .from(`${LAB_ORDER_MASTER.NAME} as ${LAB_ORDER_MASTER.NAME}`)
        .leftJoin(
          `${LAB_BASIC_INFO.NAME} as ${LAB_BASIC_INFO.NAME}`,
          `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.LAB_ID}`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ID}`
        )
        .leftJoin(
          `${ACCREDATION.NAME} as ${ACCREDATION.NAME}`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ACCREDATION_ID}`,
          `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ID}`
        );

      // .where(
      //   `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.LAB_ID}`,
      //   lab_id
      // );
      if (patient_id) {
        query.where(function () {
          this.where(
            `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.PATIENT_ID}`,
            patient_id
          );
        });
      }
      logQuery({
        logger: fastify.log,
        query,
        context: "Get orders list details",
        logTrace
      });

      const orders = await query
        .orderBy(LAB_ORDER_MASTER.COLUMNS.ID, "DESC")
        .paginate({
          pageSize: page_size, // Customize as needed
          currentPage: current_page // Customize as needed
        });
      if (orders.meta.pagination.total_pages < current_page) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_ACCEPTABLE,
          message: "Requested page is beyond the available data",
          property: "",
          code: "NOT_ACCEPTABLE"
        });
      }
      if (!orders.data.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Orders not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      const orderdetails = await Promise.all(
        orders.data.map(async order => {
          const tests_cart_lines = await trx(LAB_ORDER_DETAILS.NAME)
            .join(
              `${L_LAB_INFO.NAME} as ${L_LAB_INFO.NAME}`,
              `${LAB_ORDER_DETAILS.NAME}.${LAB_ORDER_DETAILS.COLUMNS.LAB_TEST_ID}`,
              `${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.LAB_TEST_ID}`
            )
            .join(
              `${LAB_TEST.NAME} as ${LAB_TEST.NAME}`,
              `${LAB_ORDER_DETAILS.NAME}.${LAB_ORDER_DETAILS.COLUMNS.LAB_TEST_ID}`,
              `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.ID}`
            )
            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID, order.id)
            .where(LAB_ORDER_DETAILS.COLUMNS.IS_TEST_OR_PACKAGE, 0)
            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ID, order.lab_id)
            .where(L_LAB_INFO.COLUMNS.LAB_NAME_ID, order.lab_id)
            .select(
              `${LAB_ORDER_DETAILS.NAME}.*`,
              `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.TEST_NAME}`
            );
          const tests_packages_cart_lines = await trx(LAB_ORDER_DETAILS.NAME)
            .join(
              `${LAB_TEST_PACK.NAME} as ${LAB_TEST_PACK.NAME}`,
              `${LAB_ORDER_DETAILS.NAME}.${LAB_ORDER_DETAILS.COLUMNS.LAB_PACKAGE_ID}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.ID}`
            )

            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID, order.id)
            .where(LAB_ORDER_DETAILS.COLUMNS.IS_TEST_OR_PACKAGE, 1)
            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ID, order.lab_id)
            .where(LAB_TEST_PACK.COLUMNS.LAB_NAME_ID, order.lab_id)
            .select(
              `${LAB_ORDER_DETAILS.NAME}.*`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.COST}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.OFFER_PERCENT}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.LAB_PACK_NAME}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.LAB_TEST_ID}`
            );

          return {
            ...order,
            tests_cart_lines,
            tests_packages_cart_lines
          };
        })
      );

      return {
        data: orderdetails,
        meta: orders.meta
      };
    });

    return response;
  }
  async function OrderStatusChange({ body, params, logTrace }) {
    const knex = this;
    const query = knex(LAB_ORDER_MASTER.NAME).where(
      LAB_ORDER_MASTER.COLUMNS.ID,
      body.order_id
    );

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Orders not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${LAB_ORDER_MASTER.NAME}`)
      .where(`${LAB_ORDER_MASTER.COLUMNS.ID}`, body.order_id)
      .update({
        [LAB_ORDER_MASTER.COLUMNS.REPORT_STATUS]: body.status
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating Order Status",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true, message: "order staus has been changed" };
  }
  async function getOrderStatus({ params, logTrace }) {
    const knex = this;

    let patient_id = params.patient_id;
    let lab_id = params.lab_id;

    const query = knex(LAB_ORDER_MASTER.NAME)
      .select([
        LAB_ORDER_MASTER.COLUMNS.REPORT_STATUS,
        knex.raw("count(*) as count")
      ])
      .where(
        `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.LAB_ID}`,
        lab_id
      )
      .groupBy(LAB_ORDER_MASTER.COLUMNS.REPORT_STATUS)
      .orderBy(LAB_ORDER_MASTER.COLUMNS.REPORT_STATUS);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get order status count",
      logTrace
    });
    if (patient_id) {
      query.where(function () {
        this.where(
          `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.PATIENT_ID}`,
          patient_id
        );
      });
    }
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Order status not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getAdminOrder({ body, logTrace, params }) {
    let page_size = params.page_size;
    let current_page = params.current_page;
    let patient_id = params.patient_id;
    let lab_id = params.lab_id;

    const knex = this;
    const response = await knex.transaction(async trx => {
      // Fetch products
      const query = knex
        .select([
          `${LAB_ORDER_MASTER.NAME}.*`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_NAME}`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.LAB_IMAGE}`,
          `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ACCREDATION_NAME}`
        ])
        .from(`${LAB_ORDER_MASTER.NAME} as ${LAB_ORDER_MASTER.NAME}`)
        .leftJoin(
          `${LAB_BASIC_INFO.NAME} as ${LAB_BASIC_INFO.NAME}`,
          `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.LAB_ID}`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ID}`
        )
        .leftJoin(
          `${ACCREDATION.NAME} as ${ACCREDATION.NAME}`,
          `${LAB_BASIC_INFO.NAME}.${LAB_BASIC_INFO.COLUMNS.ACCREDATION_ID}`,
          `${ACCREDATION.NAME}.${ACCREDATION.COLUMNS.ID}`
        )

        .where(
          `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.LAB_ID}`,
          lab_id
        );
      if (patient_id) {
        query.where(function () {
          this.where(
            `${LAB_ORDER_MASTER.NAME}.${LAB_ORDER_MASTER.COLUMNS.PATIENT_ID}`,
            patient_id
          );
        });
      }
      logQuery({
        logger: fastify.log,
        query,
        context: "Get orders list details",
        logTrace
      });

      const orders = await query
        .orderBy(LAB_ORDER_MASTER.COLUMNS.ID, "DESC")
        .paginate({
          pageSize: page_size, // Customize as needed
          currentPage: current_page // Customize as needed
        });
      if (orders.meta.pagination.total_pages < current_page) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_ACCEPTABLE,
          message: "Requested page is beyond the available data",
          property: "",
          code: "NOT_ACCEPTABLE"
        });
      }
      if (!orders.data.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Orders not found",
          property: "",
          code: "NOT_FOUND"
        });
      }

      const orderdetails = await Promise.all(
        orders.data.map(async order => {
          const tests_cart_lines = await trx(LAB_ORDER_DETAILS.NAME)
            .join(
              `${L_LAB_INFO.NAME} as ${L_LAB_INFO.NAME}`,
              `${LAB_ORDER_DETAILS.NAME}.${LAB_ORDER_DETAILS.COLUMNS.LAB_TEST_ID}`,
              `${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.LAB_TEST_ID}`
            )
            .join(
              `${LAB_TEST.NAME} as ${LAB_TEST.NAME}`,
              `${LAB_ORDER_DETAILS.NAME}.${LAB_ORDER_DETAILS.COLUMNS.LAB_TEST_ID}`,
              `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.ID}`
            )
            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID, order.id)
            .where(LAB_ORDER_DETAILS.COLUMNS.IS_TEST_OR_PACKAGE, 0)
            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ID, order.lab_id)
            .where(L_LAB_INFO.COLUMNS.LAB_NAME_ID, order.lab_id)
            .select(
              `${LAB_ORDER_DETAILS.NAME}.*`,
              `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.TEST_NAME}`
            );
          const tests_packages_cart_lines = await trx(LAB_ORDER_DETAILS.NAME)
            .join(
              `${LAB_TEST_PACK.NAME} as ${LAB_TEST_PACK.NAME}`,
              `${LAB_ORDER_DETAILS.NAME}.${LAB_ORDER_DETAILS.COLUMNS.LAB_PACKAGE_ID}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.ID}`
            )

            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID, order.id)
            .where(LAB_ORDER_DETAILS.COLUMNS.IS_TEST_OR_PACKAGE, 1)
            .where(LAB_ORDER_DETAILS.COLUMNS.LAB_ID, order.lab_id)
            .where(LAB_TEST_PACK.COLUMNS.LAB_NAME_ID, order.lab_id)
            .select(
              `${LAB_ORDER_DETAILS.NAME}.*`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.COST}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.OFFER_PERCENT}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.LAB_PACK_NAME}`,
              `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.LAB_TEST_ID}`
            );

          return {
            ...order,
            tests_cart_lines,
            tests_packages_cart_lines
          };
        })
      );

      return {
        data: orderdetails,
        meta: orders.meta
      };
    });

    return response;
  }
  async function getPatientInfo({ patient_id, logTrace }) {
    const knex = fastify.knexPatient;

    const query = knex(PATIENT_INFO.NAME).where(
      PATIENT_INFO.COLUMNS.ID,
      patient_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get patient details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "patient not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function OrderReportStatusChange({
    body,
    input: { patient_id, order_details_id, order_id, fullUrl }
  }) {
    const knex = this;
    const query = knex(LAB_ORDER_DETAILS.NAME).where(
      LAB_ORDER_DETAILS.COLUMNS.ID,
      order_details_id
    );

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Orders not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${LAB_ORDER_DETAILS.NAME}`)
      .where(`${LAB_ORDER_DETAILS.COLUMNS.ID}`, order_details_id)
      .where(`${LAB_ORDER_DETAILS.COLUMNS.LAB_ORDER_ID}`, order_id)
      .where(`${LAB_ORDER_DETAILS.COLUMNS.PATIENT_ID}`, patient_id)
      .update({
        [LAB_ORDER_DETAILS.COLUMNS.LAB_REPORT_STATUS_LINK]: fullUrl
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating Order Report Status",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return {
      message: "Report uploaded successfully",
      image_url: fullUrl
    };
  }
  async function insertPatientRecord({
    logTrace,
    patient_id,
    doctor_id,
    fullUrl
  }) {
    const knex = fastify.knexPatient;
    const query = await knex(`${PATIENT_RECORD.NAME}`).insert({
      [PATIENT_RECORD.COLUMNS.PATIENT_ID]: patient_id,
      [PATIENT_RECORD.COLUMNS.DOCTOR_ID]: doctor_id,
      [PATIENT_RECORD.COLUMNS.FILE_PATH]: fullUrl,
      [PATIENT_RECORD.COLUMNS.FILE_FLAG]: 5
    });

    const response = await query;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while inserting record",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return {
      success: true,
      message: "Your recored inserted successfully"
    };
  }
  async function uploadPastReport({
    logTrace,
    patient_id,
    doctor_id,
    fullUrl,
    file_flag
  }) {
    const knex = fastify.knexPatient;
    const query = await knex(`${PATIENT_RECORD.NAME}`).insert({
      [PATIENT_RECORD.COLUMNS.PATIENT_ID]: patient_id,
      [PATIENT_RECORD.COLUMNS.DOCTOR_ID]: doctor_id,
      [PATIENT_RECORD.COLUMNS.FILE_PATH]: fullUrl,
      [PATIENT_RECORD.COLUMNS.FILE_FLAG]: file_flag
    });

    const response = await query;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while inserting record",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return {
      success: true,
      message: "Your recored inserted successfully",
      image_url: fullUrl
    };
  }
  
  async function getHealthCard({ patient_id, logTrace }) {
    const knex = fastify.knexPatient;
    const query = knex(HEALTH_CARDS.NAME)
      .where(HEALTH_CARDS.COLUMNS.PATIENT_ID, patient_id)
      .where(HEALTH_CARDS.COLUMNS.ACTIVE, 1);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Card Masters info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }
  return {
    placeOrder,
    getOrder,
    OrderStatusChange,
    getOrderStatus,
    getAdminOrder,
    getPatientInfo,
    OrderReportStatusChange,
    insertPatientRecord,
    uploadPastReport,
    getHealthCard
  };
}

module.exports = ordersRepo;
