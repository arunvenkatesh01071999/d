const getFinalDiagnosisSchema = require("./getFinalDiagnosis");

module.exports = {
  getFinalDiagnosisSchema
};
