const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const availability_service = require('../services/availability_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/doctor_addCheck_service');


const FetchAvailability = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await availability_service.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {

        await availability_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_availability_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}


const NewAvailability = async (req, res, next) => {

    const { second_option_id, doctor_name_id, period_id, fees_id,
        inst_time, inst_consult, avail_chat, avail_consult, active } = req.body;
    created_by = req.user.id;
    updated_by = req.user.id;
    const addCheck = 11;
    const query = AddCheck(req.body.doctor_name_id);

    if (doctor_name_id) {
        s_data = {
            second_option_id: parseInt(second_option_id),
            doctor_name_id: parseInt(doctor_name_id),
            period_id: period_id,
            fees_id: fees_id,
            inst_time: inst_time,
            inst_consult: inst_consult,
            avail_chat: avail_chat,
            avail_consult: avail_consult,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        console.log(s_data)
        await availability_service.GetId(doctor_name_id)
            .then(basic_data => {
                if (basic_data.length > 0) {
                    msg = " Id Already exists ";
                    return res.status(400).json(failure_func(msg))
                } else {
                    availability_service.CreateAvailabilityInfo(s_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                logger.info(msg);
                                res.status(400).json(failure_func(msg))
                            } else {
                                availability_service.GetId(doctor_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully"
                                        cache.DEL(req.user.id + '_availability_service')
                                        res.status(200).json(success_func(datas))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "second_option_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateAvailability = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const { second_option_id, doctor_name_id, period_id, fees_id,
            inst_time, inst_consult, avail_chat, avail_consult, active } = req.body;

        updated_by = req.user.id;
        updated_at = date();
        if (doctor_name_id) {
            s_data = {
                second_option_id: second_option_id,
                doctor_name_id: doctor_name_id,
                period_id: period_id,
                fees_id: fees_id,
                inst_time: inst_time,
                inst_consult: inst_consult,
                avail_chat: avail_chat,
                avail_consult: avail_consult,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await availability_service.UpdateAvailabilityInfo(id, s_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_availability_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "doctor_name_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteAvailability = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await availability_service.DeleteAvailabilityInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_availability_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    NewAvailability,
    FetchAvailability,
    UpdateAvailability,
    DeleteAvailability
}