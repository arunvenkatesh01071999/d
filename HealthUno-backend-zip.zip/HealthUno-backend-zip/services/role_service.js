const Role = require('../models/RoleModel');
const Services = require('../models/ServiceModel');

const Get = async () => {
    await Role.findAll({ include: [Services] })
        .then(roles => {
            res = roles
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await Role.findAll({ include: [Services], where: { id: id } })
        .then(roles => {
            res = roles
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateRole = async (role_name, active, service_id, created_by, updated_by) => {
    await Role.create({ role_name: role_name, active: active, service_id: service_id, created_by: created_by, updated_by: updated_by })
        .then(role => {
            res = role
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateRole = async (id, data) => {
    await Role.update(data, { where: { id: id }, individualHooks: true })
        .then(role => {
            res = role[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyRole = async (id) => {
    await Role.destroy({ where: { id: id }, individualHooks: true })
        .then(role => {
            res = role
        }).catch(err => {
            res = err
        })
    return res
}
const GetbyModuleId = async (id) => {
    await Role.findAll({ include: [Services], where: { service_id: id } })
        .then(roles => {
            res = roles
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await Role.findAll({ where: { role_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateRole,
    UpdateRole,
    DestroyRole,
    GetbyModuleId
};
