const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
    fastify.route({
        method: "GET",
        url: "/d-account-details",
        // preHandler: fastify.authenticate,
        schema: schemas.getAccounDetailInfo.getAccountGetInfoSchema,
        handler: handlers.getAccounDetailInfo.getAccounDetailInfoHandler(fastify)
    });

    fastify.route({
        method: "GET",
        url: "/d-account-details/:doctor_id",
        // preHandler: fastify.authenticate,
        // schema: schemas.getAccounDetailInfo.getAccountGetInfoSchema,
        handler: handlers.getAccounDetailInfo.getAccounDetailInfoByIdHandler(fastify)
    });

    fastify.route({
        method: "POST",
        url: "/d-account-details",
        schema: schemas.getAccounDetailInfo.getAccountPostInfoSchema,
        handler: handlers.getAccounDetailInfo.getAccounDetailPostInfoHandler(fastify),
        // preHandler: fastify.authenticate
    });

    fastify.route({
        method: "PUT",
        url: "/d-account-details/:doctor_id",
        // preHandler: fastify.authenticate, // Apply JWT authentication decorator
        schema: schemas.getAccounDetailInfo.getAccountPutInfoSchema,
        handler: handlers.getAccounDetailInfo.getAccounDetailPutInfoHandler(fastify)
    });

    fastify.route({
        method: "DELETE",
        url: "/d-account-details/:id",
        // preHandler: fastify.authenticate,
        schema: schemas.getAccounDetailInfo.getDeleteAccountInfoSchema,
        handler: handlers.getAccounDetailInfo.getAccounDetailDeleteInfoHandler(fastify)
    });
};
