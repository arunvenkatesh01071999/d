const getScanByLabService = require("../services/getScanByLabService");

function getScanByLabHandler(fastify) {
  const getScanByLab = getScanByLabService.getScanByLabService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getScanByLab({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getScanByLabHandler;
