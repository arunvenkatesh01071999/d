const geteduInfos = require("../services/geteduInfoservices");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream");
const { log } = require("console");
// const pump = util.promisify(pipeline);


function geteduInfoHandler(fastify) {
  const geteduInfo =
    geteduInfos.getalleduService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function geteduInfoByIdHandler(fastify) {
  const geteduInfo =
    geteduInfos.getByIdeduService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

// function getedupostInfoHandler(fastify) {
//   const geteduInfo =
//     geteduInfos.getPosteduService(fastify);

//   return async (request, reply) => {
//     // const partes = request.body.qua_certificate_path;
//     // const partes_file = request.body.specialized_file;
//     // const partes_reg_file = request.body.certificate_path;


//     const originalObject = request.body;

//     const convertedData = {};

//     for (const key in originalObject) {

//       if (Object.hasOwnProperty.call(originalObject, key)) {
//         convertedData[key] = originalObject[key].value;
//       }

//     }

//     // if (partes.filename == '') {
//     //   convertedData[partes.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
//     //   convertedData[partes.fieldname] = partes.filename;

//     // }


//     // if (partes_file.filename == '') {
//     //   convertedData[partes_file.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes_file.file, fs.createWriteStream(`./uploads/${partes_file.filename}`));
//     //   convertedData[partes_file.fieldname] = partes_file.filename;

//     // }


//     // if (partes_reg_file.filename == '') {
//     //   convertedData[partes_reg_file.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes_reg_file.file, fs.createWriteStream(`./uploads/${partes_reg_file.filename}`));
//     //   convertedData[partes_reg_file.fieldname] = partes_reg_file.filename;

//     // }



//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await geteduInfo({
//       body,
//       params,
//       logTrace,
//       convertedData,
//       userDetails
//     });
//     return reply.code(200).send(response);
//   };
// // }

function getedupostInfoHandler(fastify) {
  const geteduInfo =
    geteduInfos.getPosteduService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



// function geteduputInfoHandler(fastify) {
//   const geteduInfo =
//     geteduInfos.getPuteduService(fastify);

//   return async (request, reply) => {
//     // const partes = request.body.qua_certificate_path;
//     // const partes_file = request.body.specialized_file;
//     // const partes_reg_file = request.body.certificate_path;
//     const originalObject = request.body;

//     const convertedData = {};

//     for (const key in originalObject) {

//       if (Object.hasOwnProperty.call(originalObject, key)) {
//         convertedData[key] = originalObject[key].value;
//       }
//     }

//     // if (partes.filename == '') {
//     //   convertedData[partes.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
//     //   convertedData[partes.fieldname] = partes.filename;

//     // }

//     // if (partes_file.filename == '') {
//     //   convertedData[partes_file.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes_file.file, fs.createWriteStream(`./uploads/${partes_file.filename}`));
//     //   convertedData[partes_file.fieldname] = partes_file.filename;
//     // }

//     // if (partes_reg_file.filename == '') {
//     //   convertedData[partes_reg_file.fieldname] = 'null';
//     // }
//     // else {
//     //   pump(partes_reg_file.file, fs.createWriteStream(`./uploads/${partes_reg_file.filename}`));
//     //   convertedData[partes_reg_file.fieldname] = partes_reg_file.filename;

//     // }



//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await geteduInfo({
//       body,
//       params,
//       logTrace,
//       convertedData,
//       userDetails
//     });
//     return reply.code(200).send(response);
//   };
// }

function geteduputInfoHandler(fastify) {
  const geteduInfo =
    geteduInfos.getPuteduService(fastify);

  return async (request, reply) => {
   
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getedudeleteInfoHandler(fastify) {
  const geteduInfo =
    geteduInfos.getDeleteeduService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getGenerateotp(fastify) {
  const geteduInfo =
    geteduInfos.getGenerateotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getGenerateotp(fastify) {
  const geteduInfo =
    geteduInfos.getGenerateotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function checkotp(fastify) {
  const geteduInfo =
    geteduInfos.getcheckotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await geteduInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = {
  geteduInfoHandler,
  geteduInfoByIdHandler,
  getedupostInfoHandler,
  geteduputInfoHandler,
  getedudeleteInfoHandler,
  getGenerateotp,
  checkotp

};
