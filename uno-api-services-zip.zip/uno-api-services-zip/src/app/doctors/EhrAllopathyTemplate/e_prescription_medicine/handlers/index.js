const getPrescriptionMedicineHandler = require("./getPrescriptionMedicineHandler.js");

module.exports = {
  getPrescriptionMedicineHandler
};
