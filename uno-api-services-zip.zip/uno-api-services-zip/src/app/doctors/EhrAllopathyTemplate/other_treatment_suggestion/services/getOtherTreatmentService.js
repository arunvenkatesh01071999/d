const getOtherTreatmentRepository = require("../repository/getOtherTreatmentRepository");



function getOtherTreatmentInfoService(fastify) {
  
  const { OtherTreatmentGetAlls } = getOtherTreatmentRepository.getOtherTreatmentRepository(fastify);
  
  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = OtherTreatmentGetAlls.call(knex, {
      logTrace
    });
    const [getOtherTreatmentAlldata] = await Promise.all([promise1]);
    return getOtherTreatmentAlldata;
  }
}




module.exports = {

 
 getOtherTreatmentInfoService
 
};
