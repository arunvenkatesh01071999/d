const doctorBasicInfoRepo = require("../repository/getLoginInfo");
const otpGenerator = require("otp-generator");

function doctorLoginService(fastify) {
  const { getdoctorLogin } = doctorBasicInfoRepo.doctorLogin(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getdoctorLogin.call(knex, {
      phone_no: body.phone_no,
      logTrace,
      body
    });

    const [getlogindata] = await Promise.all([response]);
    return getlogindata;
  };
}

function doctorLogincheckService(fastify) {
  const { getdoctorLoginCheck } = doctorBasicInfoRepo.doctorLogincheck(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getdoctorLoginCheck.call(knex, {
      body,
      logTrace
    });

    const [getlogindata] = await Promise.all([response]);
    return getlogindata;
  };
}
module.exports = { doctorLoginService, doctorLogincheckService };
