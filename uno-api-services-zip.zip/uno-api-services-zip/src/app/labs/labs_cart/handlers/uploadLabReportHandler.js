const getOrderService = require("../services/getOrderServices");

function uploadLabReportHandler(fastify) {
  const uploadLabReport = getOrderService.uploadLabReportService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await uploadLabReport({ body, logTrace, request, reply });
    return reply.code(200).send(response);
  };
}

module.exports = uploadLabReportHandler;
