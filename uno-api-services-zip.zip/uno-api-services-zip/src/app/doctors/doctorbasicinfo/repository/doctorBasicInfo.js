const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORBASICINFO } = require("../commons/constants");
const { DOCTOREDUCATIONINFO } = require("../commons/constants");
const { DOCTORADDRESSINFO } = require("../commons/constants");
const { DOCTORLANGUAGEINFO } = require("../commons/constants");
const { GENDER } = require("../../../masterData/commons/constants");
const { SPECIALITIES } = require("../../../masterData/commons/constants");
const { CITIES } = require("../../../masterData/commons/constants");
const { STATES } = require("../../../masterData/commons/constants");
const { COUNTRIES } = require("../../../masterData/commons/constants");
const { LANGUAGES } = require("../../../masterData/commons/constants");
const { CustomError } = require("../../../errorHandler");
const {
  QUALIFICATIONMASTER
} = require("../../../masterData/commons/constants");

function doctorBasicInfoRepo(fastify) {
  async function getDoctorBasicInfo({ doctor_id, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${DOCTORBASICINFO.NAME}.*`,
        `${GENDER.NAME}.${GENDER.COLUMNS.GENDER_NAME}`
      ])
      .from(`${DOCTORBASICINFO.NAME} as ${DOCTORBASICINFO.NAME}`)
      .leftJoin(
        `${GENDER.NAME} as ${GENDER.NAME}`,
        `${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.GENDER_ID}`,
        `${GENDER.NAME}.${GENDER.COLUMNS.ID}`
      )
      .where(`${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.ACTIVE}`, 1)
      .where(
        `${DOCTORBASICINFO.NAME}.${DOCTORBASICINFO.COLUMNS.ID}`,
        doctor_id
      );

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get doctor details",
    //   logTrace
    // });

    const response = await query;
    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Doctor info not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }
    return response[0];
  }
  async function getDoctorEducationInfo({ doctor_id, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${DOCTOREDUCATIONINFO.NAME}.*`,
        `${QUALIFICATIONMASTER.NAME}.${QUALIFICATIONMASTER.COLUMNS.QUALIFICATION}`
      ])
      .from(`${DOCTOREDUCATIONINFO.NAME} as ${DOCTOREDUCATIONINFO.NAME}`)
      .leftJoin(
        `${QUALIFICATIONMASTER.NAME} as ${QUALIFICATIONMASTER.NAME}`,
        `${DOCTOREDUCATIONINFO.NAME}.${DOCTOREDUCATIONINFO.COLUMNS.QUALIFICATION_NAME_ID}`,
        `${QUALIFICATIONMASTER.NAME}.${QUALIFICATIONMASTER.COLUMNS.ID}`
      )
      .where(
        `${DOCTOREDUCATIONINFO.NAME}.${DOCTOREDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID}`,
        doctor_id
      );

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get doctor education info details",
    //   logTrace
    // });

    const response = await query;

    return response;
  }
  async function getDoctorAddressInfo({ doctor_id, logTrace }) {
    const knex = this;

    const query = knex
      .select([
        `${DOCTORADDRESSINFO.NAME}.*`,
        `${CITIES.NAME}.${CITIES.COLUMNS.CITYNAME}`,
        `${STATES.NAME}.${STATES.COLUMNS.NAME} as state_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.NAME} as country_name`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.PHONECODE} as phonecode`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.SHORTNAME}`
      ])
      .from(`${DOCTORADDRESSINFO.NAME} as ${DOCTORADDRESSINFO.NAME}`)
      .leftJoin(
        `${CITIES.NAME} as ${CITIES.NAME}`,
        `${DOCTORADDRESSINFO.NAME}.${DOCTORADDRESSINFO.COLUMNS.CITYID}`,
        `${CITIES.NAME}.${CITIES.COLUMNS.ID}`
      )
      .leftJoin(
        `${STATES.NAME} as ${STATES.NAME}`,
        `${DOCTORADDRESSINFO.NAME}.${DOCTORADDRESSINFO.COLUMNS.STATEID}`,
        `${STATES.NAME}.${STATES.COLUMNS.ID}`
      )
      .leftJoin(
        `${COUNTRIES.NAME} as ${COUNTRIES.NAME}`,
        `${DOCTORADDRESSINFO.NAME}.${DOCTORADDRESSINFO.COLUMNS.COUNTRYID}`,
        `${COUNTRIES.NAME}.${COUNTRIES.COLUMNS.ID}`
      )

      .where(DOCTORADDRESSINFO.COLUMNS.DOCTOR_NAME_ID, doctor_id);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get doctor education info details",
    //   logTrace
    // });

    const response = await query;

    return response;
  }
  async function getDoctorLanguageInfo({ doctor_id, logTrace }) {
    const knex = this;

    const query = knex
      .select([`${LANGUAGES.NAME}.*`])
      .from(`${DOCTORLANGUAGEINFO.NAME} as ${DOCTORLANGUAGEINFO.NAME}`)
      .leftJoin(
        `${LANGUAGES.NAME} as ${LANGUAGES.NAME}`,
        `${DOCTORLANGUAGEINFO.NAME}.${DOCTORLANGUAGEINFO.COLUMNS.LANGUAGE_NAME_ID}`,
        `${LANGUAGES.NAME}.${LANGUAGES.COLUMNS.ID}`
      )
      .where(
        `${DOCTORLANGUAGEINFO.NAME}.${DOCTORLANGUAGEINFO.COLUMNS.DOCTOR_NAME_ID}`,
        doctor_id
      );

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get doctor education info details",
    //   logTrace
    // });

    const response = await query;

    return response;
  }

  async function doctorLogins({ mobile, logTrace }) {
    const knex = this;
    const query = knex(DOCTORBASICINFO.NAME)
      .select(
        DOCTORBASICINFO.COLUMNS.ID,
        DOCTORBASICINFO.COLUMNS.EMAIL,
        DOCTORBASICINFO.COLUMNS.PHONE_NO,
        DOCTORBASICINFO.COLUMNS.DOB
      )
      .where(DOCTORBASICINFO.COLUMNS.PHONE_NO, mobile)
      .where(DOCTORBASICINFO.COLUMNS.ACTIVE, "1");

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get doctor login info",
    //   logTrace
    // });
    const response = await query;
    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Customer not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }
    return response[0];
  }

  return {
    getDoctorBasicInfo,
    doctorLogins,
    getDoctorEducationInfo,
    getDoctorAddressInfo,
    getDoctorLanguageInfo
  };
}

module.exports = doctorBasicInfoRepo;