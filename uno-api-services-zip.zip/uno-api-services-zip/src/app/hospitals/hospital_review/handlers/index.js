const postHospitalReviewHandler = require("./postHospitalReviewHandler");
const getHospitalReviewHandler = require("./getHospitalReviewHandler");
const getHospitalAdminReviewHandler = require("./getHospitalAdminReviewHandler");
const postDisableHospitalReviewHandler = require("./postDisableHospitalReviewHandler");

module.exports = {
  postHospitalReviewHandler,
  getHospitalReviewHandler,
  getHospitalAdminReviewHandler,
  postDisableHospitalReviewHandler
};
