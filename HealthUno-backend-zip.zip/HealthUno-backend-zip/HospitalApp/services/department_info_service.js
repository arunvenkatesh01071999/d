const DepartmentInfo = require('../models/DepartmentInfoModel');
const DepartmentMasterModel = require('../../MastersApp/models/DepartmentMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const Get = async () => {
    await DepartmentInfo.findAll({ include: [DepartmentMasterModel, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await DepartmentInfo.findAll({ where: { hospital_name_id: hospital_name_id }, include: [DepartmentMasterModel, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await DepartmentInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateDepartmentInfo = async (s_data) => {
    await DepartmentInfo.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateDepartmentInfo = async (s_data) => {
//     await DepartmentInfo.create(s_data)
//     .then(data => {
//         res = data
//     }).catch(err => {
//         res = err
//     })
// return res
// }

const DestroyDepartmentInfo = async (hospital_name_id) => {
    await DepartmentInfo.destroy({ where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetId,
    GetbyId,
    CreateDepartmentInfo,
    // UpdateDepartmentInfo,
    DestroyDepartmentInfo
};
