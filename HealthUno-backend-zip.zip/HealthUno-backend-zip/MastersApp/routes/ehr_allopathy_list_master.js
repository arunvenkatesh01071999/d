const express = require('express');
const router = express();
const EhrListController = require('../controller/EhrAllopathyListController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, EhrListController.FetchEhrList);
router.get('/:id', verify_token, EhrListController.FetchEhrList);
router.post('/', verify_token, EhrListController.NewEhrList);
router.put('/:id', verify_token, EhrListController.UpdateEhrList);
router.delete('/:id', verify_token, EhrListController.DeleteEhrList);

module.exports = router;