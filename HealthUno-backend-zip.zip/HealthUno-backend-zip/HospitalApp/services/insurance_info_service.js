const InsuranceInfo = require('../models/InsuranceInfoModel');
const InsuranceModel = require('../../MastersApp/models/InsuranceModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const Get = async () => {
    await InsuranceInfo.findAll({ include: [HospitalInfo, InsuranceModel] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await InsuranceInfo.findAll({ where: { hospital_name_id: hospital_name_id }, include: [HospitalInfo, InsuranceModel] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await InsuranceInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateInsuranceInfo = async (s_data) => {
    console.log('j',s_data);
    await InsuranceInfo.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateInsuranceInfo = async (id, s_data) => {
//     await InsuranceInfo.update(s_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

const DestroyInsuranceInfo = async (hospital_name_id) => {
    await InsuranceInfo.destroy({ where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetId,
    GetbyId,
    CreateInsuranceInfo,
    // UpdateInsuranceInfo,
    DestroyInsuranceInfo
};
