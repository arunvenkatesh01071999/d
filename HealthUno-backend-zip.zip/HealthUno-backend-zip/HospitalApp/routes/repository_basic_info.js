const express = require('express');
const router = express();
const repositoryBasicInfoController = require('../../HospitalApp/controller/RepositoryInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, repositoryBasicInfoController.FetchrepositoryBasicInfo);
router.get('/:hospital_name_id', verify_token, repositoryBasicInfoController.FetchrepositoryBasicInfo);

module.exports = router; 