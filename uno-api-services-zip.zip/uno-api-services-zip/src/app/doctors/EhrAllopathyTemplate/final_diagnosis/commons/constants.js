const FINALDIAGNOSIS = {
  NAME: "e_final_diagnosis",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    LIST_NAME: "list_name",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  FINALDIAGNOSIS
};
