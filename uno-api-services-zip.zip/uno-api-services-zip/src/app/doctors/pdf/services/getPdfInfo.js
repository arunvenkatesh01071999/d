const getPdfInfoRepos = require('../repository/getPdfInfos');

function getPDFInfoService(fastify) {
    const {getCheifComplaintsInfo} = getPdfInfoRepos.getPdfInfoRepo(fastify);
    
    return async ({ body, params, logTrace, userDetails,reply }) => {

        const knex = fastify.knexMaster;
        // const patient_id = userDetails.response.id;

        const promise1 = getCheifComplaintsInfo.call(knex,{
            logTrace,body,params,reply
        });
        // const promise2 = getPastMedicalHistory.call(knex,{
        //     patient_id,logTrace
        // });
        const [dataRepo] = await Promise.all([promise1])

        return dataRepo
    }
}

module.exports = {
    getPDFInfoService
}