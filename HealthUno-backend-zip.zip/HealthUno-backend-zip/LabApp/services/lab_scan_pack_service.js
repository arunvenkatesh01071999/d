const TestInfo = require('../models/LabScanPackModel');
const labInfo = require('../models/LabBasicInfoModel');
const ScanMaster = require('../../MastersApp/models/ScanTestMasterModel');

const Get = async () => {
    await TestInfo.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (lab_name_id) => {
    await TestInfo.findAll({ where: { lab_name_id: lab_name_id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await TestInfo.findAll({ where: { lab_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreatTestPack = async (lt_data) => {
    await TestInfo.create(lt_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateTestInfo = async (id, lt_data) => {
    await TestInfo.update(lt_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyTestInfo = async (id) => {
    await TestInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    GetId,
    CreatTestPack,
    UpdateTestInfo,
    DestroyTestInfo
};
