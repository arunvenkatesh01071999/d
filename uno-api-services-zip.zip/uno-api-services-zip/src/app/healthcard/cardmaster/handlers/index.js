const getCardMasterHandler = require("./getCardMasterHandler");
const putCardMasterHandler = require("./putCardMasterHandler");
const postCardMasterHandler = require("./postCardMasterHandler");
const deleteCardMasterHandler = require("./deleteCardMasterHandler");
const getCardMasterInfoHandler = require("./getCardMasterInfoHandler");

module.exports = {
  getCardMasterHandler,
  putCardMasterHandler,
  postCardMasterHandler,
  deleteCardMasterHandler,
  getCardMasterInfoHandler
};
