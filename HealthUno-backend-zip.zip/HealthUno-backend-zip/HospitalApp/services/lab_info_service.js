const LabInfo = require('../models/LabInfoModel');
const LabTestMasterModel = require('../../MastersApp/models/LabTestCategoryModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const Get = async () => {
    await LabInfo.findAll({ include: [LabTestMasterModel, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await LabInfo.findAll({ where: { hospital_name_id: hospital_name_id }, include: [ HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await LabInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateLabInfo = async (l_data) => {
    await LabInfo.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateLabInfo = async (id, l_data) => {
//     await LabInfo.update(l_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

const DestroyLabInfo = async (hospital_name_id) => {
    await LabInfo.destroy({ where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetId,
    GetbyId,
    CreateLabInfo,
    // UpdateLabInfo,
    DestroyLabInfo
};
