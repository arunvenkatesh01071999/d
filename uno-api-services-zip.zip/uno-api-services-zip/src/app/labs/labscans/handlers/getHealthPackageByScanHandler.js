const healthPackageServices = require("../services/scanHealthPackageServices");

function getHealthPackageByScanHandler(fastify) {
  const getHealthPackageByScan =
    healthPackageServices.getHealthPackageByScanService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getHealthPackageByScan({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHealthPackageByScanHandler;
