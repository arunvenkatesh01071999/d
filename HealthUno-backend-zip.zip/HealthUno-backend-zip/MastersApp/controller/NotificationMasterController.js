const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const notification_master_services = require('../services/notification_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchNotificationMasters = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await notification_master_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_notification_masters');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await notification_master_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_notification_masters', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
        }
    }
}

const NewNotificationMaster = async (req, res, next) => {
    notification_name = req.body.notification_name;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (notification_name) {
        nm_data = {
            notification_name: notification_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await notification_master_services.GetbyName(notification_name)
            .then(services_data => {
                if (services_data.length > 0) {
                    msg = "Notification Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    notification_master_services.CreateNotificationMaster(nm_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(500).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_notification_masters')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(500).json(failure_func(err))
                        })
                }
            })

    } else {
        msg = "notification_name and active is required";
        res.status(500).json(failure_func(msg))
    }
}

const UpdateNotificationMaster = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        notification_name = req.body.notification_name;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (notification_name) {
            nm_data = {
                notification_name: notification_name,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // await notification_master_services.GetbyName(notification_name)
            //     .then(services_data => {
            //         if (services_data.length > 0) {
            //             msg = "Notification Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            notification_master_services.UpdateNotificationMaster(id, nm_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_notification_masters')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(500).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
            //     }
            // })
        } else {
            msg = "notification_name and active is required";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

const DeleteNotificationMaster = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await notification_master_services.DestroyNotificationMaster(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_notification_masters')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}


module.exports = {
    NewNotificationMaster,
    FetchNotificationMasters,
    UpdateNotificationMaster,
    DeleteNotificationMaster
}