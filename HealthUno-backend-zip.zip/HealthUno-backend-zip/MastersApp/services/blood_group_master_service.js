const BloodGroupMasterModel = require('../models/BloodGroupMasterModel');

const Get = async () => {
    await BloodGroupMasterModel.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await BloodGroupMasterModel.findAll({ where: { id: id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (group_name) => {
    await BloodGroupMasterModel.findAll({ where: { group_name: group_name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const createBloodGroup = async () => {
    await BloodGroupMasterModel.create(ms_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateBloodGroup = async (id, ms_data) => {
    await BloodGroupMasterModel.update(ms_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyBloodGroup = async (id) => {
    await BloodGroupMasterModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    createBloodGroup,
    UpdateBloodGroup,
    DestroyBloodGroup
};