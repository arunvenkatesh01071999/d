const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const LabTestCategory = require('../../MastersApp/models/LabTestCategoryModel')
const LabTestModelId = require('../models/LabtestIdModel');

const LabTestMaster = sequelize.define("lab_test", {
    test_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    alter_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    category_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    long_descrip:{
        type: DataTypes.STRING,
        allowNull: false,
    },
    short_descrip: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    recommend: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    sample_collected: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    pretest_prepare: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });


LabTestMaster.hasMany(LabTestModelId, { foreignKey: 'test_name_id'});


LabTestMaster.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'lab_test',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabTestMaster.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'lab_test',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = LabTestMaster;