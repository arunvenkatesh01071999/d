const getHandWrittenService = require("../services/getHandWrittenService");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream")
const pump = util.promisify(pipeline);


function createHandWrittenHandler(fastify) {
  
  const createHandWritten =
  getHandWrittenService.createHandWrittenServiceBasic(fastify);

  return async (request, reply) => {

    


    const { body, params, logTrace } = request;
    
    const { userDetails } = request;
    const response = await createHandWritten({
      body,
      logTrace,
      params,
      userDetails
    });
    return reply.code(200).send(response);
  };
  
}

function updateHandWrittenHandler(fastify) {
  const updateHandWritten = getHandWrittenService.updateHandWrittenServiceBasic(fastify);

  return async (request, reply) => {

    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await updateHandWritten({
      body,
      params,
      logTrace,
      userDetails
      
    });
    return reply.code(200).send(response);
  };
}

function getHandWrittenHandler(fastify) {

  const getHandWritten = getHandWrittenService.getHandWrittenInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getHandWritten({
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function getHandWrittenHandlerId(fastify) {

  const getHandWritten = getHandWrittenService.getHandWrittenInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getHandWritten({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

function deleteHandWrittenHandler(fastify) {

  const deleteHandWritten = getHandWrittenService.deleteHandWrittenServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deleteHandWritten({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}

module.exports = {

  createHandWrittenHandler,
  updateHandWrittenHandler,
  getHandWrittenHandler,
  getHandWrittenHandlerId,
  deleteHandWrittenHandler
};
