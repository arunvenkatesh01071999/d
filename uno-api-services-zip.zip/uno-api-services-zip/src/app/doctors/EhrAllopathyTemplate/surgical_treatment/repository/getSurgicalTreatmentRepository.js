const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../../../src/app/commons/helpers");
const { SURGICAL } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postSurgicalTreatmentRepositoryBasic(fastify) {
  async function getSurgicalTreatmentAdd({ logTrace, body }) {
    const knex = this;
    const surgical = body.list_name;

    let surgicalResult = surgical.join(",");
   

    const surigicalLink = body.surgical_hospital_link
    let surigicalLinkResult = surigicalLink.join(",");


    const query = await knex(`${SURGICAL.NAME}`).insert({
      [SURGICAL.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [SURGICAL.COLUMNS.PATIENT_ID]: body.patient_id,
      [SURGICAL.COLUMNS.ACTIVE]: body.active,
      [SURGICAL.COLUMNS.LIST_NAME]: surgicalResult,
      [SURGICAL.COLUMNS.SURGICAL_HOSPITAL_LINK]: surigicalLinkResult,
      [SURGICAL.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    getSurgicalTreatmentAdd

  };
}

function updateSurgicalTreatmentRepository(fastify) {
  async function getSurgicalTreatmentUpdate({ logTrace, body, params }) {
    const knex = this;
    const  patient_id = params.patient_id;
    const doctor_id = body.doctor_id

    const surgicalTreatmentGetID = await knex.raw(`select top 1 id from e_surgical_treatment where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)
    const id=surgicalTreatmentGetID[0].id


    const surgical = body.list_name;

    let surgicalResult = surgical.join(",");

    const surigicalLink = body.surgical_hospital_link
    let surigicalLinkResult = surigicalLink.join(",");

    const query = await knex(`${SURGICAL.NAME}`)
      .where(`${SURGICAL.COLUMNS.ID}`, id)
      .update({
        [SURGICAL.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [SURGICAL.COLUMNS.PATIENT_ID]: body.patient_id,
        [SURGICAL.COLUMNS.ACTIVE]: body.active,
        [SURGICAL.COLUMNS.LIST_NAME]: surgicalResult,
      [SURGICAL.COLUMNS.SURGICAL_HOSPITAL_LINK]: surigicalLinkResult,
      [SURGICAL.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    getSurgicalTreatmentUpdate,
  };
}

function getSurgicalTreatmentRepository(fastify) {
  
  async function getSurgicalTreatmentGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${SURGICAL.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Surgical Treatment details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Surgical Treatment info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getSurgicalTreatmentGetAlls
  };

}


function getSurgicalTreatmentRepositoryId(fastify) {
  
  async function getSurgicalTreatmentGetOne({ logTrace, params }) {
    
    const knex = this;
    const patient_id = params.patient_id;
    const doctor_id = params.doctor_id;

    

    const query = knex.raw(`select top 1 * from e_surgical_treatment  where patient_id =${patient_id} and doctor_id=${doctor_id} and end_consultation =0 order BY id desc`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Surgical Treatment details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Surgical Treatment info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getSurgicalTreatmentGetOne
  };

}

function deleteSurgicalTreatmentRepositoryId(fastify) {
  async function getSurgicalTreatmentDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const  patient_id = params.patient_id;
    const doctor_id = params.doctor_id

    const surgicalTreatmentGetID = await knex.raw(`select top 1 id from e_surgical_treatment where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation=0 order By id desc`)
    const id=surgicalTreatmentGetID[0].id

    const query = await knex(`${SURGICAL.NAME}`).where(`${SURGICAL.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    getSurgicalTreatmentDelete
  };
}


module.exports = {
  postSurgicalTreatmentRepositoryBasic,
  updateSurgicalTreatmentRepository,
  getSurgicalTreatmentRepository,
  getSurgicalTreatmentRepositoryId,
  deleteSurgicalTreatmentRepositoryId

};
