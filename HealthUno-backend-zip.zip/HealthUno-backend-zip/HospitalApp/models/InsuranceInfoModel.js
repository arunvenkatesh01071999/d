const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const InsuranceModel = require('../../MastersApp/models/InsuranceModel');
const HospitalInfo = require('./HospitalBasicInfoModel');
const logger = require('../../config/activity_logger');


const InsuranceInfo = sequelize.define("h_insurance_info", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "hospital_name_id is required"
            }
        }
    },
    insurance_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "insurance_name_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

InsuranceInfo.belongsTo(InsuranceModel, { foreignKey: 'insurance_name_id' });
InsuranceInfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' })

InsuranceInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_insurance_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

InsuranceInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_insurance_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = InsuranceInfo;